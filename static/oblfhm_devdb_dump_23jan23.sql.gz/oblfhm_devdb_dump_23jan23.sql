--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5 (Ubuntu 14.5-1ubuntu1)
-- Dumped by pg_dump version 14.5 (Ubuntu 14.5-1ubuntu1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: application_masters_appcontent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.application_masters_appcontent (
    id bigint NOT NULL,
    uuid character varying(200),
    status integer NOT NULL,
    server_created_on timestamp with time zone NOT NULL,
    server_modified_on timestamp with time zone NOT NULL,
    app_created_on date,
    created_by_id integer,
    modified_by_id integer,
    sync_status integer NOT NULL,
    CONSTRAINT application_masters_appcontent_status_check CHECK ((status >= 0)),
    CONSTRAINT application_masters_appcontent_sync_status_check CHECK ((sync_status >= 0))
);


ALTER TABLE public.application_masters_appcontent OWNER TO postgres;

--
-- Name: application_masters_appcontent_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.application_masters_appcontent_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.application_masters_appcontent_id_seq OWNER TO postgres;

--
-- Name: application_masters_appcontent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.application_masters_appcontent_id_seq OWNED BY public.application_masters_appcontent.id;


--
-- Name: application_masters_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.application_masters_category (
    id bigint NOT NULL,
    uuid character varying(200),
    status integer NOT NULL,
    server_created_on timestamp with time zone NOT NULL,
    server_modified_on timestamp with time zone NOT NULL,
    sync_status integer NOT NULL,
    name character varying(200) NOT NULL,
    parent_id integer NOT NULL,
    created_by_id integer,
    modified_by_id integer,
    CONSTRAINT application_masters_category_parent_id_check CHECK ((parent_id >= 0)),
    CONSTRAINT application_masters_category_status_check CHECK ((status >= 0)),
    CONSTRAINT application_masters_category_sync_status_check CHECK ((sync_status >= 0))
);


ALTER TABLE public.application_masters_category OWNER TO postgres;

--
-- Name: application_masters_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.application_masters_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.application_masters_category_id_seq OWNER TO postgres;

--
-- Name: application_masters_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.application_masters_category_id_seq OWNED BY public.application_masters_category.id;


--
-- Name: application_masters_comorbid; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.application_masters_comorbid (
    id bigint NOT NULL,
    uuid character varying(200),
    status integer NOT NULL,
    server_created_on timestamp with time zone NOT NULL,
    server_modified_on timestamp with time zone NOT NULL,
    sync_status integer NOT NULL,
    name character varying(150) NOT NULL,
    patient_id character varying(150),
    created_by_id integer,
    modified_by_id integer,
    CONSTRAINT application_masters_comorbid_status_check CHECK ((status >= 0)),
    CONSTRAINT application_masters_comorbid_sync_status_check CHECK ((sync_status >= 0))
);


ALTER TABLE public.application_masters_comorbid OWNER TO postgres;

--
-- Name: application_masters_comorbid_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.application_masters_comorbid_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.application_masters_comorbid_id_seq OWNER TO postgres;

--
-- Name: application_masters_comorbid_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.application_masters_comorbid_id_seq OWNED BY public.application_masters_comorbid.id;


--
-- Name: application_masters_district; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.application_masters_district (
    id bigint NOT NULL,
    uuid character varying(200),
    status integer NOT NULL,
    server_created_on timestamp with time zone NOT NULL,
    server_modified_on timestamp with time zone NOT NULL,
    name character varying(150) NOT NULL,
    created_by_id integer,
    modified_by_id integer,
    state_id bigint NOT NULL,
    sync_status integer NOT NULL,
    code character varying(2),
    CONSTRAINT application_masters_district_status_check CHECK ((status >= 0)),
    CONSTRAINT application_masters_district_sync_status_check CHECK ((sync_status >= 0))
);


ALTER TABLE public.application_masters_district OWNER TO postgres;

--
-- Name: application_masters_district_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.application_masters_district_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.application_masters_district_id_seq OWNER TO postgres;

--
-- Name: application_masters_district_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.application_masters_district_id_seq OWNED BY public.application_masters_district.id;


--
-- Name: application_masters_dosage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.application_masters_dosage (
    id bigint NOT NULL,
    uuid character varying(200),
    status integer NOT NULL,
    server_created_on timestamp with time zone NOT NULL,
    server_modified_on timestamp with time zone NOT NULL,
    sync_status integer NOT NULL,
    name character varying(200) NOT NULL,
    value double precision,
    created_by_id integer,
    modified_by_id integer,
    CONSTRAINT application_masters_dosage_status_check CHECK ((status >= 0)),
    CONSTRAINT application_masters_dosage_sync_status_check CHECK ((sync_status >= 0))
);


ALTER TABLE public.application_masters_dosage OWNER TO postgres;

--
-- Name: application_masters_dosage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.application_masters_dosage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.application_masters_dosage_id_seq OWNER TO postgres;

--
-- Name: application_masters_dosage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.application_masters_dosage_id_seq OWNED BY public.application_masters_dosage.id;


--
-- Name: application_masters_masterlookup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.application_masters_masterlookup (
    id bigint NOT NULL,
    name character varying(150) NOT NULL,
    "order" integer NOT NULL,
    parent_id bigint,
    created_by_id integer,
    modified_by_id integer,
    server_created_on timestamp with time zone NOT NULL,
    server_modified_on timestamp with time zone NOT NULL,
    status integer NOT NULL,
    uuid character varying(200),
    sync_status integer NOT NULL,
    CONSTRAINT application_masters_masterlookup_order_check CHECK (("order" >= 0)),
    CONSTRAINT application_masters_masterlookup_status_check CHECK ((status >= 0)),
    CONSTRAINT application_masters_masterlookup_sync_status_check CHECK ((sync_status >= 0))
);


ALTER TABLE public.application_masters_masterlookup OWNER TO postgres;

--
-- Name: application_masters_masterlookup_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.application_masters_masterlookup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.application_masters_masterlookup_id_seq OWNER TO postgres;

--
-- Name: application_masters_masterlookup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.application_masters_masterlookup_id_seq OWNED BY public.application_masters_masterlookup.id;


--
-- Name: application_masters_medicines; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.application_masters_medicines (
    id bigint NOT NULL,
    uuid character varying(200),
    status integer NOT NULL,
    server_created_on timestamp with time zone NOT NULL,
    server_modified_on timestamp with time zone NOT NULL,
    sync_status integer NOT NULL,
    name character varying(150) NOT NULL,
    code character varying(50),
    type character varying(50),
    category_id integer,
    created_by_id integer,
    modified_by_id integer,
    CONSTRAINT application_masters_medicines_status_check CHECK ((status >= 0)),
    CONSTRAINT application_masters_medicines_sync_status_check CHECK ((sync_status >= 0))
);


ALTER TABLE public.application_masters_medicines OWNER TO postgres;

--
-- Name: application_masters_medicines_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.application_masters_medicines_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.application_masters_medicines_id_seq OWNER TO postgres;

--
-- Name: application_masters_medicines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.application_masters_medicines_id_seq OWNED BY public.application_masters_medicines.id;


--
-- Name: application_masters_phc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.application_masters_phc (
    id bigint NOT NULL,
    uuid character varying(200),
    status integer NOT NULL,
    server_created_on timestamp with time zone NOT NULL,
    server_modified_on timestamp with time zone NOT NULL,
    name character varying(150) NOT NULL,
    code character varying(50),
    created_by_id integer,
    modified_by_id integer,
    taluk_id bigint NOT NULL,
    sync_status integer NOT NULL,
    CONSTRAINT application_masters_phc_status_check CHECK ((status >= 0)),
    CONSTRAINT application_masters_phc_sync_status_check CHECK ((sync_status >= 0))
);


ALTER TABLE public.application_masters_phc OWNER TO postgres;

--
-- Name: application_masters_phc_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.application_masters_phc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.application_masters_phc_id_seq OWNER TO postgres;

--
-- Name: application_masters_phc_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.application_masters_phc_id_seq OWNED BY public.application_masters_phc.id;


--
-- Name: application_masters_state; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.application_masters_state (
    id bigint NOT NULL,
    uuid character varying(200),
    status integer NOT NULL,
    server_created_on timestamp with time zone NOT NULL,
    server_modified_on timestamp with time zone NOT NULL,
    name character varying(150) NOT NULL,
    created_by_id integer,
    modified_by_id integer,
    parent_id integer NOT NULL,
    sync_status integer NOT NULL,
    code character varying(2),
    CONSTRAINT application_masters_state_parent_id_check CHECK ((parent_id >= 0)),
    CONSTRAINT application_masters_state_status_check CHECK ((status >= 0)),
    CONSTRAINT application_masters_state_sync_status_check CHECK ((sync_status >= 0))
);


ALTER TABLE public.application_masters_state OWNER TO postgres;

--
-- Name: application_masters_state_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.application_masters_state_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.application_masters_state_id_seq OWNER TO postgres;

--
-- Name: application_masters_state_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.application_masters_state_id_seq OWNED BY public.application_masters_state.id;


--
-- Name: application_masters_subcenter; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.application_masters_subcenter (
    id bigint NOT NULL,
    uuid character varying(200),
    status integer NOT NULL,
    server_created_on timestamp with time zone NOT NULL,
    server_modified_on timestamp with time zone NOT NULL,
    sync_status integer NOT NULL,
    name character varying(150) NOT NULL,
    code character varying(2),
    created_by_id integer,
    modified_by_id integer,
    phc_id bigint NOT NULL,
    CONSTRAINT application_masters_subcenter_status_check CHECK ((status >= 0)),
    CONSTRAINT application_masters_subcenter_sync_status_check CHECK ((sync_status >= 0))
);


ALTER TABLE public.application_masters_subcenter OWNER TO postgres;

--
-- Name: application_masters_subcenter_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.application_masters_subcenter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.application_masters_subcenter_id_seq OWNER TO postgres;

--
-- Name: application_masters_subcenter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.application_masters_subcenter_id_seq OWNED BY public.application_masters_subcenter.id;


--
-- Name: application_masters_taluk; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.application_masters_taluk (
    id bigint NOT NULL,
    uuid character varying(200),
    status integer NOT NULL,
    server_created_on timestamp with time zone NOT NULL,
    server_modified_on timestamp with time zone NOT NULL,
    name character varying(150) NOT NULL,
    created_by_id integer,
    district_id bigint NOT NULL,
    modified_by_id integer,
    sync_status integer NOT NULL,
    code character varying(2),
    CONSTRAINT application_masters_taluk_status_check CHECK ((status >= 0)),
    CONSTRAINT application_masters_taluk_sync_status_check CHECK ((sync_status >= 0))
);


ALTER TABLE public.application_masters_taluk OWNER TO postgres;

--
-- Name: application_masters_taluk_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.application_masters_taluk_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.application_masters_taluk_id_seq OWNER TO postgres;

--
-- Name: application_masters_taluk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.application_masters_taluk_id_seq OWNED BY public.application_masters_taluk.id;


--
-- Name: application_masters_village; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.application_masters_village (
    id bigint NOT NULL,
    uuid character varying(200),
    status integer NOT NULL,
    server_created_on timestamp with time zone NOT NULL,
    server_modified_on timestamp with time zone NOT NULL,
    name character varying(150) NOT NULL,
    code character varying(50),
    created_by_id integer,
    modified_by_id integer,
    sync_status integer NOT NULL,
    subcenter_id bigint,
    CONSTRAINT application_masters_village_status_check CHECK ((status >= 0)),
    CONSTRAINT application_masters_village_sync_status_check CHECK ((sync_status >= 0))
);


ALTER TABLE public.application_masters_village OWNER TO postgres;

--
-- Name: application_masters_village_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.application_masters_village_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.application_masters_village_id_seq OWNER TO postgres;

--
-- Name: application_masters_village_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.application_masters_village_id_seq OWNED BY public.application_masters_village.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO postgres;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_groups (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO postgres;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_user_permissions (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: health_management_diagnosis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.health_management_diagnosis (
    id bigint NOT NULL,
    status integer NOT NULL,
    server_created_on timestamp with time zone NOT NULL,
    server_modified_on timestamp with time zone NOT NULL,
    uuid character varying(150),
    treatment_uuid character varying(150),
    source_treatment integer,
    years character varying(150),
    sync_status integer NOT NULL,
    created_by_id integer,
    modified_by_id integer,
    ndc_id bigint NOT NULL,
    detected_by integer,
    user_uuid character varying(150),
    CONSTRAINT health_management_diagnosis_status_check CHECK ((status >= 0))
);


ALTER TABLE public.health_management_diagnosis OWNER TO postgres;

--
-- Name: health_management_diagnosis_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.health_management_diagnosis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.health_management_diagnosis_id_seq OWNER TO postgres;

--
-- Name: health_management_diagnosis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.health_management_diagnosis_id_seq OWNED BY public.health_management_diagnosis.id;


--
-- Name: health_management_drugdispensation; Type: TABLE; Schema: public; Owner: oblf_user
--

CREATE TABLE public.health_management_drugdispensation (
    id bigint NOT NULL,
    uuid character varying(200),
    status integer NOT NULL,
    server_created_on timestamp with time zone NOT NULL,
    server_modified_on timestamp with time zone NOT NULL,
    sync_status integer NOT NULL,
    units_dispensed integer,
    date_of_dispensation date,
    created_by_id integer,
    medicine_id bigint,
    modified_by_id integer,
    village_id bigint NOT NULL,
    CONSTRAINT health_management_drugdispensation_status_check CHECK ((status >= 0)),
    CONSTRAINT health_management_drugdispensation_sync_status_check CHECK ((sync_status >= 0)),
    CONSTRAINT health_management_drugdispensation_units_dispensed_check CHECK ((units_dispensed >= 0))
);


ALTER TABLE public.health_management_drugdispensation OWNER TO oblf_user;

--
-- Name: health_management_drugdispensation_id_seq; Type: SEQUENCE; Schema: public; Owner: oblf_user
--

CREATE SEQUENCE public.health_management_drugdispensation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.health_management_drugdispensation_id_seq OWNER TO oblf_user;

--
-- Name: health_management_drugdispensation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oblf_user
--

ALTER SEQUENCE public.health_management_drugdispensation_id_seq OWNED BY public.health_management_drugdispensation.id;


--
-- Name: health_management_homevisit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.health_management_homevisit (
    id bigint NOT NULL,
    status integer NOT NULL,
    server_created_on timestamp with time zone NOT NULL,
    server_modified_on timestamp with time zone NOT NULL,
    sync_status integer NOT NULL,
    uuid character varying(150),
    patient_uuid character varying(150),
    home_vist integer NOT NULL,
    response_location character varying(150),
    response_datetime timestamp with time zone,
    image character varying(100),
    created_by_id integer,
    modified_by_id integer,
    user_uuid character varying(150),
    CONSTRAINT health_management_homevisit_home_vist_check CHECK ((home_vist >= 0)),
    CONSTRAINT health_management_homevisit_status_check CHECK ((status >= 0)),
    CONSTRAINT health_management_homevisit_sync_status_check CHECK ((sync_status >= 0))
);


ALTER TABLE public.health_management_homevisit OWNER TO postgres;

--
-- Name: health_management_homevisit_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.health_management_homevisit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.health_management_homevisit_id_seq OWNER TO postgres;

--
-- Name: health_management_homevisit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.health_management_homevisit_id_seq OWNED BY public.health_management_homevisit.id;


--
-- Name: health_management_medicinestock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.health_management_medicinestock (
    id bigint NOT NULL,
    uuid character varying(200),
    status integer NOT NULL,
    server_created_on timestamp with time zone NOT NULL,
    server_modified_on timestamp with time zone NOT NULL,
    sync_status integer NOT NULL,
    date_of_creation date,
    unit_price integer,
    no_of_units integer,
    opening_stock integer,
    closing_stock integer,
    created_by_id integer,
    medicine_id bigint,
    modified_by_id integer,
    CONSTRAINT health_management_medicinestock_no_of_units_check CHECK ((no_of_units >= 0)),
    CONSTRAINT health_management_medicinestock_status_check CHECK ((status >= 0)),
    CONSTRAINT health_management_medicinestock_sync_status_check CHECK ((sync_status >= 0)),
    CONSTRAINT health_management_medicinestock_unit_price_check CHECK ((unit_price >= 0))
);


ALTER TABLE public.health_management_medicinestock OWNER TO postgres;

--
-- Name: health_management_medicinestock_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.health_management_medicinestock_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.health_management_medicinestock_id_seq OWNER TO postgres;

--
-- Name: health_management_medicinestock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.health_management_medicinestock_id_seq OWNED BY public.health_management_medicinestock.id;


--
-- Name: health_management_patients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.health_management_patients (
    id bigint NOT NULL,
    status integer NOT NULL,
    server_created_on timestamp with time zone NOT NULL,
    server_modified_on timestamp with time zone NOT NULL,
    uuid character varying(150),
    patient_id character varying(150),
    name character varying(150) NOT NULL,
    dob date,
    age integer,
    gender integer,
    phone_number character varying(10),
    image character varying(100),
    height integer,
    weight integer,
    door_no character varying(150),
    fee_status integer,
    fee_paid integer,
    fee_date timestamp with time zone,
    registered_date timestamp with time zone,
    last_visit_date timestamp with time zone,
    created_by_id integer,
    modified_by_id integer,
    patient_visit_type_id bigint,
    village_id bigint,
    sync_status integer NOT NULL,
    seq_no character varying(150),
    subcenter_id integer,
    user_uuid character varying(150),
    CONSTRAINT health_management_patients_age_check CHECK ((age >= 0)),
    CONSTRAINT health_management_patients_fee_paid_check CHECK ((fee_paid >= 0)),
    CONSTRAINT health_management_patients_fee_status_check CHECK ((fee_status >= 0)),
    CONSTRAINT health_management_patients_height_check CHECK ((height >= 0)),
    CONSTRAINT health_management_patients_status_check CHECK ((status >= 0)),
    CONSTRAINT health_management_patients_subcenter_id_check CHECK ((subcenter_id >= 0)),
    CONSTRAINT health_management_patients_weight_check CHECK ((weight >= 0))
);


ALTER TABLE public.health_management_patients OWNER TO postgres;

--
-- Name: health_management_patients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.health_management_patients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.health_management_patients_id_seq OWNER TO postgres;

--
-- Name: health_management_patients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.health_management_patients_id_seq OWNED BY public.health_management_patients.id;


--
-- Name: health_management_prescription; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.health_management_prescription (
    id bigint NOT NULL,
    status integer NOT NULL,
    server_created_on timestamp with time zone NOT NULL,
    server_modified_on timestamp with time zone NOT NULL,
    uuid character varying(150),
    patient_uuid character varying(150),
    treatment_uuid character varying(150),
    no_of_days integer,
    medicine_type character varying(150),
    qty integer,
    sync_status integer NOT NULL,
    created_by_id integer,
    medicines_id bigint NOT NULL,
    modified_by_id integer,
    dosage_id bigint,
    user_uuid character varying(150),
    CONSTRAINT health_management_prescription_status_check CHECK ((status >= 0))
);


ALTER TABLE public.health_management_prescription OWNER TO postgres;

--
-- Name: health_management_prescription_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.health_management_prescription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.health_management_prescription_id_seq OWNER TO postgres;

--
-- Name: health_management_prescription_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.health_management_prescription_id_seq OWNED BY public.health_management_prescription.id;


--
-- Name: health_management_scanned_report; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.health_management_scanned_report (
    id bigint NOT NULL,
    status integer NOT NULL,
    server_created_on timestamp with time zone NOT NULL,
    server_modified_on timestamp with time zone NOT NULL,
    uuid character varying(150),
    patient_uuid character varying(150),
    title character varying(150),
    image_path character varying(150),
    captured_date timestamp with time zone,
    sync_status integer NOT NULL,
    created_by_id integer,
    modified_by_id integer,
    user_uuid character varying(150),
    CONSTRAINT health_management_scanned_report_status_check CHECK ((status >= 0))
);


ALTER TABLE public.health_management_scanned_report OWNER TO postgres;

--
-- Name: health_management_scanned_report_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.health_management_scanned_report_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.health_management_scanned_report_id_seq OWNER TO postgres;

--
-- Name: health_management_scanned_report_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.health_management_scanned_report_id_seq OWNED BY public.health_management_scanned_report.id;


--
-- Name: health_management_treatments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.health_management_treatments (
    id bigint NOT NULL,
    status integer NOT NULL,
    server_created_on timestamp with time zone NOT NULL,
    server_modified_on timestamp with time zone NOT NULL,
    uuid character varying(150),
    patient_uuid character varying(150),
    visit_date timestamp with time zone,
    bp_sys1 character varying(150),
    bp_non_sys1 character varying(150),
    bp_sys2 character varying(150),
    bp_non_sys2 character varying(150),
    bp_sys3 character varying(150),
    bp_non_sys3 character varying(150),
    fbs character varying(150),
    pp character varying(150),
    random character varying(150),
    weight character varying(150),
    bmi character varying(150),
    symptoms character varying(150),
    remarks character varying(150),
    hyper_diabetic integer,
    co_morbid_ids character varying(150),
    co_morbid_names character varying(150),
    is_alcoholic integer,
    is_tobacco integer,
    is_smoker integer,
    created_by_id integer,
    modified_by_id integer,
    sync_status integer NOT NULL,
    user_uuid character varying(150),
    CONSTRAINT health_management_treatments_hyper_diabetic_check CHECK ((hyper_diabetic >= 0)),
    CONSTRAINT health_management_treatments_status_check CHECK ((status >= 0))
);


ALTER TABLE public.health_management_treatments OWNER TO postgres;

--
-- Name: health_management_treatments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.health_management_treatments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.health_management_treatments_id_seq OWNER TO postgres;

--
-- Name: health_management_treatments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.health_management_treatments_id_seq OWNED BY public.health_management_treatments.id;


--
-- Name: health_management_userprofile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.health_management_userprofile (
    id bigint NOT NULL,
    status integer NOT NULL,
    server_created_on timestamp with time zone NOT NULL,
    server_modified_on timestamp with time zone NOT NULL,
    uuid character varying(200),
    user_type integer NOT NULL,
    created_by_id integer,
    modified_by_id integer,
    user_id integer NOT NULL,
    village_id bigint,
    sync_status integer NOT NULL,
    phone_no character varying(150),
    CONSTRAINT health_management_userprofile_status_check CHECK ((status >= 0)),
    CONSTRAINT health_management_userprofile_sync_status_check CHECK ((sync_status >= 0)),
    CONSTRAINT health_management_userprofile_user_type_check CHECK ((user_type >= 0))
);


ALTER TABLE public.health_management_userprofile OWNER TO postgres;

--
-- Name: health_management_userprofile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.health_management_userprofile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.health_management_userprofile_id_seq OWNER TO postgres;

--
-- Name: health_management_userprofile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.health_management_userprofile_id_seq OWNED BY public.health_management_userprofile.id;


--
-- Name: application_masters_appcontent id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_appcontent ALTER COLUMN id SET DEFAULT nextval('public.application_masters_appcontent_id_seq'::regclass);


--
-- Name: application_masters_category id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_category ALTER COLUMN id SET DEFAULT nextval('public.application_masters_category_id_seq'::regclass);


--
-- Name: application_masters_comorbid id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_comorbid ALTER COLUMN id SET DEFAULT nextval('public.application_masters_comorbid_id_seq'::regclass);


--
-- Name: application_masters_district id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_district ALTER COLUMN id SET DEFAULT nextval('public.application_masters_district_id_seq'::regclass);


--
-- Name: application_masters_dosage id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_dosage ALTER COLUMN id SET DEFAULT nextval('public.application_masters_dosage_id_seq'::regclass);


--
-- Name: application_masters_masterlookup id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_masterlookup ALTER COLUMN id SET DEFAULT nextval('public.application_masters_masterlookup_id_seq'::regclass);


--
-- Name: application_masters_medicines id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_medicines ALTER COLUMN id SET DEFAULT nextval('public.application_masters_medicines_id_seq'::regclass);


--
-- Name: application_masters_phc id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_phc ALTER COLUMN id SET DEFAULT nextval('public.application_masters_phc_id_seq'::regclass);


--
-- Name: application_masters_state id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_state ALTER COLUMN id SET DEFAULT nextval('public.application_masters_state_id_seq'::regclass);


--
-- Name: application_masters_subcenter id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_subcenter ALTER COLUMN id SET DEFAULT nextval('public.application_masters_subcenter_id_seq'::regclass);


--
-- Name: application_masters_taluk id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_taluk ALTER COLUMN id SET DEFAULT nextval('public.application_masters_taluk_id_seq'::regclass);


--
-- Name: application_masters_village id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_village ALTER COLUMN id SET DEFAULT nextval('public.application_masters_village_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: health_management_diagnosis id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_diagnosis ALTER COLUMN id SET DEFAULT nextval('public.health_management_diagnosis_id_seq'::regclass);


--
-- Name: health_management_drugdispensation id; Type: DEFAULT; Schema: public; Owner: oblf_user
--

ALTER TABLE ONLY public.health_management_drugdispensation ALTER COLUMN id SET DEFAULT nextval('public.health_management_drugdispensation_id_seq'::regclass);


--
-- Name: health_management_homevisit id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_homevisit ALTER COLUMN id SET DEFAULT nextval('public.health_management_homevisit_id_seq'::regclass);


--
-- Name: health_management_medicinestock id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_medicinestock ALTER COLUMN id SET DEFAULT nextval('public.health_management_medicinestock_id_seq'::regclass);


--
-- Name: health_management_patients id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_patients ALTER COLUMN id SET DEFAULT nextval('public.health_management_patients_id_seq'::regclass);


--
-- Name: health_management_prescription id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_prescription ALTER COLUMN id SET DEFAULT nextval('public.health_management_prescription_id_seq'::regclass);


--
-- Name: health_management_scanned_report id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_scanned_report ALTER COLUMN id SET DEFAULT nextval('public.health_management_scanned_report_id_seq'::regclass);


--
-- Name: health_management_treatments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_treatments ALTER COLUMN id SET DEFAULT nextval('public.health_management_treatments_id_seq'::regclass);


--
-- Name: health_management_userprofile id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_userprofile ALTER COLUMN id SET DEFAULT nextval('public.health_management_userprofile_id_seq'::regclass);


--
-- Data for Name: application_masters_appcontent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.application_masters_appcontent (id, uuid, status, server_created_on, server_modified_on, app_created_on, created_by_id, modified_by_id, sync_status) FROM stdin;
\.


--
-- Data for Name: application_masters_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.application_masters_category (id, uuid, status, server_created_on, server_modified_on, sync_status, name, parent_id, created_by_id, modified_by_id) FROM stdin;
14	\N	2	2022-12-28 05:57:17.136543+00	2022-12-28 05:57:17.13656+00	2	Pumps and inhaler	0	\N	\N
13	\N	2	2022-12-28 05:57:17.139703+00	2022-12-28 05:57:17.139717+00	2	Ointments and lotions	0	\N	\N
12	\N	2	2022-12-28 05:57:17.142563+00	2022-12-28 05:57:17.142576+00	2	Eye drops	0	\N	\N
11	\N	2	2022-12-28 05:57:17.145395+00	2022-12-28 05:57:17.145408+00	2	Syrups and powder	0	\N	\N
10	\N	2	2022-12-28 05:57:17.148214+00	2022-12-28 05:57:17.148227+00	2	Psychiatry drugs	0	\N	\N
9	\N	2	2022-12-28 05:57:17.151494+00	2022-12-28 05:57:17.151511+00	2	Respiratory system related	0	\N	\N
8	\N	2	2022-12-28 05:57:17.154329+00	2022-12-28 05:57:17.154341+00	2	Digestive system related	0	\N	\N
7	\N	2	2022-12-28 05:57:17.157116+00	2022-12-28 05:57:17.157129+00	2	NSAIDS and related	0	\N	\N
6	\N	2	2022-12-28 05:57:17.160759+00	2022-12-28 05:57:17.160777+00	2	Antiparasitic	0	\N	\N
5	\N	2	2022-12-28 05:57:17.164886+00	2022-12-28 05:57:17.1649+00	2	Antifungal	0	\N	\N
4	\N	2	2022-12-28 05:57:17.167837+00	2022-12-28 05:57:17.16785+00	2	Antibiotics	0	\N	\N
3	\N	2	2022-12-28 05:57:17.17065+00	2022-12-28 05:57:17.170663+00	2	Vitamins and minerals	0	\N	\N
2	\N	2	2022-12-28 05:57:17.173449+00	2022-12-28 05:57:17.173462+00	2	ANTIDIABETICS	0	\N	\N
1	\N	2	2022-12-28 05:57:17.176259+00	2022-12-28 05:57:17.176272+00	2	ANTIHYPERTENSIVES	0	\N	\N
\.


--
-- Data for Name: application_masters_comorbid; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.application_masters_comorbid (id, uuid, status, server_created_on, server_modified_on, sync_status, name, patient_id, created_by_id, modified_by_id) FROM stdin;
1	\N	2	2022-12-12 16:06:14.739283+00	2022-12-12 16:06:14.73934+00	2	ASTHMA	\N	\N	\N
2	\N	2	2022-12-12 16:06:14.744092+00	2022-12-12 16:06:14.744126+00	2	CHRONIC KIDNEY DISEASE	\N	\N	\N
3	\N	2	2022-12-12 16:06:14.751541+00	2022-12-12 16:06:14.751572+00	2	CHRONIC LIVER DISEASE	\N	\N	\N
4	\N	2	2022-12-12 16:06:14.756625+00	2022-12-12 16:06:14.75665+00	2	CORONARY ARTERY DISEASE	\N	\N	\N
5	\N	2	2022-12-12 16:06:14.761218+00	2022-12-12 16:06:14.761247+00	2	COPD	\N	\N	\N
6	\N	2	2022-12-12 16:06:14.766155+00	2022-12-12 16:06:14.766178+00	2	ARTHRITIS	\N	\N	\N
7	\N	2	2022-12-12 16:06:14.771994+00	2022-12-12 16:06:14.772013+00	2	RHEUMATOID ARTHRITIS	\N	\N	\N
8	\N	2	2022-12-12 16:06:14.775435+00	2022-12-12 16:06:14.775453+00	2	EPILEPSY 	\N	\N	\N
9	\N	2	2022-12-12 16:06:14.779375+00	2022-12-12 16:06:14.779391+00	2	PSYCHIATRIC DISORDER	\N	\N	\N
10	\N	2	2022-12-12 16:06:14.782625+00	2022-12-12 16:06:14.78264+00	2	MENSTRUAL DISORDER	\N	\N	\N
11	\N	2	2022-12-12 16:06:14.785135+00	2022-12-12 16:06:14.785148+00	2	ANEMIA 	\N	\N	\N
12	\N	2	2022-12-12 16:06:14.787439+00	2022-12-12 16:06:14.787452+00	2	DVT	\N	\N	\N
13	\N	2	2022-12-12 16:06:14.789697+00	2022-12-12 16:06:14.789709+00	2	VARICOSE VEINS 	\N	\N	\N
14	\N	2	2022-12-12 16:06:14.791849+00	2022-12-12 16:06:14.791858+00	2	RENAL DISORDERS	\N	\N	\N
15	\N	2	2022-12-12 16:06:14.793503+00	2022-12-12 16:06:14.793517+00	2	TUBERCULOSIS	\N	\N	\N
16	\N	2	2022-12-12 16:06:14.795849+00	2022-12-12 16:06:14.795859+00	2	THYROID DISORDER	\N	\N	\N
17	\N	2	2022-12-12 16:06:14.797957+00	2022-12-12 16:06:14.797964+00	2	DRUG DISORDER	\N	\N	\N
\.


--
-- Data for Name: application_masters_district; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.application_masters_district (id, uuid, status, server_created_on, server_modified_on, name, created_by_id, modified_by_id, state_id, sync_status, code) FROM stdin;
51	\N	2	2022-12-12 18:10:07.100951+00	2022-12-16 09:54:22.605817+00	Bangalore urban	\N	\N	12	2	BU
\.


--
-- Data for Name: application_masters_dosage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.application_masters_dosage (id, uuid, status, server_created_on, server_modified_on, sync_status, name, value, created_by_id, modified_by_id) FROM stdin;
6	\N	2	2022-12-15 12:14:02.632506+00	2022-12-15 12:14:02.632522+00	2	WEEKLY ONCE	1	\N	\N
5	\N	2	2022-12-15 12:14:02.6361+00	2022-12-15 12:14:02.636121+00	2	HS	1	\N	\N
4	\N	2	2022-12-15 12:14:02.63915+00	2022-12-15 12:14:02.639163+00	2	SOS	1	\N	\N
3	\N	2	2022-12-15 12:14:02.645825+00	2022-12-15 12:14:02.64584+00	2	TID	1	\N	\N
2	\N	2	2022-12-15 12:14:02.649388+00	2022-12-15 12:14:02.649401+00	2	BD	1	\N	\N
1	\N	2	2022-12-15 12:14:02.65276+00	2022-12-15 12:14:02.652773+00	2	OD	1	\N	\N
\.


--
-- Data for Name: application_masters_masterlookup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.application_masters_masterlookup (id, name, "order", parent_id, created_by_id, modified_by_id, server_created_on, server_modified_on, status, uuid, sync_status) FROM stdin;
4	ndcs	0	\N	\N	\N	2022-12-09 07:30:48.737978+00	2022-12-09 07:30:48.73799+00	2	\N	2
6	patient_visit_type	0	\N	\N	\N	2022-12-09 15:43:08.754819+00	2022-12-09 15:43:08.754849+00	2	\N	2
12	regular patient	0	6	\N	\N	2022-12-12 16:15:07.584948+00	2022-12-13 05:56:04.934393+00	2	\N	2
13	walk in patient	0	6	\N	\N	2022-12-13 05:56:52.487722+00	2022-12-13 05:56:52.48775+00	2	\N	2
11	KHT	0	4	\N	\N	2022-12-12 16:10:28.102219+00	2022-12-15 07:25:07.773328+00	2	\N	2
10	KDM	0	4	\N	\N	2022-12-12 16:10:08.37209+00	2022-12-15 07:25:19.085616+00	2	\N	2
7	PHT	0	4	\N	\N	2022-12-12 16:08:32.985372+00	2022-12-15 07:25:52.439348+00	2	\N	2
5	PDM	0	4	\N	\N	2022-12-09 07:31:06.053866+00	2022-12-15 07:26:05.087355+00	2	\N	2
8	DM	0	4	\N	\N	2022-12-12 16:09:19.783592+00	2022-12-20 12:41:45.597788+00	2	\N	2
9	HT	0	4	\N	\N	2022-12-12 16:09:33.470167+00	2022-12-20 12:41:56.418731+00	2	\N	2
21	MSD Sb	0	4	\N	\N	2022-12-29 07:41:47.626555+00	2022-12-29 07:41:59.334364+00	2	\N	2
\.


--
-- Data for Name: application_masters_medicines; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.application_masters_medicines (id, uuid, status, server_created_on, server_modified_on, sync_status, name, code, type, category_id, created_by_id, modified_by_id) FROM stdin;
1	\N	2	2022-12-13 12:55:51.035615+00	2022-12-13 12:55:51.035634+00	2	ANTIHYPERTENSIVES		Tab	0	\N	\N
2	\N	2	2022-12-13 12:55:51.039637+00	2022-12-13 12:55:51.039654+00	2	ANTIDIABETICS		Tab	0	\N	\N
3	\N	2	2022-12-13 12:55:51.043361+00	2022-12-13 12:55:51.043375+00	2	Vitamins and minerals		Tab	0	\N	\N
4	\N	2	2022-12-13 12:55:51.047004+00	2022-12-13 12:55:51.047019+00	2	Antibiotics		Tab	0	\N	\N
5	\N	2	2022-12-13 12:55:51.050379+00	2022-12-13 12:55:51.050395+00	2	Antifungal		Tab	0	\N	\N
6	\N	2	2022-12-13 12:55:51.054304+00	2022-12-13 12:55:51.054319+00	2	Antiparasitic		Tab	0	\N	\N
7	\N	2	2022-12-13 12:55:51.057739+00	2022-12-13 12:55:51.057754+00	2	NSAIDS and related		Tab	0	\N	\N
8	\N	2	2022-12-13 12:55:51.061211+00	2022-12-13 12:55:51.061231+00	2	Digestive system related 		Tab	0	\N	\N
9	\N	2	2022-12-13 12:55:51.064528+00	2022-12-13 12:55:51.064542+00	2	Respiratory system related		Tab	0	\N	\N
10	\N	2	2022-12-13 12:55:51.067667+00	2022-12-13 12:55:51.067681+00	2	Psychiatry drugs		Tab	0	\N	\N
11	\N	2	2022-12-13 12:55:51.071196+00	2022-12-13 12:55:51.071209+00	2	Syrups and powder		Syrup	0	\N	\N
12	\N	2	2022-12-13 12:55:51.074421+00	2022-12-13 12:55:51.074437+00	2	Eye drops		EyeDrop	0	\N	\N
13	\N	2	2022-12-13 12:55:51.078055+00	2022-12-13 12:55:51.078068+00	2	Ointments and lotions		Lotion	0	\N	\N
14	\N	2	2022-12-13 12:55:51.081106+00	2022-12-13 12:55:51.081119+00	2	Pumps and inhaler		Inhaler	0	\N	\N
15	\N	2	2022-12-13 12:55:51.084332+00	2022-12-13 12:55:51.084344+00	2	Tab AMLODIPINE 5mg		Tab	1	\N	\N
16	\N	2	2022-12-13 12:55:51.087929+00	2022-12-13 12:55:51.087944+00	2	Tab Telmisartan 40mg		Tab	1	\N	\N
17	\N	2	2022-12-13 12:55:51.09158+00	2022-12-13 12:55:51.0916+00	2	Tab Hydrochlorothiazide 25mg		Tab	1	\N	\N
18	\N	2	2022-12-13 12:55:51.102932+00	2022-12-13 12:55:51.102954+00	2	Tab Atenolol 50mg		Tab	1	\N	\N
19	\N	2	2022-12-13 12:55:51.107425+00	2022-12-13 12:55:51.107445+00	2	Tab Metoprolol 50mg		Tab	1	\N	\N
20	\N	2	2022-12-13 12:55:51.111572+00	2022-12-13 12:55:51.111592+00	2	Tab Metformin 500mg		Tab	2	\N	\N
21	\N	2	2022-12-13 12:55:51.115899+00	2022-12-13 12:55:51.115918+00	2	Tab Metformin 1000mg		Tab	2	\N	\N
22	\N	2	2022-12-13 12:55:51.120307+00	2022-12-13 12:55:51.120327+00	2	Tab Glimeperide 1mg		Tab	2	\N	\N
23	\N	2	2022-12-13 12:55:51.125014+00	2022-12-13 12:55:51.125034+00	2	Tab Glimeperide 2mg		Tab	2	\N	\N
24	\N	2	2022-12-13 12:55:51.129959+00	2022-12-13 12:55:51.12998+00	2	Tab PIOGLITAZONE (15mg)+Metformin (500mg)+Glimeperide (2mg)		Tab	2	\N	\N
25	\N	2	2022-12-13 12:55:51.134956+00	2022-12-13 12:55:51.134979+00	2	Tab Voglibose (0.2mg)+Metformin (500mg)+Glimeperide (2mg)		Tab	2	\N	\N
26	\N	2	2022-12-13 12:55:51.139749+00	2022-12-13 12:55:51.13977+00	2	Tab Multivitamin B complex		Tab	3	\N	\N
27	\N	2	2022-12-13 12:55:51.144537+00	2022-12-13 12:55:51.144558+00	2	Tab Iron sulphate + Folic acid		Tab	3	\N	\N
28	\N	2	2022-12-13 12:55:51.149108+00	2022-12-13 12:55:51.149127+00	2	Tab C		Tab	3	\N	\N
29	\N	2	2022-12-13 12:55:51.153843+00	2022-12-13 12:55:51.153866+00	2	Tab Zinc		Tab	3	\N	\N
30	\N	2	2022-12-13 12:55:51.158758+00	2022-12-13 12:55:51.158779+00	2	Tab Calcium+ Vitamin D3		Tab	3	\N	\N
31	\N	2	2022-12-13 12:55:51.162265+00	2022-12-13 12:55:51.16228+00	2	Tab Amoxicillin+ potassium clavunate 625mg		Tab	4	\N	\N
32	\N	2	2022-12-13 12:55:51.165955+00	2022-12-13 12:55:51.165969+00	2	Tab Cefexime 200 mg		Tab	4	\N	\N
33	\N	2	2022-12-13 12:55:51.170128+00	2022-12-13 12:55:51.170142+00	2	Tab Metronidazole 400mg		Tab	4	\N	\N
34	\N	2	2022-12-13 12:55:51.173515+00	2022-12-13 12:55:51.173533+00	2	Tab Fluconazole 150mg		Tab	5	\N	\N
35	\N	2	2022-12-13 12:55:51.1768+00	2022-12-13 12:55:51.176818+00	2	Tab Albendazole 400mg		Tab	6	\N	\N
36	\N	2	2022-12-13 12:55:51.180104+00	2022-12-13 12:55:51.180117+00	2	Tab Paracetamol 650mg		Tab	7	\N	\N
37	\N	2	2022-12-13 12:55:51.183512+00	2022-12-13 12:55:51.183525+00	2	Tab Tramadol 50mg		Tab	7	\N	\N
38	\N	2	2022-12-13 12:55:51.186438+00	2022-12-13 12:55:51.186452+00	2	Tab Diclofenac 100mg		Tab	7	\N	\N
39	\N	2	2022-12-13 12:55:51.189867+00	2022-12-13 12:55:51.189886+00	2	Tab Pregabalin 75mg		Tab	7	\N	\N
40	\N	2	2022-12-13 12:55:51.193612+00	2022-12-13 12:55:51.193627+00	2	Cap Omeprazole 20mg		Cap	8	\N	\N
41	\N	2	2022-12-13 12:55:51.197046+00	2022-12-13 12:55:51.197061+00	2	Tab Lactobacillus		Tab	8	\N	\N
42	\N	2	2022-12-13 12:55:51.200493+00	2022-12-13 12:55:51.200506+00	2	Tab Domperidone		Tab	8	\N	\N
43	\N	2	2022-12-13 12:55:51.203977+00	2022-12-13 12:55:51.203993+00	2	Tab Mefenemic acid + Dicyclomine		Tab	8	\N	\N
44	\N	2	2022-12-13 12:55:51.207105+00	2022-12-13 12:55:51.207119+00	2	Tab Ondansetron		Tab	8	\N	\N
45	\N	2	2022-12-13 12:55:51.210237+00	2022-12-13 12:55:51.21025+00	2	Tab Bisacodyl		Tab	8	\N	\N
46	\N	2	2022-12-13 12:55:51.213596+00	2022-12-13 12:55:51.213609+00	2	Tab Citrizine 10mg		Tab	9	\N	\N
47	\N	2	2022-12-13 12:55:51.216712+00	2022-12-13 12:55:51.216724+00	2	Tab Salbutamol 4mg		Tab	9	\N	\N
48	\N	2	2022-12-13 12:55:51.21986+00	2022-12-13 12:55:51.219874+00	2	Tab Etophylline+ Theophylline		Tab	9	\N	\N
49	\N	2	2022-12-13 12:55:51.222851+00	2022-12-13 12:55:51.222865+00	2	Tab Chlorpheniramine		Tab	9	\N	\N
50	\N	2	2022-12-13 12:55:51.225853+00	2022-12-13 12:55:51.225866+00	2	Tab Amitriptyline 10mg		Tab	10	\N	\N
51	\N	2	2022-12-13 12:55:51.229002+00	2022-12-13 12:55:51.229014+00	2	Tab Risperidone 4mg		Tab	10	\N	\N
52	\N	2	2022-12-13 12:55:51.232209+00	2022-12-13 12:55:51.232226+00	2	Tab TRIHEXPHENYDYL 2mg		Tab	10	\N	\N
53	\N	2	2022-12-13 12:55:51.235174+00	2022-12-13 12:55:51.235187+00	2	Aluminium hydroxide+ magnesium hydroxide syrup		Syrup	11	\N	\N
54	\N	2	2022-12-13 12:55:51.238328+00	2022-12-13 12:55:51.238341+00	2	Ambroxyl/ Chlorpheniramine syrup		Syrup	11	\N	\N
55	\N	2	2022-12-13 12:55:51.241452+00	2022-12-13 12:55:51.241465+00	2	Paracetamol 250mg syrup		Syrup	11	\N	\N
56	\N	2	2022-12-13 12:55:51.24452+00	2022-12-13 12:55:51.244532+00	2	Amoxicillin 228.5mg syrup		Syrup	11	\N	\N
57	\N	2	2022-12-13 12:55:51.24767+00	2022-12-13 12:55:51.247683+00	2	ORS powder		Powder	11	\N	\N
58	\N	2	2022-12-13 12:55:51.250573+00	2022-12-13 12:55:51.250591+00	2	Carboxymethylcellulose eyedrops		EyeDrop	12	\N	\N
59	\N	2	2022-12-13 12:55:51.254251+00	2022-12-13 12:55:51.254264+00	2	Ciprofloxacin eyedrops		EyeDrop	12	\N	\N
60	\N	2	2022-12-13 12:55:51.25741+00	2022-12-13 12:55:51.257424+00	2	Moisturizer		Lotion	13	\N	\N
61	\N	2	2022-12-13 12:55:51.260696+00	2022-12-13 12:55:51.260711+00	2	Miconazole ointment		Lotion	13	\N	\N
62	\N	2	2022-12-13 12:55:51.26448+00	2022-12-13 12:55:51.2645+00	2	Diclofenac gel		Lotion	13	\N	\N
63	\N	2	2022-12-13 12:55:51.268104+00	2022-12-13 12:55:51.26812+00	2	Povidone ointment		Lotion	13	\N	\N
64	\N	2	2022-12-13 12:55:51.271743+00	2022-12-13 12:55:51.271759+00	2	Gamma benzene + cetrimide lotion		Lotion	13	\N	\N
65	\N	2	2022-12-13 12:55:51.275137+00	2022-12-13 12:55:51.275158+00	2	Rotahaler		Inhaler	14	\N	\N
66	\N	2	2022-12-13 12:55:51.278586+00	2022-12-13 12:55:51.278602+00	2	Salbutamol MDI		Inhaler	14	\N	\N
67	\N	2	2022-12-13 12:55:51.282189+00	2022-12-13 12:55:51.282206+00	2	BUDESONIDE MDI		Inhaler	14	\N	\N
68	\N	2	2022-12-13 12:55:51.285988+00	2022-12-13 12:55:51.286004+00	2	Formoterol+ BUDESONIDE Rotacaps		Inhaler	14	\N	\N
70	\N	2	2022-12-29 07:36:34.429285+00	2022-12-29 07:36:34.429308+00	2	Vihddbe	5	Tab	14	\N	\N
71	\N	1	2022-12-29 07:42:52.447832+00	2022-12-29 07:43:45.908149+00	2	Vicks Action 500	3	Tab	8	\N	\N
69	\N	2	2022-12-29 07:29:36.352141+00	2022-12-29 07:44:27.699745+00	2	Vicks Action 500 Sb	500	Tab	12	\N	\N
\.


--
-- Data for Name: application_masters_phc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.application_masters_phc (id, uuid, status, server_created_on, server_modified_on, name, code, created_by_id, modified_by_id, taluk_id, sync_status) FROM stdin;
1	\N	2	2022-12-08 09:25:42.005005+00	2022-12-19 07:46:00.426579+00	INDLAWADI	IND	\N	\N	1	2
4	\N	2	2022-12-29 07:05:05.048563+00	2022-12-29 07:24:22.581972+00	India Sb	5	\N	\N	1	2
5	\N	2	2022-12-29 07:06:02.69205+00	2022-12-29 07:24:48.845465+00	eqff Sb	4554	\N	\N	1	2
\.


--
-- Data for Name: application_masters_state; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.application_masters_state (id, uuid, status, server_created_on, server_modified_on, name, created_by_id, modified_by_id, parent_id, sync_status, code) FROM stdin;
12	\N	2	2022-12-12 17:58:16.13748+00	2022-12-16 09:54:10.81217+00	Karnataka	\N	\N	0	2	KA
\.


--
-- Data for Name: application_masters_subcenter; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.application_masters_subcenter (id, uuid, status, server_created_on, server_modified_on, sync_status, name, code, created_by_id, modified_by_id, phc_id) FROM stdin;
1	\N	2	2022-12-19 08:46:57.213861+00	2022-12-19 08:46:57.213872+00	2	INDLAWADI	I	\N	\N	1
2	\N	2	2022-12-19 08:46:57.215964+00	2022-12-19 08:46:57.215971+00	2	VANAKANAHALLI	V	\N	\N	1
3	\N	2	2022-12-19 08:46:57.217641+00	2022-12-19 08:46:57.217648+00	2	CHIKKAHOSALLI	C	\N	\N	1
4	\N	2	2022-12-29 07:09:30.3828+00	2022-12-29 07:10:02.886588+00	2	Jayadev Sb	2	\N	\N	4
\.


--
-- Data for Name: application_masters_taluk; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.application_masters_taluk (id, uuid, status, server_created_on, server_modified_on, name, created_by_id, district_id, modified_by_id, sync_status, code) FROM stdin;
1	\N	2	2022-12-08 09:25:09.233683+00	2022-12-19 06:16:23.342088+00	Anekal	\N	51	\N	2	AT
\.


--
-- Data for Name: application_masters_village; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.application_masters_village (id, uuid, status, server_created_on, server_modified_on, name, code, created_by_id, modified_by_id, sync_status, subcenter_id) FROM stdin;
1	\N	2	2022-12-19 08:56:55.04065+00	2022-12-19 08:56:55.040659+00	INDLAWADI	IN	\N	\N	2	1
2	\N	2	2022-12-19 08:56:55.042788+00	2022-12-19 08:56:55.042798+00	KADUJAKKANAHALLI	KJ	\N	\N	2	1
3	\N	2	2022-12-19 08:56:55.045117+00	2022-12-19 08:56:55.045125+00	MYSORAMANADODDI	MY	\N	\N	2	1
4	\N	2	2022-12-19 08:56:55.046955+00	2022-12-19 08:56:55.046961+00	BAGGANADODDI	BA	\N	\N	2	1
5	\N	2	2022-12-19 08:56:55.04856+00	2022-12-19 08:56:55.048566+00	TIMMYANADODDI	TH	\N	\N	2	1
6	\N	2	2022-12-19 08:56:55.050139+00	2022-12-19 08:56:55.050145+00	NAGAYANADODDI	NY	\N	\N	2	1
7	\N	2	2022-12-19 08:56:55.051722+00	2022-12-19 08:56:55.051729+00	CHIKKNAHALLI	CK	\N	\N	2	1
8	\N	2	2022-12-19 08:56:55.053364+00	2022-12-19 08:56:55.053371+00	INDLAWADI PURA	ID	\N	\N	2	1
9	\N	2	2022-12-19 08:56:55.055103+00	2022-12-19 08:56:55.055109+00	TIMMASANDRA	TM	\N	\N	2	1
10	\N	2	2022-12-19 08:56:55.057069+00	2022-12-19 08:56:55.057076+00	BANGLADODDI	BN	\N	\N	2	1
11	\N	2	2022-12-19 08:56:55.05902+00	2022-12-19 08:56:55.059027+00	VANAKANAHALLI	VK	\N	\N	2	2
12	\N	2	2022-12-19 08:56:55.060798+00	2022-12-19 08:56:55.060805+00	SOLLORU	SO	\N	\N	2	2
13	\N	2	2022-12-19 08:56:55.062643+00	2022-12-19 08:56:55.06265+00	KALANAYAKANAHALLI	KL	\N	\N	2	2
14	\N	2	2022-12-19 08:56:55.064266+00	2022-12-19 08:56:55.064273+00	SUNAVARA	SU	\N	\N	2	2
15	\N	2	2022-12-19 08:56:55.065902+00	2022-12-19 08:56:55.06591+00	CHODENAHALLI	CO	\N	\N	2	2
16	\N	2	2022-12-19 08:56:55.067656+00	2022-12-19 08:56:55.067662+00	P GOLLAHALLI	PG	\N	\N	2	2
17	\N	2	2022-12-19 08:56:55.069414+00	2022-12-19 08:56:55.06942+00	MENASIGANAHALLI	ME	\N	\N	2	2
18	\N	2	2022-12-19 08:56:55.071406+00	2022-12-19 08:56:55.071418+00	SINGASANDRA	SG	\N	\N	2	2
19	\N	2	2022-12-19 08:56:55.0753+00	2022-12-19 08:56:55.07531+00	KEMPADOMMASANDRA	KD	\N	\N	2	2
20	\N	2	2022-12-19 08:56:55.077473+00	2022-12-19 08:56:55.077492+00	TELAGARAHALLI	TE	\N	\N	2	2
21	\N	2	2022-12-19 08:56:55.07987+00	2022-12-19 08:56:55.079881+00	CHIKKAHOSALLI	CH	\N	\N	2	3
22	\N	2	2022-12-19 08:56:55.082081+00	2022-12-19 08:56:55.082087+00	NALLAYANADODDI	NA	\N	\N	2	3
23	\N	2	2022-12-19 08:56:55.083737+00	2022-12-19 08:56:55.083743+00	TAMMANAYAKANAHALLI	TK	\N	\N	2	3
24	\N	2	2022-12-19 08:56:55.085357+00	2022-12-19 08:56:55.085363+00	CHOODAHALLI	CO	\N	\N	2	3
25	\N	2	2022-12-19 08:56:55.08701+00	2022-12-19 08:56:55.087016+00	KARAKALAGATTA	KG	\N	\N	2	3
26	\N	2	2022-12-19 08:56:55.089692+00	2022-12-19 08:56:55.089704+00	KARAKALAGATTA JANATHA COLONY 	KC	\N	\N	2	3
27	\N	2	2022-12-19 08:56:55.091691+00	2022-12-19 08:56:55.091697+00	AREHALLI	AR	\N	\N	2	3
28	\N	2	2022-12-19 08:56:55.093426+00	2022-12-19 08:56:55.093433+00	LAKSHMIPURA	LP	\N	\N	2	3
29	\N	2	2022-12-19 08:56:55.095684+00	2022-12-19 08:56:55.095691+00	BASAVANAPURA	BA	\N	\N	2	3
30	\N	2	2022-12-19 08:56:55.09735+00	2022-12-19 08:56:55.097357+00	MUTTURU	MU	\N	\N	2	3
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add user	4	add_user
14	Can change user	4	change_user
15	Can delete user	4	delete_user
16	Can view user	4	view_user
17	Can add content type	5	add_contenttype
18	Can change content type	5	change_contenttype
19	Can delete content type	5	delete_contenttype
20	Can view content type	5	view_contenttype
21	Can add session	6	add_session
22	Can change session	6	change_session
23	Can delete session	6	delete_session
24	Can view session	6	view_session
25	Can add district	7	add_district
26	Can change district	7	change_district
27	Can delete district	7	delete_district
28	Can view district	7	view_district
29	Can add phc	8	add_phc
30	Can change phc	8	change_phc
31	Can delete phc	8	delete_phc
32	Can view phc	8	view_phc
33	Can add village	9	add_village
34	Can change village	9	change_village
35	Can delete village	9	delete_village
36	Can view village	9	view_village
37	Can add taluk	10	add_taluk
38	Can change taluk	10	change_taluk
39	Can delete taluk	10	delete_taluk
40	Can view taluk	10	view_taluk
41	Can add state	11	add_state
42	Can change state	11	change_state
43	Can delete state	11	delete_state
44	Can view state	11	view_state
45	Can add master lookup	12	add_masterlookup
46	Can change master lookup	12	change_masterlookup
47	Can delete master lookup	12	delete_masterlookup
48	Can view master lookup	12	view_masterlookup
49	Can add app content	13	add_appcontent
50	Can change app content	13	change_appcontent
51	Can delete app content	13	delete_appcontent
52	Can view app content	13	view_appcontent
53	Can add medicines	14	add_medicines
54	Can change medicines	14	change_medicines
55	Can delete medicines	14	delete_medicines
56	Can view medicines	14	view_medicines
57	Can add treatments	15	add_treatments
58	Can change treatments	15	change_treatments
59	Can delete treatments	15	delete_treatments
60	Can view treatments	15	view_treatments
61	Can add scanned_ report	16	add_scanned_report
62	Can change scanned_ report	16	change_scanned_report
63	Can delete scanned_ report	16	delete_scanned_report
64	Can view scanned_ report	16	view_scanned_report
65	Can add prescription	17	add_prescription
66	Can change prescription	17	change_prescription
67	Can delete prescription	17	delete_prescription
68	Can view prescription	17	view_prescription
69	Can add patients	18	add_patients
70	Can change patients	18	change_patients
71	Can delete patients	18	delete_patients
72	Can view patients	18	view_patients
73	Can add diagnosis	19	add_diagnosis
74	Can change diagnosis	19	change_diagnosis
75	Can delete diagnosis	19	delete_diagnosis
76	Can view diagnosis	19	view_diagnosis
77	Can add comorbid	20	add_comorbid
78	Can change comorbid	20	change_comorbid
79	Can delete comorbid	20	delete_comorbid
80	Can view comorbid	20	view_comorbid
81	Can add user profile	21	add_userprofile
82	Can change user profile	21	change_userprofile
83	Can delete user profile	21	delete_userprofile
84	Can view user profile	21	view_userprofile
85	Can add comorbid	22	add_comorbid
86	Can change comorbid	22	change_comorbid
87	Can delete comorbid	22	delete_comorbid
88	Can view comorbid	22	view_comorbid
89	Can add medicines	23	add_medicines
90	Can change medicines	23	change_medicines
91	Can delete medicines	23	delete_medicines
92	Can view medicines	23	view_medicines
93	Can add dosage	24	add_dosage
94	Can change dosage	24	change_dosage
95	Can delete dosage	24	delete_dosage
96	Can view dosage	24	view_dosage
97	Can add subcenter	25	add_subcenter
98	Can change subcenter	25	change_subcenter
99	Can delete subcenter	25	delete_subcenter
100	Can view subcenter	25	view_subcenter
101	Can add category	26	add_category
102	Can change category	26	change_category
103	Can delete category	26	delete_category
104	Can view category	26	view_category
105	Can add home visit	27	add_homevisit
106	Can change home visit	27	change_homevisit
107	Can delete home visit	27	delete_homevisit
108	Can view home visit	27	view_homevisit
109	Can add medicine stock	28	add_medicinestock
110	Can change medicine stock	28	change_medicinestock
111	Can delete medicine stock	28	delete_medicinestock
112	Can view medicine stock	28	view_medicinestock
113	Can add drug dispensation	29	add_drugdispensation
114	Can change drug dispensation	29	change_drugdispensation
115	Can delete drug dispensation	29	delete_drugdispensation
116	Can view drug dispensation	29	view_drugdispensation
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
1	pbkdf2_sha256$260000$NKSdsMPsAEJCcu74i85u1z$BLWWoebe4DHld6kmvSljA/2llNg+w93Ijbk8hXLKM84=	2022-12-01 13:40:41.069437+00	t	admin				t	t	2022-09-26 06:40:56.648576+00
5	pbkdf2_sha256$260000$e4ngCZfUIhp8HezLp6zuqD$OUki2eI6HvsAPBNN50igak+1XCApcSJr2clbNsPofDo=	\N	f	hw	health worker		dev.ashish@thesocialbytes.com	t	t	2022-12-11 12:18:48+00
4	pbkdf2_sha256$260000$vx2Y6kELLec5ESrc0YVrW8$a7yr2S6PUW8FBVf1OvKn8XZEHNaGy/QiCHQYdDZceDA=	\N	f	doctor1	doctor1		teachertest986@gmail.com	t	t	2022-12-11 12:17:49+00
2	pbkdf2_sha256$260000$pidIqX9mEaf5NyTiED0nfc$Ly6cpdbHHw7c01Yn50AU7JCQsy2gyqBfecAiHO5V0JM=	2022-12-12 16:01:07.810258+00	t	admin2				t	t	2022-12-08 07:06:12.139389+00
6	pbkdf2_sha256$260000$IcDZqv3gkD5AJGPAUXfvka$EugiLz4L51Ls5icyJB2/OSXiRTtBgbvVCIpB2uq6ImY=	\N	f	hw01				f	t	2022-12-29 05:46:42.280993+00
21	pbkdf2_sha256$260000$z9zpdGYIAUnAdmH3iQgeUt$VqEBccZjVEOmhdm/Wa65XAZsJA6J+vGT+TNME9JUTak=	\N	f	HwEmy15	Varalakshmi.M		varalakshmim@onebillionliterates.org	t	t	2023-01-17 09:21:51+00
22	pbkdf2_sha256$260000$zKwuyDk3gc0v4rYwD21iTY$1pfLcGg0zX7AMdcvAxnQzcJKf0Tl89E27T5o99mf+IE=	\N	f	HwEmy16	Manjula.S		manjulas@onebillionliterates.org	t	t	2023-01-17 09:22:36+00
23	pbkdf2_sha256$260000$QHWteI2kMbBAmwHu0dCYa1$fcgLcGj+r8XbNBByz8uqwuiNz0oiZWsHoQQxT99UN+4=	\N	f	HwEmy17	Anvitha		anvithas@onebillionliterates.org	t	t	2023-01-17 09:23:17+00
7	pbkdf2_sha256$260000$5poK8T3LZsuqJufQUiIwnK$7rG0eTPyVdg/FmO0bLMrXkyTv/vtABA84F1xXaMPJGo=	\N	f	HwEmy01	Lakshmibhai		lakshmibaic@onebillionliterates.org	t	t	2023-01-17 09:04:29+00
8	pbkdf2_sha256$260000$N8O83uzGzexdkNqfMFvF05$/F0xzmwoZohq8YzOd4cKWhi0kkOuZanVY/ZVYkEiui0=	\N	f	HwEmy02	Ramya		ramyas@onebillionliterates.org	t	t	2023-01-17 09:05:53+00
9	pbkdf2_sha256$260000$IknL6coPtFtXN10E3TFzo8$Yeb9IOGNz0Gzc0FTji/P+c1cQxOPybUAMZDlW73pTU8=	\N	f	HwEmy03	Shashikala.C		shashikalac@onebillionliterates.org	t	t	2023-01-17 09:06:34+00
10	pbkdf2_sha256$260000$GCJuyqiEun02nkSKoY2G5Q$A6BEsWePvAt9q4fNedQ1KJB2afzqiOK/BYnWHBS0B6E=	\N	f	HwEmy04	Yashodha		yashodhav@onebillionliterates.org	t	t	2023-01-17 09:07:57+00
11	pbkdf2_sha256$260000$W0Kph2nxA4jVYZcN97H6mR$BvApkv+5FLv+8nk8f4voZT3SFVygyDJ8utJKEJ5RheE=	\N	f	HwEmy05	Kasthuri		kasturic@onebillionliterates.org	t	t	2023-01-17 09:08:44+00
12	pbkdf2_sha256$260000$mggEOVzopoaIxsaKgYN4Mq$yzcEPKUnhaYQwMcZyElVGLNRff/yd5+mubcPKpfG92I=	\N	f	HwEmy06	Vidyashree		vidhyasreer@onebillionliterates.org	t	t	2023-01-17 09:09:22+00
13	pbkdf2_sha256$260000$6dkOjFRFFGNA2jLcmXC2qo$BU2Z6VRbzuLx4JvcOD7tp7vxA3Vns8rbzazIwlMtxQQ=	\N	f	HwEmy07	Savitha.G		savithag@onebillionliterates.org	t	t	2023-01-17 09:13:07+00
24	pbkdf2_sha256$260000$1okYr8UH8c6Lkhs2AWKVhA$Jcba3iQ6oeceYkY89s8m0R1Qcu7uZwMHcCnM0SQDuMU=	\N	f	HwEmy18	Ankitha		ankitak@onebillionliterates.org	t	t	2023-01-17 09:24:12+00
14	pbkdf2_sha256$260000$SvqJEpviHnQQmwkPYdabQG$uOrY8p19oovWKsQGK1jmjAnCKpBkR+W0/ARYNaHtgcQ=	\N	f	HwEmy08	Vedavathi.N		vedhavathin@onebillionliterates.org	t	t	2023-01-17 09:14:03+00
15	pbkdf2_sha256$260000$hJZOD3TF5mydGJKWMP73NL$vvpnCPZYs7WthGNMX3KaX/10Uxh2X9kW9pxlS3nRlOc=	\N	f	HwEmy09	Pushpa.R (Old)		pushpar@onebillionliterates.org	t	t	2023-01-17 09:15:26+00
16	pbkdf2_sha256$260000$dJgbMYXCvs0PPYsH2LMgsW$V8mgY78bjkHPmAmxvfz8LSg5EH1L3bB+COEZsfhDILs=	\N	f	HwEmy10	Shashikala. R Biocon		shashikalab@onebillionliterates.org	t	t	2023-01-17 09:16:20+00
17	pbkdf2_sha256$260000$NaIdKuItw4FPSwamKqtkZR$oVWEmUjNA2UJE+2LRDjCiLQS5D6UqGdAmuWshNQ7Qz4=	\N	f	HwEmy11	Radha.V		radhav@onebillionliterates.org	t	t	2023-01-17 09:17:26+00
18	pbkdf2_sha256$260000$NF5DsEzxcYmflLaiyABhtK$A1jeHWBjp8RMrcR3O1T5TuVQPHmnQiI7n4p+5H02+og=	\N	f	HwEmy12	Sukanya.V		sukanyav@onebillionliterates.org	t	t	2023-01-17 09:18:12+00
19	pbkdf2_sha256$260000$klvkxG0LfBp0AdEhF8KsU7$YGadpKFyExG7Gi6IgPBfapBMe/UHc+WLHnnFE2eescU=	\N	f	HwEmy13	Pushpa.R (New)		pushpad@onebillionliterates.org	t	t	2023-01-17 09:19:14+00
25	pbkdf2_sha256$260000$A6vGT77VJtgk3amerTNze0$MzdHH8cpuqOGMfUNHFQrzIaFV+EwZHgveugctKb2+N0=	\N	f	HwEmy19	Channakeshava		channakeshavam@onebillionliterates.org	t	t	2023-01-17 09:25:34+00
26	pbkdf2_sha256$260000$FUblemL7S2IrxPpRtu3b3V$xT4Bts8MwwWJnbR5Q9di8zIvklJe6ewxD5N3QLg4Qa4=	\N	f	HwEmy20	Sachin		saching@onebillionliterates.org	t	t	2023-01-17 09:26:18+00
20	pbkdf2_sha256$260000$Adxtxxe89bRqfR1viYnilO$sH5wXzkUVf4GB+lB7eRPbYdEn5ySYtxVecvQ3Ki3fNU=	\N	f	HwEmy14	Savitha. V		savithav@onebillionliterates.org	t	t	2023-01-17 09:20:12+00
3	pbkdf2_sha256$260000$P4taY1dm9gB0SqE6Is0mx5$lUiH6MYw0eUoMk9gC8StZgVT/reRmmgSj52wdqksDHA=	2023-01-19 06:19:22.719405+00	t	hmadmin				t	t	2022-12-09 14:33:17+00
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2022-12-08 09:24:11.268704+00	1	Andhra Pradesh	1	[{"added": {}}]	11	1
2	2022-12-08 09:24:41.17442+00	1	Visakhapatnam	1	[{"added": {}}]	7	1
3	2022-12-08 09:25:09.235068+00	1	Anakapalle	1	[{"added": {}}]	10	1
4	2022-12-08 09:25:42.006871+00	1	JSS Side	1	[{"added": {}}]	8	1
5	2022-12-08 09:26:40.514273+00	1	Allikhanudupalem	1	[{"added": {}}]	9	1
6	2022-12-08 09:27:08.231533+00	1	admin2	1	[{"added": {}}]	21	1
7	2022-12-08 14:09:21.015373+00	1	Dari ambatoli	1	[{"added": {}}]	12	2
8	2022-12-08 14:09:31.781033+00	2	Tangartoli	1	[{"added": {}}]	12	2
9	2022-12-08 14:11:24.076268+00	1	Lalmati	1	[{"added": {}}]	18	2
10	2022-12-08 14:14:27.377804+00	1	Lalmati	2	[{"changed": {"fields": ["Patient uuid"]}}]	18	2
11	2022-12-08 18:28:57.091414+00	1	Dari ambatoli	1	[{"added": {}}]	14	2
12	2022-12-08 18:29:12.480797+00	2	Tangartoli	1	[{"added": {}}]	14	2
13	2022-12-09 05:22:49.981921+00	1	Lalmati	3		18	2
14	2022-12-09 06:07:50.499469+00	2	ndcs	2	[{"changed": {"fields": ["Name"]}}]	12	2
15	2022-12-09 06:08:09.754857+00	3	weww	1	[{"added": {}}]	12	2
16	2022-12-09 06:09:00.126375+00	2	ndcs	2	[{"changed": {"fields": ["Parent"]}}]	12	2
17	2022-12-09 06:20:22.608302+00	3	weww	3		12	2
18	2022-12-09 06:20:22.613648+00	2	ndcs	3		12	2
19	2022-12-09 06:20:22.616622+00	1	Dari ambatoli	3		12	2
22	2022-12-09 06:40:29.923284+00	2	Diagnosis object (2)	3		19	2
23	2022-12-09 06:40:49.624096+00	6	RUHI	3		18	2
24	2022-12-09 06:41:29.069789+00	2	Tangartoli	3		14	2
25	2022-12-09 06:41:29.074419+00	1	Dari ambatoli	3		14	2
26	2022-12-09 06:41:52.344178+00	1	Scanned_Report object (1)	3		16	2
27	2022-12-09 06:42:07.006746+00	1	Treatments object (1)	3		15	2
28	2022-12-09 06:51:13.477749+00	3	weww	3		12	2
29	2022-12-09 06:51:13.48199+00	2	ndcs	3		12	2
30	2022-12-09 06:51:13.484589+00	1	Dari ambatoli	3		12	2
31	2022-12-09 07:30:48.738793+00	4	ndcs	1	[{"added": {}}]	12	2
32	2022-12-09 07:31:06.054471+00	5	Tangartoli	1	[{"added": {}}]	12	2
33	2022-12-09 07:55:41.274466+00	1	Dari ambatoli	1	[{"added": {}}]	20	2
34	2022-12-09 15:43:08.756468+00	6	patient_visit_type	1	[{"added": {}}]	12	2
35	2022-12-11 12:17:50.079575+00	4	doctor1	1	[{"added": {}}]	4	3
36	2022-12-11 12:18:11.066594+00	4	doctor1	2	[{"changed": {"fields": ["First name"]}}]	4	3
37	2022-12-11 12:18:48.745894+00	5	hw	1	[{"added": {}}]	4	3
38	2022-12-11 12:19:26.119191+00	5	hw	2	[{"changed": {"fields": ["First name", "Last name"]}}]	4	3
39	2022-12-11 12:20:27.264085+00	4	doctor1	2	[{"changed": {"fields": ["Email address"]}}]	4	3
40	2022-12-11 12:20:48.801746+00	4	doctor1	2	[{"changed": {"fields": ["Staff status"]}}]	4	3
41	2022-12-11 12:21:09.703535+00	5	hw	2	[{"changed": {"fields": ["Staff status"]}}]	4	3
42	2022-12-11 12:22:46.533767+00	5	hw	2	[{"changed": {"fields": ["Last name", "Email address"]}}]	4	3
43	2022-12-11 12:49:12.193391+00	4	doctor1	2	[]	4	3
44	2022-12-12 05:58:39.589186+00	2	hw	1	[{"added": {}}]	21	3
45	2022-12-12 05:59:10.033079+00	3	doctor1	1	[{"added": {}}]	21	3
46	2022-12-12 05:59:21.410668+00	3	doctor1	2	[{"changed": {"fields": ["User type"]}}]	21	3
47	2022-12-12 07:22:28.28391+00	10	Alexa	1	[{"added": {}}]	18	3
48	2022-12-12 11:32:00.996382+00	1	Dari ambatoli	3		20	3
49	2022-12-12 16:06:14.802455+00	1	ASTHMA	1	new through import_export	22	2
50	2022-12-12 16:06:14.806328+00	2	CHRONIC KIDNEY DISEASE	1	new through import_export	22	2
51	2022-12-12 16:06:14.808738+00	3	CHRONIC LIVER DISEASE	1	new through import_export	22	2
52	2022-12-12 16:06:14.81111+00	4	CORONARY ARTERY DISEASE	1	new through import_export	22	2
53	2022-12-12 16:06:14.81369+00	5	COPD	1	new through import_export	22	2
54	2022-12-12 16:06:14.816372+00	6	ARTHRITIS	1	new through import_export	22	2
55	2022-12-12 16:06:14.818806+00	7	RHEUMATOID ARTHRITIS	1	new through import_export	22	2
56	2022-12-12 16:06:14.821273+00	8	EPILEPSY 	1	new through import_export	22	2
57	2022-12-12 16:06:14.823816+00	9	PSYCHIATRIC DISORDER	1	new through import_export	22	2
58	2022-12-12 16:06:14.826773+00	10	MENSTRUAL DISORDER	1	new through import_export	22	2
59	2022-12-12 16:06:14.829525+00	11	ANEMIA 	1	new through import_export	22	2
60	2022-12-12 16:06:14.832286+00	12	DVT	1	new through import_export	22	2
61	2022-12-12 16:06:14.835087+00	13	VARICOSE VEINS 	1	new through import_export	22	2
62	2022-12-12 16:06:14.83792+00	14	RENAL DISORDERS	1	new through import_export	22	2
63	2022-12-12 16:06:14.840684+00	15	TUBERCULOSIS	1	new through import_export	22	2
64	2022-12-12 16:06:14.843515+00	16	THYROID DISORDER	1	new through import_export	22	2
65	2022-12-12 16:06:14.846923+00	17	DRUG DISORDER	1	new through import_export	22	2
66	2022-12-12 16:07:57.229723+00	5	KNOWN HTN	2	[{"changed": {"fields": ["Name"]}}]	12	2
67	2022-12-12 16:08:32.986008+00	7	KNOWN DM	1	[{"added": {}}]	12	2
68	2022-12-12 16:09:19.784345+00	8	NEW HTN	1	[{"added": {}}]	12	2
69	2022-12-12 16:09:33.471678+00	9	NEW DM	1	[{"added": {}}]	12	2
70	2022-12-12 16:10:08.37301+00	10	HTN	1	[{"added": {}}]	12	2
71	2022-12-12 16:10:28.102614+00	11	DM	1	[{"added": {}}]	12	2
72	2022-12-12 16:15:07.585412+00	12	HIV	1	[{"added": {}}]	12	2
73	2022-12-12 16:27:53.554655+00	2	Assam	1	[{"added": {}}]	11	2
74	2022-12-12 16:28:18.66267+00	3	Bihar	1	[{"added": {}}]	11	2
75	2022-12-12 16:28:29.520099+00	4	Chhattisgarh	1	[{"added": {}}]	11	2
76	2022-12-12 16:28:45.743313+00	5	Delhi & NCR	1	[{"added": {}}]	11	2
77	2022-12-12 16:29:02.396418+00	6	Delhi & NCR (Haryana)	1	[{"added": {}}]	11	2
78	2022-12-12 16:29:14.163577+00	7	Delhi & NCR (U.P)	1	[{"added": {}}]	11	2
79	2022-12-12 17:58:16.167784+00	8	Goa	1	new through import_export	11	2
80	2022-12-12 17:58:16.171704+00	9	Gujarat	1	new through import_export	11	2
81	2022-12-12 17:58:16.175347+00	10	Himachal Pradesh	1	new through import_export	11	2
82	2022-12-12 17:58:16.179286+00	11	Jharkhand	1	new through import_export	11	2
83	2022-12-12 17:58:16.183061+00	12	Karnataka	1	new through import_export	11	2
84	2022-12-12 17:58:16.186907+00	13	Kerala	1	new through import_export	11	2
85	2022-12-12 17:58:16.193323+00	14	Ladakh	1	new through import_export	11	2
86	2022-12-12 17:58:16.19724+00	15	Madhya Pradesh	1	new through import_export	11	2
87	2022-12-12 17:58:16.200973+00	16	Maharashtra	1	new through import_export	11	2
88	2022-12-12 17:58:16.204643+00	17	Odisha	1	new through import_export	11	2
89	2022-12-12 17:58:16.208414+00	18	Punjab	1	new through import_export	11	2
90	2022-12-12 17:58:16.212266+00	19	Rajasthan	1	new through import_export	11	2
91	2022-12-12 17:58:16.216027+00	20	Tamil Nadu	1	new through import_export	11	2
777	2022-12-13 12:15:40.374445+00	58	BALLARI	3		7	3
92	2022-12-12 17:58:16.219584+00	21	Telangana	1	new through import_export	11	2
93	2022-12-12 17:58:16.222459+00	22	Uttar Pradesh	1	new through import_export	11	2
94	2022-12-12 17:58:16.224923+00	23	Uttarakhand	1	new through import_export	11	2
95	2022-12-12 17:58:16.227406+00	24	West Bengal	1	new through import_export	11	2
96	2022-12-12 18:10:07.261936+00	2	Vijyanagaram	1	new through import_export	7	2
97	2022-12-12 18:10:07.265067+00	3	Parvathipuram	1	new through import_export	7	2
98	2022-12-12 18:10:07.267748+00	4	Kamrup Metro	1	new through import_export	7	2
99	2022-12-12 18:10:07.270029+00	5	Aurangabad	1	new through import_export	7	2
100	2022-12-12 18:10:07.272384+00	6	Buxar	1	new through import_export	7	2
101	2022-12-12 18:10:07.274653+00	7	Darbhanga	1	new through import_export	7	2
102	2022-12-12 18:10:07.277009+00	8	Madhubani	1	new through import_export	7	2
103	2022-12-12 18:10:07.27959+00	9	Muzaffarpur	1	new through import_export	7	2
104	2022-12-12 18:10:07.282254+00	10	Patna	1	new through import_export	7	2
105	2022-12-12 18:10:07.284656+00	11	RAIGARH	1	new through import_export	7	2
106	2022-12-12 18:10:07.286929+00	12	Gautam Buddha Nagar	1	new through import_export	7	2
107	2022-12-12 18:10:07.289239+00	13	SOUTH WEST	1	new through import_export	7	2
108	2022-12-12 18:10:07.291505+00	14	SOUTH	1	new through import_export	7	2
109	2022-12-12 18:10:07.293954+00	15	Faridabad	1	new through import_export	7	2
110	2022-12-12 18:10:07.296512+00	16	Rohtak	1	new through import_export	7	2
111	2022-12-12 18:10:07.299143+00	17	South Delhi	1	new through import_export	7	2
112	2022-12-12 18:10:07.301776+00	18	GURUGRAM	1	new through import_export	7	2
113	2022-12-12 18:10:07.304486+00	19	JHAJJAR	1	new through import_export	7	2
114	2022-12-12 18:10:07.307734+00	20	Delhi & NCR(UP)	1	new through import_export	7	2
115	2022-12-12 18:10:07.311228+00	21	North-Goa	1	new through import_export	7	2
116	2022-12-12 18:10:07.314557+00	22	Ahmedabad	1	new through import_export	7	2
117	2022-12-12 18:10:07.317977+00	23	Bharuch	1	new through import_export	7	2
118	2022-12-12 18:10:07.321257+00	24	Mehsana	1	new through import_export	7	2
119	2022-12-12 18:10:07.324452+00	25	surat	1	new through import_export	7	2
120	2022-12-12 18:10:07.327848+00	26	Surendrnagar	1	new through import_export	7	2
121	2022-12-12 18:10:07.331044+00	27	VADODARA	1	new through import_export	7	2
122	2022-12-12 18:10:07.33415+00	28	PANCHMAHAL	1	new through import_export	7	2
123	2022-12-12 18:10:07.336885+00	29	Anand	1	new through import_export	7	2
124	2022-12-12 18:10:07.339398+00	30	Jamnagar	1	new through import_export	7	2
125	2022-12-12 18:10:07.341852+00	31	Devbhoomi Dwarka	1	new through import_export	7	2
126	2022-12-12 18:10:07.34434+00	32	GIR SOMNATH	1	new through import_export	7	2
127	2022-12-12 18:10:07.347105+00	33	Dahod	1	new through import_export	7	2
128	2022-12-12 18:10:07.350055+00	34	Mahisagar	1	new through import_export	7	2
129	2022-12-12 18:10:07.353156+00	35	Kheda	1	new through import_export	7	2
130	2022-12-12 18:10:07.3563+00	36	Kutch	1	new through import_export	7	2
131	2022-12-12 18:10:07.361572+00	37	Amreli	1	new through import_export	7	2
132	2022-12-12 18:10:07.366409+00	38	Morbi	1	new through import_export	7	2
133	2022-12-12 18:10:07.370972+00	39	Chota Udaipur	1	new through import_export	7	2
134	2022-12-12 18:10:07.374017+00	40	HAMIRPUR	1	new through import_export	7	2
135	2022-12-12 18:10:07.376936+00	41	KANGRA	1	new through import_export	7	2
136	2022-12-12 18:10:07.380026+00	42	Kinnaur	1	new through import_export	7	2
137	2022-12-12 18:10:07.383109+00	43	KULLU	1	new through import_export	7	2
138	2022-12-12 18:10:07.386012+00	44	MANDI	1	new through import_export	7	2
139	2022-12-12 18:10:07.388903+00	45	Shimla	1	new through import_export	7	2
140	2022-12-12 18:10:07.391722+00	46	Solan	1	new through import_export	7	2
141	2022-12-12 18:10:07.394491+00	47	Una	1	new through import_export	7	2
142	2022-12-12 18:10:07.397618+00	48	SHIMLA	1	new through import_export	7	2
143	2022-12-12 18:10:07.40083+00	49	GODDA	1	new through import_export	7	2
144	2022-12-12 18:10:07.403884+00	50	Bangalore	1	new through import_export	7	2
145	2022-12-12 18:10:07.407365+00	51	Bangalore Rural	1	new through import_export	7	2
146	2022-12-12 18:10:07.411032+00	52	Bangalore Urban	1	new through import_export	7	2
147	2022-12-12 18:10:07.414402+00	53	Chamarajanagar	1	new through import_export	7	2
148	2022-12-12 18:10:07.417769+00	54	Mysore	1	new through import_export	7	2
149	2022-12-12 18:10:07.421267+00	55	Raichur	1	new through import_export	7	2
150	2022-12-12 18:10:07.424464+00	56	SANDUR	1	new through import_export	7	2
151	2022-12-12 18:10:07.427419+00	57	VIJAY NAGAR	1	new through import_export	7	2
152	2022-12-12 18:10:07.430597+00	58	BALLARI	1	new through import_export	7	2
153	2022-12-12 18:10:07.43415+00	59	VIJAYANAGARA	1	new through import_export	7	2
154	2022-12-12 18:10:07.437336+00	60	Bangalore.G	1	new through import_export	7	2
155	2022-12-12 18:10:07.440533+00	61	Tumakur.G	1	new through import_export	7	2
156	2022-12-12 18:10:07.444017+00	62	BELLARI	1	new through import_export	7	2
157	2022-12-12 18:10:07.447483+00	63	Trivandrum	1	new through import_export	7	2
158	2022-12-12 18:10:07.450446+00	64	Leh	1	new through import_export	7	2
159	2022-12-12 18:10:07.453453+00	65	Betul	1	new through import_export	7	2
160	2022-12-12 18:10:07.456627+00	66	Dhar	1	new through import_export	7	2
161	2022-12-12 18:10:07.459876+00	67	Indore	1	new through import_export	7	2
162	2022-12-12 18:10:07.4629+00	68	KHANDWA	1	new through import_export	7	2
163	2022-12-12 18:10:07.466242+00	69	BHIND	1	new through import_export	7	2
164	2022-12-12 18:10:07.469084+00	70	Ahmednagar	1	new through import_export	7	2
165	2022-12-12 18:10:07.471702+00	71	CHANDRAPUR	1	new through import_export	7	2
166	2022-12-12 18:10:07.474302+00	72	Gondia	1	new through import_export	7	2
167	2022-12-12 18:10:07.476909+00	73	Mumbai	1	new through import_export	7	2
168	2022-12-12 18:10:07.480063+00	74	Mumbai City	1	new through import_export	7	2
169	2022-12-12 18:10:07.483257+00	75	Pune	1	new through import_export	7	2
170	2022-12-12 18:10:07.486179+00	76	Raigad	1	new through import_export	7	2
171	2022-12-12 18:10:07.489129+00	77	Satara	1	new through import_export	7	2
172	2022-12-12 18:10:07.492328+00	78	Thane	1	new through import_export	7	2
173	2022-12-12 18:10:07.495464+00	79	Satara	1	new through import_export	7	2
174	2022-12-12 18:10:07.498812+00	80	Nasik	1	new through import_export	7	2
175	2022-12-12 18:10:07.501818+00	81	Raigad	1	new through import_export	7	2
176	2022-12-12 18:10:07.505151+00	82	Palghar	1	new through import_export	7	2
1061	2022-12-19 07:42:44.242583+00	17	monu	3		18	3
177	2022-12-12 18:10:07.508508+00	83	Pune City	1	new through import_export	7	2
178	2022-12-12 18:10:07.511476+00	84	Angul	1	new through import_export	7	2
179	2022-12-12 18:10:07.514593+00	85	Balangir	1	new through import_export	7	2
180	2022-12-12 18:10:07.517545+00	86	Bhadrak	1	new through import_export	7	2
181	2022-12-12 18:10:07.520461+00	87	Jagatsinghpur	1	new through import_export	7	2
182	2022-12-12 18:10:07.523577+00	88	Koraput	1	new through import_export	7	2
183	2022-12-12 18:10:07.526491+00	89	PURI	1	new through import_export	7	2
184	2022-12-12 18:10:07.529409+00	90	Keonjhar	1	new through import_export	7	2
185	2022-12-12 18:10:07.532623+00	91	Sundargarh	1	new through import_export	7	2
186	2022-12-12 18:10:07.535634+00	92	Sambalpur	1	new through import_export	7	2
187	2022-12-12 18:10:07.538566+00	93	Solan	1	new through import_export	7	2
188	2022-12-12 18:10:07.54144+00	94	Ropar	1	new through import_export	7	2
189	2022-12-12 18:10:07.544429+00	95	SAS Mohali	1	new through import_export	7	2
190	2022-12-12 18:10:07.547836+00	96	Bikaner	1	new through import_export	7	2
191	2022-12-12 18:10:07.551236+00	97	Churu	1	new through import_export	7	2
192	2022-12-12 18:10:07.554751+00	98	Baran	1	new through import_export	7	2
193	2022-12-12 18:10:07.55814+00	99	Chennai	1	new through import_export	7	2
194	2022-12-12 18:10:07.561136+00	100	DINDIGUL	1	new through import_export	7	2
195	2022-12-12 18:10:07.564156+00	101	Kancheepuram	1	new through import_export	7	2
196	2022-12-12 18:10:07.567181+00	102	Kanchipuram	1	new through import_export	7	2
197	2022-12-12 18:10:07.570341+00	103	MADURAI	1	new through import_export	7	2
198	2022-12-12 18:10:07.573282+00	104	RAMANATHAPURAM	1	new through import_export	7	2
199	2022-12-12 18:10:07.576073+00	105	Thiruvallur	1	new through import_export	7	2
200	2022-12-12 18:10:07.578989+00	106	Tirunelveli	1	new through import_export	7	2
201	2022-12-12 18:10:07.58252+00	107	Tiruvallur	1	new through import_export	7	2
202	2022-12-12 18:10:07.585557+00	108	THIRUVALUR	1	new through import_export	7	2
203	2022-12-12 18:10:07.588478+00	109	Asifabad	1	new through import_export	7	2
204	2022-12-12 18:10:07.591384+00	110	Mancherial	1	new through import_export	7	2
205	2022-12-12 18:10:07.594286+00	111	Sangareddy	1	new through import_export	7	2
206	2022-12-12 18:10:07.597348+00	112	Ambedkar Nagar	1	new through import_export	7	2
207	2022-12-12 18:10:07.600553+00	113	Amroha	1	new through import_export	7	2
208	2022-12-12 18:10:07.603729+00	114	Bulandshahr	1	new through import_export	7	2
209	2022-12-12 18:10:07.606774+00	115	Mathura	1	new through import_export	7	2
210	2022-12-12 18:10:07.609692+00	116	Moradabad	1	new through import_export	7	2
211	2022-12-12 18:10:07.612645+00	117	Saharanpur	1	new through import_export	7	2
212	2022-12-12 18:10:07.615894+00	118	LUCKNOW	1	new through import_export	7	2
213	2022-12-12 18:10:07.618849+00	119	Chamoli	1	new through import_export	7	2
214	2022-12-12 18:10:07.62178+00	120	Dehradun	1	new through import_export	7	2
215	2022-12-12 18:10:07.624629+00	121	Pauri Garhwal	1	new through import_export	7	2
216	2022-12-12 18:10:07.627495+00	122	RUDRAPRAYAG	1	new through import_export	7	2
217	2022-12-12 18:10:07.630498+00	123	Tehri	1	new through import_export	7	2
218	2022-12-12 18:10:07.633595+00	124	Uttarkashi	1	new through import_export	7	2
219	2022-12-12 18:10:07.63636+00	125	Uttarakashi	1	new through import_export	7	2
220	2022-12-12 18:10:07.639262+00	126	Nainital	1	new through import_export	7	2
221	2022-12-12 18:10:07.642214+00	127	Bankura	1	new through import_export	7	2
222	2022-12-12 18:10:07.645108+00	128	Howrah	1	new through import_export	7	2
223	2022-12-12 18:10:07.648379+00	129	Kolkata	1	new through import_export	7	2
224	2022-12-12 18:10:07.651368+00	130	Murshidabad	1	new through import_export	7	2
225	2022-12-12 18:10:07.654431+00	131	Paschim Bardhaman	1	new through import_export	7	2
226	2022-12-12 18:10:07.657255+00	132	Purba Bardhaman	1	new through import_export	7	2
227	2022-12-12 18:10:07.660158+00	133	South 24 Pgs	1	new through import_export	7	2
228	2022-12-12 18:10:07.663389+00	134	Paschim Barddhaman	1	new through import_export	7	2
229	2022-12-12 18:11:21.740363+00	1	Taluk 1	2	[{"changed": {"fields": ["Name"]}}]	10	2
230	2022-12-12 18:12:35.599123+00	1	INDLAWADI	2	[{"changed": {"fields": ["Name"]}}]	8	2
231	2022-12-12 18:13:25.166759+00	2	VANAKANAHALLI	1	[{"added": {}}]	8	2
232	2022-12-12 18:14:49.334091+00	3	CHIKKAHOSALLI	1	[{"added": {}}]	8	2
233	2022-12-12 18:16:10.247455+00	1	INDLAWADI	2	[{"changed": {"fields": ["Phc code"]}}]	8	2
234	2022-12-12 18:16:15.383986+00	2	VANAKANAHALLI	2	[{"changed": {"fields": ["Phc code"]}}]	8	2
235	2022-12-12 18:16:20.352916+00	3	CHIKKAHOSALLI	2	[{"changed": {"fields": ["Phc code"]}}]	8	2
236	2022-12-12 18:23:59.489419+00	2	KADUJAKKANAHALLI	1	new through import_export	9	2
237	2022-12-12 18:23:59.491977+00	3	MYSORAMANADODDI	1	new through import_export	9	2
238	2022-12-12 18:23:59.49455+00	4	BAGGANADODDI	1	new through import_export	9	2
239	2022-12-12 18:23:59.496944+00	5	TIMMYANADODDI	1	new through import_export	9	2
240	2022-12-12 18:23:59.499153+00	6	NAGAYANADODDI	1	new through import_export	9	2
241	2022-12-12 18:23:59.501411+00	7	CHIKKNAHALLI	1	new through import_export	9	2
242	2022-12-12 18:23:59.503614+00	8	INDLAWADI PURA	1	new through import_export	9	2
243	2022-12-12 18:23:59.505921+00	9	TIMMASANDRA	1	new through import_export	9	2
244	2022-12-12 18:23:59.508232+00	10	BANGLADODDI	1	new through import_export	9	2
245	2022-12-12 18:23:59.510817+00	11	VANAKANAHALLI	1	new through import_export	9	2
246	2022-12-12 18:23:59.513458+00	12	SOLLORU	1	new through import_export	9	2
247	2022-12-12 18:23:59.515901+00	13	KALANAYAKANAHALLI	1	new through import_export	9	2
248	2022-12-12 18:23:59.518461+00	14	SUNAVARA	1	new through import_export	9	2
249	2022-12-12 18:23:59.520985+00	15	CHODENAHALLI	1	new through import_export	9	2
250	2022-12-12 18:23:59.523553+00	16	P GOLLAHALLI	1	new through import_export	9	2
251	2022-12-12 18:23:59.526319+00	17	MENASIGANAHALLI	1	new through import_export	9	2
252	2022-12-12 18:23:59.529236+00	18	SINGASANDRA	1	new through import_export	9	2
253	2022-12-12 18:23:59.532004+00	19	KEMPADOMMASANDRA	1	new through import_export	9	2
254	2022-12-12 18:23:59.535003+00	20	TELAGARAHALLI	1	new through import_export	9	2
255	2022-12-12 18:23:59.537986+00	21	CHIKKAHOSALLI	1	new through import_export	9	2
256	2022-12-12 18:23:59.541203+00	22	NALLAYANADODDI	1	new through import_export	9	2
257	2022-12-12 18:23:59.544692+00	23	TAMMANAYAKANAHALLI	1	new through import_export	9	2
258	2022-12-12 18:23:59.548038+00	24	CHOODAHALLI	1	new through import_export	9	2
1062	2022-12-19 07:42:44.246423+00	10	Alexa	3		18	3
259	2022-12-12 18:23:59.551398+00	25	KARAKALAGATTA	1	new through import_export	9	2
260	2022-12-12 18:23:59.554741+00	26	KARAKALAGATTA JANATHA COLONY	1	new through import_export	9	2
261	2022-12-12 18:23:59.557829+00	27	AREHALLI	1	new through import_export	9	2
262	2022-12-12 18:23:59.56131+00	28	LAKSHMIPURA	1	new through import_export	9	2
263	2022-12-12 18:23:59.5646+00	29	BASAVANAPURA	1	new through import_export	9	2
264	2022-12-12 18:23:59.567684+00	30	MUTTURU	1	new through import_export	9	2
265	2022-12-13 05:56:04.939461+00	12	regular patient	2	[{"changed": {"fields": ["Name"]}}]	12	2
266	2022-12-13 05:56:52.489726+00	13	walk in patient	1	[{"added": {}}]	12	2
267	2022-12-13 07:03:38.274086+00	9	RUHI	2	[{"changed": {"fields": ["Phone number", "Fee status"]}}]	18	2
268	2022-12-13 08:19:28.857353+00	2	Tangartoli	3		14	2
269	2022-12-13 08:19:28.860183+00	1	Dari ambatoli	3		14	2
270	2022-12-13 08:20:58.450687+00	4	Tangartoli	3		17	2
271	2022-12-13 08:20:58.453715+00	3	Tangartoli	3		17	2
272	2022-12-13 09:12:39.87783+00	1	MD-Antigout	1	new through import_export	23	2
273	2022-12-13 09:12:39.880449+00	2	MD-BPH medicine	1	new through import_export	23	2
274	2022-12-13 09:12:39.882827+00	3	MD-Anti filarial	1	new through import_export	23	2
275	2022-12-13 09:12:39.8851+00	4	MD-Statin	1	new through import_export	23	2
276	2022-12-13 09:12:39.887428+00	5	MD-Analgesisc/ Antiypyretic	1	new through import_export	23	2
277	2022-12-13 09:12:39.889644+00	6	MD-Antacid	1	new through import_export	23	2
278	2022-12-13 09:12:39.891874+00	7	MD-Anti - Diabetics	1	new through import_export	23	2
279	2022-12-13 09:12:39.894333+00	8	MD-Anti - Parkinsons	1	new through import_export	23	2
280	2022-12-13 09:12:39.897105+00	9	MD-Anti Convulsant	1	new through import_export	23	2
281	2022-12-13 09:12:39.899614+00	10	MD-Anti -emetic	1	new through import_export	23	2
282	2022-12-13 09:12:39.901871+00	11	MD-Anti fungal	1	new through import_export	23	2
283	2022-12-13 09:12:39.904051+00	12	MD-Anti hypertensive	1	new through import_export	23	2
284	2022-12-13 09:12:39.906528+00	13	MD-Anti Malaria	1	new through import_export	23	2
285	2022-12-13 09:12:39.908955+00	14	MD-Anti spasmodic /Analgesic	1	new through import_export	23	2
286	2022-12-13 09:12:39.911619+00	15	MD-Anti -thyroid /Thyroid	1	new through import_export	23	2
287	2022-12-13 09:12:39.914739+00	16	MD-Antibiotics	1	new through import_export	23	2
288	2022-12-13 09:12:39.917341+00	17	MD-Antihistaminic	1	new through import_export	23	2
289	2022-12-13 09:12:39.919643+00	18	MD-Corticosteroid	1	new through import_export	23	2
290	2022-12-13 09:12:39.922075+00	19	MD-De worming	1	new through import_export	23	2
291	2022-12-13 09:12:39.924614+00	20	MD-Diuretic	1	new through import_export	23	2
292	2022-12-13 09:12:39.927434+00	21	MD-Eye/ Ear Drops/ointments	1	new through import_export	23	2
293	2022-12-13 09:12:39.930373+00	22	MD-Laxative	1	new through import_export	23	2
294	2022-12-13 09:12:39.93352+00	23	MD-NSAID	1	new through import_export	23	2
295	2022-12-13 09:12:39.93659+00	24	MD-OTHERS	1	new through import_export	23	2
296	2022-12-13 09:12:39.939684+00	25	MD-Scabicide/ Pediculicide	1	new through import_export	23	2
297	2022-12-13 09:12:39.942849+00	26	MD-Sedative/anti anxiety	1	new through import_export	23	2
298	2022-12-13 09:12:39.945869+00	27	MD-Steroid ointment/ tab	1	new through import_export	23	2
299	2022-12-13 09:12:39.94896+00	28	MD-supplements/Vitamins	1	new through import_export	23	2
300	2022-12-13 09:12:39.951748+00	29	MD-Anti- Angina/ cardiac/stroke	1	new through import_export	23	2
301	2022-12-13 09:12:39.954802+00	30	MD-Anti - Asthmatic / Bronchodilator	1	new through import_export	23	2
302	2022-12-13 09:12:39.95767+00	31	MD-Dermatological ointment/ cream	1	new through import_export	23	2
303	2022-12-13 09:12:39.960514+00	32	Allopurinol 100mg	1	new through import_export	23	2
304	2022-12-13 09:12:39.963563+00	33	Tamulosin 0.4 mg	1	new through import_export	23	2
305	2022-12-13 09:12:39.966526+00	34	Diethylcarbamazine Citrate 100mg	1	new through import_export	23	2
306	2022-12-13 09:12:39.969475+00	35	Atrovastatin 10mg	1	new through import_export	23	2
307	2022-12-13 09:12:39.972341+00	36	Paracetamol 125mg/5ml 60 ml bottle	1	new through import_export	23	2
308	2022-12-13 09:12:39.975405+00	37	Paracetamol 500mg	1	new through import_export	23	2
309	2022-12-13 09:12:39.978662+00	38	Dried aluminium Hydroxide Gel 250mg+ Magnesium Hydroxide+Activated Dimethicone 50mg 250 +250+50 mg	1	new through import_export	23	2
310	2022-12-13 09:12:39.982099+00	39	Pantaprazole 40mg	1	new through import_export	23	2
311	2022-12-13 09:12:39.985507+00	40	Metformin 500mg	1	new through import_export	23	2
312	2022-12-13 09:12:39.989037+00	41	Glicazide 40mg	1	new through import_export	23	2
313	2022-12-13 09:12:39.992808+00	42	Glipizide 5mg	1	new through import_export	23	2
314	2022-12-13 09:12:39.996524+00	43	Glimipride 2mg	1	new through import_export	23	2
315	2022-12-13 09:12:40.000446+00	44	Metformin SR 1000mg	1	new through import_export	23	2
316	2022-12-13 09:12:40.0044+00	45	Glimipride 1mg	1	new through import_export	23	2
317	2022-12-13 09:12:40.008423+00	46	Ldopa-carbidopa 100mg	1	new through import_export	23	2
318	2022-12-13 09:12:40.012009+00	47	Trihexiphenidyl 2mg	1	new through import_export	23	2
319	2022-12-13 09:12:40.015381+00	48	sodium valproate 200 mg/5ml 100 ml bottle	1	new through import_export	23	2
320	2022-12-13 09:12:40.01862+00	49	sodium valproate (enteric coated) 200 mg	1	new through import_export	23	2
321	2022-12-13 09:12:40.021795+00	50	Phenytoin sodium 100mg	1	new through import_export	23	2
322	2022-12-13 09:12:40.024857+00	51	Carbamazepine 200 mg	1	new through import_export	23	2
323	2022-12-13 09:12:40.02798+00	52	Carbamazepine 100 mg	1	new through import_export	23	2
324	2022-12-13 09:12:40.031035+00	53	Phenytoin sodium 30mg/5 ml, 100 ml bottle	1	new through import_export	23	2
325	2022-12-13 09:12:40.033985+00	54	Carbamazepine 200 mg/ 5ml, 100 ml bottle)	1	new through import_export	23	2
326	2022-12-13 09:12:40.036843+00	55	Domperidone 10mg	1	new through import_export	23	2
327	2022-12-13 09:12:40.039682+00	56	Domperidone 5mg/5ml ,30 ml pack	1	new through import_export	23	2
328	2022-12-13 09:12:40.043182+00	57	Clotrimazole Oint 1% 15gm tube	1	new through import_export	23	2
329	2022-12-13 09:12:40.046768+00	58	Fluconazole 150mg	1	new through import_export	23	2
330	2022-12-13 09:12:40.050186+00	59	Amlodipine 5mg	1	new through import_export	23	2
331	2022-12-13 09:12:40.053153+00	60	Hydrochlorthiazide 25mg	1	new through import_export	23	2
332	2022-12-13 09:12:40.055891+00	61	Losartan 50mg	1	new through import_export	23	2
333	2022-12-13 09:12:40.059255+00	62	Losartan 25mg	1	new through import_export	23	2
334	2022-12-13 09:12:40.06265+00	63	Enalapril 5mg	1	new through import_export	23	2
335	2022-12-13 09:12:40.065782+00	64	Atenolol 50mg	1	new through import_export	23	2
336	2022-12-13 09:12:40.069363+00	65	Chloroquine phosphate (150 mg base) 250mg	1	new through import_export	23	2
337	2022-12-13 09:12:40.072166+00	66	Primaquine 15mg	1	new through import_export	23	2
338	2022-12-13 09:12:40.075945+00	67	SulfadoxinePyrimethamine (S-P) 500mg+25mg	1	new through import_export	23	2
339	2022-12-13 09:12:40.079315+00	68	Artesunate (AS) 50 mg	1	new through import_export	23	2
340	2022-12-13 09:12:40.082384+00	69	Artimether+Lumfentrine 20mg+120 mg	1	new through import_export	23	2
341	2022-12-13 09:12:40.085234+00	70	Dicylomine+ Paracetamol 20 +325mg	1	new through import_export	23	2
342	2022-12-13 09:12:40.088064+00	71	Carbimazole 10 mg	1	new through import_export	23	2
343	2022-12-13 09:12:40.090871+00	72	L-thyroxine 100mcg	1	new through import_export	23	2
344	2022-12-13 09:12:40.093772+00	73	L-thyroxine 50mcg	1	new through import_export	23	2
345	2022-12-13 09:12:40.096669+00	74	L-thyroxine 25mcg	1	new through import_export	23	2
346	2022-12-13 09:12:40.099499+00	75	Amoxycillin 250mg	1	new through import_export	23	2
347	2022-12-13 09:12:40.102312+00	76	Nitrofurantion 100mg	1	new through import_export	23	2
348	2022-12-13 09:12:40.105053+00	77	Nitrofurantion 25mg/5ml 60ml	1	new through import_export	23	2
349	2022-12-13 09:12:40.107734+00	78	Amoxycillin 500mg	1	new through import_export	23	2
350	2022-12-13 09:12:40.110518+00	79	Norfloxacin 400mg	1	new through import_export	23	2
351	2022-12-13 09:12:40.113647+00	80	Ciprofloxacin 500mg	1	new through import_export	23	2
352	2022-12-13 09:12:40.116671+00	81	Amoxycillin & Clavulanate Potassium 200 + 28.5 mg/5 ml, 30 ml bottle	1	new through import_export	23	2
353	2022-12-13 09:12:40.11945+00	82	Metronidazole 200 mg/5 ml/60ml	1	new through import_export	23	2
354	2022-12-13 09:12:40.122207+00	83	cephalexin 250 mg	1	new through import_export	23	2
355	2022-12-13 09:12:40.124905+00	84	Metronidazole 200mg	1	new through import_export	23	2
356	2022-12-13 09:12:40.127891+00	85	Amoxycillin & Clavulanate Potassium625mg Amox.500 + Clavulanate 125)	1	new through import_export	23	2
357	2022-12-13 09:12:40.130717+00	86	cephalexin 125 mg/5 ml 30 ml	1	new through import_export	23	2
358	2022-12-13 09:12:40.133609+00	87	Metronidazole 400mg	1	new through import_export	23	2
359	2022-12-13 09:12:40.136615+00	88	Azithromycin 500mg	1	new through import_export	23	2
360	2022-12-13 09:12:40.139738+00	89	Azithromycin 200mg/5ml 15 ml	1	new through import_export	23	2
361	2022-12-13 09:12:40.14274+00	90	Amoxycillin (Paediatric) 125 mg/5ml, 30ml	1	new through import_export	23	2
362	2022-12-13 09:12:40.145826+00	91	Cetrizine 10mg	1	new through import_export	23	2
363	2022-12-13 09:12:40.149074+00	92	Promethazine 5mg/5ml 60 ml	1	new through import_export	23	2
364	2022-12-13 09:12:40.151933+00	93	Promethazine 25 mg	1	new through import_export	23	2
365	2022-12-13 09:12:40.154773+00	94	Montelukast 10mg	1	new through import_export	23	2
366	2022-12-13 09:12:40.157481+00	95	Cinnerazine 25mg	1	new through import_export	23	2
367	2022-12-13 09:12:40.160234+00	96	Chlorpheniramine maleate 15 mg/ml 100ml	1	new through import_export	23	2
368	2022-12-13 09:12:40.163128+00	97	Prednisolone 5mg	1	new through import_export	23	2
369	2022-12-13 09:12:40.165892+00	98	Dexamethasone 0.5 mg	1	new through import_export	23	2
370	2022-12-13 09:12:40.168699+00	99	Prednisolone 10mg	1	new through import_export	23	2
371	2022-12-13 09:12:40.171394+00	100	Albendazole 400mg	1	new through import_export	23	2
372	2022-12-13 09:12:40.174137+00	101	Mebendazole 100 mg	1	new through import_export	23	2
373	2022-12-13 09:12:40.177052+00	102	Mebendazole 100 mg/5 ml 30 ml	1	new through import_export	23	2
374	2022-12-13 09:12:40.180266+00	103	Albendazole 200 mg/5 ml 10ml	1	new through import_export	23	2
375	2022-12-13 09:12:40.183311+00	104	Furosemide 40mg	1	new through import_export	23	2
376	2022-12-13 09:12:40.186184+00	105	Torsemide 10mg	1	new through import_export	23	2
377	2022-12-13 09:12:40.189043+00	106	Torsemide 5mg	1	new through import_export	23	2
378	2022-12-13 09:12:40.192369+00	107	Gentamycin eye/ ear drops 0.003	1	new through import_export	23	2
379	2022-12-13 09:12:40.195377+00	108	Ciprofloxacin eye/ear drops 0.003	1	new through import_export	23	2
380	2022-12-13 09:12:40.1984+00	109	Wax dissolving Ear drops(Paradichlorobenzene, Chlorbutol & Turpentine) 10 ml	1	new through import_export	23	2
381	2022-12-13 09:12:40.20129+00	110	Prednisolone Sodium Phosphate 0.01	1	new through import_export	23	2
382	2022-12-13 09:12:40.204531+00	111	Chloramphenicol applicaps 0.01	1	new through import_export	23	2
383	2022-12-13 09:12:40.207962+00	112	Chloramphenicol eye drops 0.005	1	new through import_export	23	2
384	2022-12-13 09:12:40.211401+00	113	Liquid paraffin + milk of magnesia 170ml	1	new through import_export	23	2
385	2022-12-13 09:12:40.214762+00	114	Lactulose 3.35g / 5ml 100ml	1	new through import_export	23	2
386	2022-12-13 09:12:40.217825+00	115	Bisacodyl 5mg	1	new through import_export	23	2
387	2022-12-13 09:12:40.22078+00	116	Isapghula husk 100mg	1	new through import_export	23	2
388	2022-12-13 09:12:40.223614+00	117	Etoricoxib 60mg	1	new through import_export	23	2
389	2022-12-13 09:12:40.226481+00	118	Diclofenac 50 mg	1	new through import_export	23	2
390	2022-12-13 09:12:40.229309+00	119	Diclofenac Gel 30gm	1	new through import_export	23	2
391	2022-12-13 09:12:40.232122+00	120	Ibuprofen 400mg	1	new through import_export	23	2
392	2022-12-13 09:12:40.23537+00	121	Aspirin (acetylsalicylic acid) 75mg	1	new through import_export	23	2
393	2022-12-13 09:12:40.23854+00	122	Boroglycerin Paint 10gm	1	new through import_export	23	2
394	2022-12-13 09:12:40.241394+00	123	Cough syrup Dextromethorphan HBr IP 13.5mg/5ml 50 ml 50 ml	1	new through import_export	23	2
395	2022-12-13 09:12:40.244318+00	124	Oxymetazoline nasal drops 0.005	1	new through import_export	23	2
396	2022-12-13 09:12:40.24741+00	125	Calamine 60 ml	1	new through import_export	23	2
397	2022-12-13 09:12:40.25031+00	126	Benzyl benzoate 25% 100 ml	1	new through import_export	23	2
398	2022-12-13 09:12:40.253087+00	127	Permethrin 5% 30g tube	1	new through import_export	23	2
399	2022-12-13 09:12:40.255877+00	128	Diazepam 2mg	1	new through import_export	23	2
400	2022-12-13 09:12:40.258907+00	129	Clonazepam 0.5mg	1	new through import_export	23	2
401	2022-12-13 09:12:40.261956+00	130	Betamethasone 0.05% 15 g tube	1	new through import_export	23	2
402	2022-12-13 09:12:40.264816+00	131	Betamethasone 0.5 mg	1	new through import_export	23	2
403	2022-12-13 09:12:40.267746+00	132	ferrous salt + folic acid 100 mg Elevental Iron & 500 mcg of Folic Acid	1	new through import_export	23	2
404	2022-12-13 09:12:40.270945+00	133	Calcium Elemental 500mg+Vitamin D3 250mg 500/250 gm	1	new through import_export	23	2
405	2022-12-13 09:12:40.274058+00	134	Vitamin C 500mg	1	new through import_export	23	2
406	2022-12-13 09:12:40.277202+00	135	Vit B Complex ( Viramin B1, B 2, B3,B5, B6, B12, folic acid)	1	new through import_export	23	2
407	2022-12-13 09:12:40.280622+00	136	Colecalciferol (vitamin D3 ) 60000 units	1	new through import_export	23	2
408	2022-12-13 09:12:40.283705+00	137	ORS Sodium Chloride 2.6gm/l, glucose anhydrous 13.5gm/I,potassium chloride 1.5gm/l,trisodium citrate dihydrate	1	new through import_export	23	2
409	2022-12-13 09:12:40.286561+00	138	Metoprolol-25mg	1	new through import_export	23	2
410	2022-12-13 09:12:40.289348+00	139	Metoprolol-50mg	1	new through import_export	23	2
411	2022-12-13 09:12:40.29273+00	140	Propanolol-20mg	1	new through import_export	23	2
412	2022-12-13 09:12:40.295785+00	141	Glyceryl Trinitrate Sublingual-0.5mg	1	new through import_export	23	2
413	2022-12-13 09:12:40.2987+00	142	Isosorbide Mononitrate-10mg	1	new through import_export	23	2
414	2022-12-13 09:12:40.30145+00	143	Isosorbide dinitrate ( Sublingual)-5mg	1	new through import_export	23	2
415	2022-12-13 09:12:40.304269+00	144	Etophylline 23 mg - Theophylline 77 mg- 23 mg -77 mg	1	new through import_export	23	2
416	2022-12-13 09:12:40.307104+00	145	Salbutamol- 2 mg/5 ml ,100ml	1	new through import_export	23	2
417	2022-12-13 09:12:40.309852+00	146	Salbutamol-4mg	1	new through import_export	23	2
418	2022-12-13 09:12:40.31273+00	147	Salbutamol-100mcg	1	new through import_export	23	2
419	2022-12-13 09:12:40.315523+00	148	Salbutamol-5 mg/ml , 15ml	1	new through import_export	23	2
420	2022-12-13 09:12:40.318256+00	149	Ipratropium-20mcg MDI	1	new through import_export	23	2
421	2022-12-13 09:12:40.320974+00	150	Neomycin and Polymyxin B Sulfates and Bacitracin zinc ointment-5gm	1	new through import_export	23	2
422	2022-12-13 09:12:40.323662+00	151	Povidone iodine-5% 15g	1	new through import_export	23	2
423	2022-12-13 09:12:40.326707+00	152	Silver Sulfadiazine + Chlorhexidine & Cetrimide cream 15gm- 1% + 0.2% 15 gm	1	new through import_export	23	2
424	2022-12-13 11:40:46.979088+00	152	Silver Sulfadiazine + Chlorhexidine & Cetrimide cream 15gm- 1% + 0.2% 15 gm	3		23	3
425	2022-12-13 11:40:46.982057+00	151	Povidone iodine-5% 15g	3		23	3
426	2022-12-13 11:40:46.983574+00	150	Neomycin and Polymyxin B Sulfates and Bacitracin zinc ointment-5gm	3		23	3
427	2022-12-13 11:40:46.984895+00	149	Ipratropium-20mcg MDI	3		23	3
428	2022-12-13 11:40:46.986144+00	148	Salbutamol-5 mg/ml , 15ml	3		23	3
429	2022-12-13 11:40:46.987313+00	147	Salbutamol-100mcg	3		23	3
430	2022-12-13 11:40:46.98847+00	146	Salbutamol-4mg	3		23	3
431	2022-12-13 11:40:46.989582+00	145	Salbutamol- 2 mg/5 ml ,100ml	3		23	3
432	2022-12-13 11:40:46.991236+00	144	Etophylline 23 mg - Theophylline 77 mg- 23 mg -77 mg	3		23	3
433	2022-12-13 11:40:46.992932+00	143	Isosorbide dinitrate ( Sublingual)-5mg	3		23	3
434	2022-12-13 11:40:46.993973+00	142	Isosorbide Mononitrate-10mg	3		23	3
435	2022-12-13 11:40:46.994941+00	141	Glyceryl Trinitrate Sublingual-0.5mg	3		23	3
436	2022-12-13 11:40:46.995901+00	140	Propanolol-20mg	3		23	3
437	2022-12-13 11:40:46.99695+00	139	Metoprolol-50mg	3		23	3
438	2022-12-13 11:40:46.998583+00	138	Metoprolol-25mg	3		23	3
439	2022-12-13 11:40:46.999572+00	137	ORS Sodium Chloride 2.6gm/l, glucose anhydrous 13.5gm/I,potassium chloride 1.5gm/l,trisodium citrate dihydrate	3		23	3
440	2022-12-13 11:40:47.000554+00	136	Colecalciferol (vitamin D3 ) 60000 units	3		23	3
441	2022-12-13 11:40:47.00166+00	135	Vit B Complex ( Viramin B1, B 2, B3,B5, B6, B12, folic acid)	3		23	3
442	2022-12-13 11:40:47.00253+00	134	Vitamin C 500mg	3		23	3
443	2022-12-13 11:40:47.003682+00	133	Calcium Elemental 500mg+Vitamin D3 250mg 500/250 gm	3		23	3
444	2022-12-13 11:40:47.004707+00	132	ferrous salt + folic acid 100 mg Elevental Iron & 500 mcg of Folic Acid	3		23	3
445	2022-12-13 11:40:47.005663+00	131	Betamethasone 0.5 mg	3		23	3
446	2022-12-13 11:40:47.006532+00	130	Betamethasone 0.05% 15 g tube	3		23	3
447	2022-12-13 11:40:47.007421+00	129	Clonazepam 0.5mg	3		23	3
448	2022-12-13 11:40:47.008235+00	128	Diazepam 2mg	3		23	3
449	2022-12-13 11:40:47.009094+00	127	Permethrin 5% 30g tube	3		23	3
450	2022-12-13 11:40:47.009947+00	126	Benzyl benzoate 25% 100 ml	3		23	3
451	2022-12-13 11:40:47.010796+00	125	Calamine 60 ml	3		23	3
452	2022-12-13 11:40:47.011992+00	124	Oxymetazoline nasal drops 0.005	3		23	3
453	2022-12-13 11:40:47.013398+00	123	Cough syrup Dextromethorphan HBr IP 13.5mg/5ml 50 ml 50 ml	3		23	3
454	2022-12-13 11:40:47.014533+00	122	Boroglycerin Paint 10gm	3		23	3
455	2022-12-13 11:40:47.015626+00	121	Aspirin (acetylsalicylic acid) 75mg	3		23	3
456	2022-12-13 11:40:47.016732+00	120	Ibuprofen 400mg	3		23	3
457	2022-12-13 11:40:47.017751+00	119	Diclofenac Gel 30gm	3		23	3
458	2022-12-13 11:40:47.019049+00	118	Diclofenac 50 mg	3		23	3
459	2022-12-13 11:40:47.020322+00	117	Etoricoxib 60mg	3		23	3
460	2022-12-13 11:40:47.021491+00	116	Isapghula husk 100mg	3		23	3
461	2022-12-13 11:40:47.022489+00	115	Bisacodyl 5mg	3		23	3
462	2022-12-13 11:40:47.023539+00	114	Lactulose 3.35g / 5ml 100ml	3		23	3
463	2022-12-13 11:40:47.024585+00	113	Liquid paraffin + milk of magnesia 170ml	3		23	3
464	2022-12-13 11:40:47.025468+00	112	Chloramphenicol eye drops 0.005	3		23	3
465	2022-12-13 11:40:47.026379+00	111	Chloramphenicol applicaps 0.01	3		23	3
466	2022-12-13 11:40:47.027467+00	110	Prednisolone Sodium Phosphate 0.01	3		23	3
467	2022-12-13 11:40:47.028463+00	109	Wax dissolving Ear drops(Paradichlorobenzene, Chlorbutol & Turpentine) 10 ml	3		23	3
468	2022-12-13 11:40:47.029439+00	108	Ciprofloxacin eye/ear drops 0.003	3		23	3
469	2022-12-13 11:40:47.03044+00	107	Gentamycin eye/ ear drops 0.003	3		23	3
470	2022-12-13 11:40:47.031439+00	106	Torsemide 5mg	3		23	3
471	2022-12-13 11:40:47.032443+00	105	Torsemide 10mg	3		23	3
472	2022-12-13 11:40:47.033425+00	104	Furosemide 40mg	3		23	3
473	2022-12-13 11:40:47.034425+00	103	Albendazole 200 mg/5 ml 10ml	3		23	3
474	2022-12-13 11:40:47.035419+00	102	Mebendazole 100 mg/5 ml 30 ml	3		23	3
475	2022-12-13 11:40:47.036252+00	101	Mebendazole 100 mg	3		23	3
476	2022-12-13 11:40:47.037281+00	100	Albendazole 400mg	3		23	3
477	2022-12-13 11:40:47.038214+00	99	Prednisolone 10mg	3		23	3
478	2022-12-13 11:40:47.039096+00	98	Dexamethasone 0.5 mg	3		23	3
479	2022-12-13 11:40:47.04005+00	97	Prednisolone 5mg	3		23	3
480	2022-12-13 11:40:47.041005+00	96	Chlorpheniramine maleate 15 mg/ml 100ml	3		23	3
481	2022-12-13 11:40:47.041907+00	95	Cinnerazine 25mg	3		23	3
482	2022-12-13 11:40:47.04284+00	94	Montelukast 10mg	3		23	3
483	2022-12-13 11:40:47.043908+00	93	Promethazine 25 mg	3		23	3
484	2022-12-13 11:40:47.04479+00	92	Promethazine 5mg/5ml 60 ml	3		23	3
485	2022-12-13 11:40:47.045786+00	91	Cetrizine 10mg	3		23	3
486	2022-12-13 11:40:47.046671+00	90	Amoxycillin (Paediatric) 125 mg/5ml, 30ml	3		23	3
487	2022-12-13 11:40:47.047938+00	89	Azithromycin 200mg/5ml 15 ml	3		23	3
488	2022-12-13 11:40:47.048995+00	88	Azithromycin 500mg	3		23	3
489	2022-12-13 11:40:47.049955+00	87	Metronidazole 400mg	3		23	3
490	2022-12-13 11:40:47.05107+00	86	cephalexin 125 mg/5 ml 30 ml	3		23	3
491	2022-12-13 11:40:47.052208+00	85	Amoxycillin & Clavulanate Potassium625mg Amox.500 + Clavulanate 125)	3		23	3
492	2022-12-13 11:40:47.053109+00	84	Metronidazole 200mg	3		23	3
493	2022-12-13 11:40:47.054173+00	83	cephalexin 250 mg	3		23	3
494	2022-12-13 11:40:47.055159+00	82	Metronidazole 200 mg/5 ml/60ml	3		23	3
495	2022-12-13 11:40:47.056102+00	81	Amoxycillin & Clavulanate Potassium 200 + 28.5 mg/5 ml, 30 ml bottle	3		23	3
496	2022-12-13 11:40:47.056961+00	80	Ciprofloxacin 500mg	3		23	3
497	2022-12-13 11:40:47.057851+00	79	Norfloxacin 400mg	3		23	3
498	2022-12-13 11:40:47.058685+00	78	Amoxycillin 500mg	3		23	3
499	2022-12-13 11:40:47.059672+00	77	Nitrofurantion 25mg/5ml 60ml	3		23	3
500	2022-12-13 11:40:47.060658+00	76	Nitrofurantion 100mg	3		23	3
501	2022-12-13 11:40:47.061504+00	75	Amoxycillin 250mg	3		23	3
502	2022-12-13 11:40:47.062405+00	74	L-thyroxine 25mcg	3		23	3
503	2022-12-13 11:40:47.063362+00	73	L-thyroxine 50mcg	3		23	3
504	2022-12-13 11:40:47.064237+00	72	L-thyroxine 100mcg	3		23	3
505	2022-12-13 11:40:47.065121+00	71	Carbimazole 10 mg	3		23	3
506	2022-12-13 11:40:47.066016+00	70	Dicylomine+ Paracetamol 20 +325mg	3		23	3
507	2022-12-13 11:40:47.067056+00	69	Artimether+Lumfentrine 20mg+120 mg	3		23	3
508	2022-12-13 11:40:47.071119+00	68	Artesunate (AS) 50 mg	3		23	3
509	2022-12-13 11:40:47.075017+00	67	SulfadoxinePyrimethamine (S-P) 500mg+25mg	3		23	3
510	2022-12-13 11:40:47.082998+00	66	Primaquine 15mg	3		23	3
511	2022-12-13 11:40:47.084661+00	65	Chloroquine phosphate (150 mg base) 250mg	3		23	3
512	2022-12-13 11:40:47.085872+00	64	Atenolol 50mg	3		23	3
513	2022-12-13 11:40:47.087096+00	63	Enalapril 5mg	3		23	3
514	2022-12-13 11:40:47.088111+00	62	Losartan 25mg	3		23	3
515	2022-12-13 11:40:47.089158+00	61	Losartan 50mg	3		23	3
516	2022-12-13 11:40:47.090138+00	60	Hydrochlorthiazide 25mg	3		23	3
517	2022-12-13 11:40:47.091645+00	59	Amlodipine 5mg	3		23	3
518	2022-12-13 11:40:47.092854+00	58	Fluconazole 150mg	3		23	3
519	2022-12-13 11:40:47.093934+00	57	Clotrimazole Oint 1% 15gm tube	3		23	3
520	2022-12-13 11:40:47.095104+00	56	Domperidone 5mg/5ml ,30 ml pack	3		23	3
521	2022-12-13 11:40:47.096096+00	55	Domperidone 10mg	3		23	3
522	2022-12-13 11:40:47.097149+00	54	Carbamazepine 200 mg/ 5ml, 100 ml bottle)	3		23	3
523	2022-12-13 11:40:47.098228+00	53	Phenytoin sodium 30mg/5 ml, 100 ml bottle	3		23	3
524	2022-12-13 11:40:47.099463+00	52	Carbamazepine 100 mg	3		23	3
525	2022-12-13 11:40:47.100478+00	51	Carbamazepine 200 mg	3		23	3
526	2022-12-13 11:40:47.101612+00	50	Phenytoin sodium 100mg	3		23	3
527	2022-12-13 11:40:47.102517+00	49	sodium valproate (enteric coated) 200 mg	3		23	3
528	2022-12-13 11:40:47.103585+00	48	sodium valproate 200 mg/5ml 100 ml bottle	3		23	3
529	2022-12-13 11:40:47.104865+00	47	Trihexiphenidyl 2mg	3		23	3
530	2022-12-13 11:40:47.105925+00	46	Ldopa-carbidopa 100mg	3		23	3
531	2022-12-13 11:40:47.10703+00	45	Glimipride 1mg	3		23	3
532	2022-12-13 11:40:47.108073+00	44	Metformin SR 1000mg	3		23	3
533	2022-12-13 11:40:47.109101+00	43	Glimipride 2mg	3		23	3
534	2022-12-13 11:40:47.110166+00	42	Glipizide 5mg	3		23	3
535	2022-12-13 11:40:47.111267+00	41	Glicazide 40mg	3		23	3
536	2022-12-13 11:40:47.112292+00	40	Metformin 500mg	3		23	3
537	2022-12-13 11:40:47.113392+00	39	Pantaprazole 40mg	3		23	3
538	2022-12-13 11:40:47.114508+00	38	Dried aluminium Hydroxide Gel 250mg+ Magnesium Hydroxide+Activated Dimethicone 50mg 250 +250+50 mg	3		23	3
539	2022-12-13 11:40:47.115585+00	37	Paracetamol 500mg	3		23	3
540	2022-12-13 11:40:47.116613+00	36	Paracetamol 125mg/5ml 60 ml bottle	3		23	3
541	2022-12-13 11:40:47.117583+00	35	Atrovastatin 10mg	3		23	3
542	2022-12-13 11:40:47.12007+00	34	Diethylcarbamazine Citrate 100mg	3		23	3
543	2022-12-13 11:40:47.121266+00	33	Tamulosin 0.4 mg	3		23	3
544	2022-12-13 11:40:47.122598+00	32	Allopurinol 100mg	3		23	3
545	2022-12-13 11:40:47.123832+00	31	MD-Dermatological ointment/ cream	3		23	3
546	2022-12-13 11:40:47.125341+00	30	MD-Anti - Asthmatic / Bronchodilator	3		23	3
547	2022-12-13 11:40:47.126394+00	29	MD-Anti- Angina/ cardiac/stroke	3		23	3
548	2022-12-13 11:40:47.12741+00	28	MD-supplements/Vitamins	3		23	3
549	2022-12-13 11:40:47.128407+00	27	MD-Steroid ointment/ tab	3		23	3
550	2022-12-13 11:40:47.129422+00	26	MD-Sedative/anti anxiety	3		23	3
551	2022-12-13 11:40:47.130473+00	25	MD-Scabicide/ Pediculicide	3		23	3
552	2022-12-13 11:40:47.131544+00	24	MD-OTHERS	3		23	3
553	2022-12-13 11:40:47.132675+00	23	MD-NSAID	3		23	3
554	2022-12-13 11:40:47.134611+00	22	MD-Laxative	3		23	3
555	2022-12-13 11:40:47.136764+00	21	MD-Eye/ Ear Drops/ointments	3		23	3
556	2022-12-13 11:40:47.138004+00	20	MD-Diuretic	3		23	3
557	2022-12-13 11:40:47.13914+00	19	MD-De worming	3		23	3
558	2022-12-13 11:40:47.140285+00	18	MD-Corticosteroid	3		23	3
559	2022-12-13 11:40:47.141545+00	17	MD-Antihistaminic	3		23	3
560	2022-12-13 11:40:47.142499+00	16	MD-Antibiotics	3		23	3
561	2022-12-13 11:40:47.144137+00	15	MD-Anti -thyroid /Thyroid	3		23	3
562	2022-12-13 11:40:47.145197+00	14	MD-Anti spasmodic /Analgesic	3		23	3
563	2022-12-13 11:40:47.146174+00	13	MD-Anti Malaria	3		23	3
564	2022-12-13 11:40:47.147346+00	12	MD-Anti hypertensive	3		23	3
565	2022-12-13 11:40:47.149455+00	11	MD-Anti fungal	3		23	3
566	2022-12-13 11:40:47.150554+00	10	MD-Anti -emetic	3		23	3
567	2022-12-13 11:40:47.151644+00	9	MD-Anti Convulsant	3		23	3
568	2022-12-13 11:40:47.152671+00	8	MD-Anti - Parkinsons	3		23	3
569	2022-12-13 11:40:47.153571+00	7	MD-Anti - Diabetics	3		23	3
570	2022-12-13 11:40:47.154477+00	6	MD-Antacid	3		23	3
571	2022-12-13 11:40:47.155863+00	5	MD-Analgesisc/ Antiypyretic	3		23	3
572	2022-12-13 11:40:47.156818+00	4	MD-Statin	3		23	3
573	2022-12-13 11:40:47.15786+00	3	MD-Anti filarial	3		23	3
574	2022-12-13 11:40:47.159242+00	2	MD-BPH medicine	3		23	3
575	2022-12-13 11:40:47.160688+00	1	MD-Antigout	3		23	3
576	2022-12-13 11:45:26.583502+00	1	Tab AMLODIPINE 5mg	1	new through import_export	23	3
577	2022-12-13 11:45:26.587239+00	2	Tab Telmisartan 40mg	1	new through import_export	23	3
578	2022-12-13 11:45:26.588946+00	3	Tab Hydrochlorothiazide 25mg	1	new through import_export	23	3
579	2022-12-13 11:45:26.590559+00	4	Tab Atenolol 50mg	1	new through import_export	23	3
580	2022-12-13 11:45:26.592389+00	5	Tab Metoprolol 50mg	1	new through import_export	23	3
581	2022-12-13 11:45:26.593873+00	6	Tab Metformin 500mg	1	new through import_export	23	3
582	2022-12-13 11:45:26.595535+00	7	Tab Metformin 1000mg	1	new through import_export	23	3
583	2022-12-13 11:45:26.596988+00	8	Tab Glimeperide 1mg	1	new through import_export	23	3
584	2022-12-13 11:45:26.598405+00	9	Tab Glimeperide 2mg	1	new through import_export	23	3
585	2022-12-13 11:45:26.600349+00	10	Tab PIOGLITAZONE (15mg)+Metformin (500mg)+Glimeperide (2mg)	1	new through import_export	23	3
586	2022-12-13 11:45:26.601643+00	11	Tab Voglibose (0.2mg)+Metformin (500mg)+Glimeperide (2mg)	1	new through import_export	23	3
587	2022-12-13 11:45:26.602704+00	12	Tab Multivitamin B complex	1	new through import_export	23	3
588	2022-12-13 11:45:26.603854+00	13	Tab Iron sulphate + Folic acid	1	new through import_export	23	3
589	2022-12-13 11:45:26.604985+00	14	Tab C	1	new through import_export	23	3
590	2022-12-13 11:45:26.606215+00	15	Tab Zinc	1	new through import_export	23	3
591	2022-12-13 11:45:26.607417+00	16	Tab Calcium+ Vitamin D3	1	new through import_export	23	3
592	2022-12-13 11:45:26.608635+00	17	Tab Amoxicillin+ potassium clavunate 625mg	1	new through import_export	23	3
593	2022-12-13 11:45:26.609769+00	18	Tab Cefexime 200 mg	1	new through import_export	23	3
594	2022-12-13 11:45:26.611244+00	19	Tab Metronidazole 400mg	1	new through import_export	23	3
595	2022-12-13 11:45:26.616288+00	20	Tab Fluconazole 150mg	1	new through import_export	23	3
596	2022-12-13 11:45:26.617988+00	21	Tab Albendazole 400mg	1	new through import_export	23	3
597	2022-12-13 11:45:26.619493+00	22	Tab Paracetamol 650mg	1	new through import_export	23	3
598	2022-12-13 11:45:26.62079+00	23	Tab Tramadol 50mg	1	new through import_export	23	3
599	2022-12-13 11:45:26.622097+00	24	Tab Diclofenac 100mg	1	new through import_export	23	3
600	2022-12-13 11:45:26.623263+00	25	Tab Pregabalin 75mg	1	new through import_export	23	3
601	2022-12-13 11:45:26.624414+00	26	Cap Omeprazole 20mg	1	new through import_export	23	3
602	2022-12-13 11:45:26.625537+00	27	Tab Lactobacillus	1	new through import_export	23	3
603	2022-12-13 11:45:26.626485+00	28	Tab Domperidone	1	new through import_export	23	3
604	2022-12-13 11:45:26.627656+00	29	Tab Mefenemic acid + Dicyclomine	1	new through import_export	23	3
605	2022-12-13 11:45:26.62865+00	30	Tab Ondansetron	1	new through import_export	23	3
606	2022-12-13 11:45:26.629769+00	31	Tab Bisacodyl	1	new through import_export	23	3
607	2022-12-13 11:45:26.630881+00	32	Tab Citrizine 10mg	1	new through import_export	23	3
608	2022-12-13 11:45:26.631962+00	33	Tab Salbutamol 4mg	1	new through import_export	23	3
609	2022-12-13 11:45:26.632866+00	34	Tab Etophylline+ Theophylline	1	new through import_export	23	3
610	2022-12-13 11:45:26.633781+00	35	Tab Chlorpheniramine	1	new through import_export	23	3
611	2022-12-13 11:45:26.634746+00	36	Tab Amitriptyline 10mg	1	new through import_export	23	3
612	2022-12-13 11:45:26.635789+00	37	Tab Risperidone 4mg	1	new through import_export	23	3
613	2022-12-13 11:45:26.63681+00	38	Tab TRIHEXPHENYDYL 2mg	1	new through import_export	23	3
614	2022-12-13 11:45:26.638033+00	39	Aluminium hydroxide+ magnesium hydroxide syrup	1	new through import_export	23	3
615	2022-12-13 11:45:26.639226+00	40	Ambroxyl/ Chlorpheniramine syrup	1	new through import_export	23	3
616	2022-12-13 11:45:26.640562+00	41	Paracetamol 250mg syrup	1	new through import_export	23	3
617	2022-12-13 11:45:26.641673+00	42	Amoxicillin 228.5mg syrup	1	new through import_export	23	3
618	2022-12-13 11:45:26.64272+00	43	ORS powder	1	new through import_export	23	3
619	2022-12-13 11:45:26.643904+00	44	Carboxymethylcellulose eyedrops	1	new through import_export	23	3
620	2022-12-13 11:45:26.645018+00	45	Ciprofloxacin eyedrops	1	new through import_export	23	3
621	2022-12-13 11:45:26.646002+00	46	Moisturizer	1	new through import_export	23	3
622	2022-12-13 11:45:26.646927+00	47	Miconazole ointment	1	new through import_export	23	3
623	2022-12-13 11:45:26.647935+00	48	Diclofenac gel	1	new through import_export	23	3
624	2022-12-13 11:45:26.648832+00	49	Povidone ointment	1	new through import_export	23	3
625	2022-12-13 11:45:26.649738+00	50	Gamma benzene + cetrimide lotion	1	new through import_export	23	3
626	2022-12-13 11:45:26.650897+00	51	Rotahaler	1	new through import_export	23	3
627	2022-12-13 11:45:26.652207+00	52	Salbutamol MDI	1	new through import_export	23	3
628	2022-12-13 11:45:26.653285+00	53	BUDESONIDE MDI	1	new through import_export	23	3
629	2022-12-13 11:45:26.65455+00	54	Formoterol+ BUDESONIDE Rotacaps	1	new through import_export	23	3
630	2022-12-13 12:11:17.097064+00	24	West Bengal	3		11	3
631	2022-12-13 12:11:17.100074+00	23	Uttarakhand	3		11	3
632	2022-12-13 12:11:17.101493+00	22	Uttar Pradesh	3		11	3
633	2022-12-13 12:11:17.102854+00	21	Telangana	3		11	3
634	2022-12-13 12:11:17.104045+00	20	Tamil Nadu	3		11	3
635	2022-12-13 12:11:17.105302+00	19	Rajasthan	3		11	3
636	2022-12-13 12:11:17.106437+00	18	Punjab	3		11	3
637	2022-12-13 12:11:17.10748+00	17	Odisha	3		11	3
638	2022-12-13 12:11:17.108589+00	16	Maharashtra	3		11	3
639	2022-12-13 12:11:17.109639+00	15	Madhya Pradesh	3		11	3
640	2022-12-13 12:11:17.110612+00	14	Ladakh	3		11	3
641	2022-12-13 12:11:17.111499+00	13	Kerala	3		11	3
642	2022-12-13 12:11:17.112362+00	11	Jharkhand	3		11	3
643	2022-12-13 12:11:17.113553+00	10	Himachal Pradesh	3		11	3
644	2022-12-13 12:11:17.114462+00	9	Gujarat	3		11	3
645	2022-12-13 12:11:17.115435+00	8	Goa	3		11	3
646	2022-12-13 12:11:17.116397+00	7	Delhi & NCR (U.P)	3		11	3
647	2022-12-13 12:11:17.117431+00	6	Delhi & NCR (Haryana)	3		11	3
648	2022-12-13 12:11:17.118436+00	5	Delhi & NCR	3		11	3
649	2022-12-13 12:11:17.119347+00	4	Chhattisgarh	3		11	3
650	2022-12-13 12:11:17.120421+00	3	Bihar	3		11	3
651	2022-12-13 12:11:17.121575+00	2	Assam	3		11	3
652	2022-12-13 12:11:17.122472+00	1	Andhra Pradesh	3		11	3
653	2022-12-13 12:11:30.649908+00	24	West Bengal	3		11	3
654	2022-12-13 12:11:30.652676+00	23	Uttarakhand	3		11	3
655	2022-12-13 12:11:30.654074+00	22	Uttar Pradesh	3		11	3
656	2022-12-13 12:11:30.655228+00	21	Telangana	3		11	3
657	2022-12-13 12:11:30.65642+00	20	Tamil Nadu	3		11	3
658	2022-12-13 12:11:30.65756+00	19	Rajasthan	3		11	3
659	2022-12-13 12:11:30.658625+00	18	Punjab	3		11	3
660	2022-12-13 12:11:30.65963+00	17	Odisha	3		11	3
661	2022-12-13 12:11:30.660499+00	16	Maharashtra	3		11	3
662	2022-12-13 12:11:30.661386+00	15	Madhya Pradesh	3		11	3
663	2022-12-13 12:11:30.662291+00	14	Ladakh	3		11	3
664	2022-12-13 12:11:30.663132+00	13	Kerala	3		11	3
665	2022-12-13 12:11:30.66396+00	11	Jharkhand	3		11	3
666	2022-12-13 12:11:30.665005+00	10	Himachal Pradesh	3		11	3
667	2022-12-13 12:11:30.665926+00	9	Gujarat	3		11	3
668	2022-12-13 12:11:30.666742+00	8	Goa	3		11	3
669	2022-12-13 12:11:30.667627+00	7	Delhi & NCR (U.P)	3		11	3
670	2022-12-13 12:11:30.668445+00	6	Delhi & NCR (Haryana)	3		11	3
671	2022-12-13 12:11:30.669823+00	5	Delhi & NCR	3		11	3
672	2022-12-13 12:11:30.670818+00	4	Chhattisgarh	3		11	3
673	2022-12-13 12:11:30.671623+00	3	Bihar	3		11	3
674	2022-12-13 12:11:30.672672+00	2	Assam	3		11	3
675	2022-12-13 12:11:30.673611+00	1	Andhra Pradesh	3		11	3
676	2022-12-13 12:12:03.305377+00	24	West Bengal	3		11	3
677	2022-12-13 12:12:03.310239+00	23	Uttarakhand	3		11	3
678	2022-12-13 12:12:03.313138+00	22	Uttar Pradesh	3		11	3
679	2022-12-13 12:12:03.316369+00	21	Telangana	3		11	3
680	2022-12-13 12:12:03.322031+00	20	Tamil Nadu	3		11	3
681	2022-12-13 12:12:03.324253+00	19	Rajasthan	3		11	3
682	2022-12-13 12:12:03.326369+00	18	Punjab	3		11	3
683	2022-12-13 12:12:03.32849+00	17	Odisha	3		11	3
684	2022-12-13 12:12:03.330871+00	16	Maharashtra	3		11	3
685	2022-12-13 12:12:03.333458+00	15	Madhya Pradesh	3		11	3
686	2022-12-13 12:12:03.335666+00	14	Ladakh	3		11	3
687	2022-12-13 12:12:03.337967+00	13	Kerala	3		11	3
688	2022-12-13 12:12:03.339907+00	11	Jharkhand	3		11	3
689	2022-12-13 12:12:03.34188+00	10	Himachal Pradesh	3		11	3
690	2022-12-13 12:12:03.343921+00	9	Gujarat	3		11	3
691	2022-12-13 12:12:03.345976+00	8	Goa	3		11	3
692	2022-12-13 12:12:03.347804+00	7	Delhi & NCR (U.P)	3		11	3
693	2022-12-13 12:12:03.349703+00	6	Delhi & NCR (Haryana)	3		11	3
694	2022-12-13 12:12:03.351411+00	5	Delhi & NCR	3		11	3
695	2022-12-13 12:12:03.353113+00	4	Chhattisgarh	3		11	3
696	2022-12-13 12:12:03.355025+00	3	Bihar	3		11	3
697	2022-12-13 12:12:03.357044+00	2	Assam	3		11	3
698	2022-12-13 12:12:03.359178+00	1	Andhra Pradesh	3		11	3
700	2022-12-13 12:13:59.029876+00	1	Anekal	2	[{"changed": {"fields": ["Name", "District"]}}]	10	3
701	2022-12-13 12:15:40.250527+00	134	Paschim Barddhaman	3		7	3
702	2022-12-13 12:15:40.258592+00	133	South 24 Pgs	3		7	3
703	2022-12-13 12:15:40.260487+00	132	Purba Bardhaman	3		7	3
704	2022-12-13 12:15:40.262148+00	131	Paschim Bardhaman	3		7	3
705	2022-12-13 12:15:40.26933+00	130	Murshidabad	3		7	3
706	2022-12-13 12:15:40.272281+00	129	Kolkata	3		7	3
707	2022-12-13 12:15:40.27487+00	128	Howrah	3		7	3
708	2022-12-13 12:15:40.278512+00	127	Bankura	3		7	3
709	2022-12-13 12:15:40.284545+00	126	Nainital	3		7	3
710	2022-12-13 12:15:40.286125+00	125	Uttarakashi	3		7	3
711	2022-12-13 12:15:40.290847+00	124	Uttarkashi	3		7	3
712	2022-12-13 12:15:40.292605+00	123	Tehri	3		7	3
713	2022-12-13 12:15:40.294047+00	122	RUDRAPRAYAG	3		7	3
714	2022-12-13 12:15:40.295342+00	121	Pauri Garhwal	3		7	3
715	2022-12-13 12:15:40.296465+00	120	Dehradun	3		7	3
716	2022-12-13 12:15:40.297557+00	119	Chamoli	3		7	3
717	2022-12-13 12:15:40.298779+00	118	LUCKNOW	3		7	3
718	2022-12-13 12:15:40.300556+00	117	Saharanpur	3		7	3
719	2022-12-13 12:15:40.301976+00	116	Moradabad	3		7	3
720	2022-12-13 12:15:40.303046+00	115	Mathura	3		7	3
721	2022-12-13 12:15:40.304126+00	114	Bulandshahr	3		7	3
722	2022-12-13 12:15:40.305258+00	113	Amroha	3		7	3
723	2022-12-13 12:15:40.306449+00	112	Ambedkar Nagar	3		7	3
724	2022-12-13 12:15:40.307748+00	111	Sangareddy	3		7	3
725	2022-12-13 12:15:40.308883+00	110	Mancherial	3		7	3
726	2022-12-13 12:15:40.310223+00	109	Asifabad	3		7	3
727	2022-12-13 12:15:40.311337+00	108	THIRUVALUR	3		7	3
728	2022-12-13 12:15:40.312347+00	107	Tiruvallur	3		7	3
729	2022-12-13 12:15:40.313466+00	106	Tirunelveli	3		7	3
730	2022-12-13 12:15:40.314649+00	105	Thiruvallur	3		7	3
731	2022-12-13 12:15:40.315737+00	104	RAMANATHAPURAM	3		7	3
732	2022-12-13 12:15:40.316887+00	103	MADURAI	3		7	3
733	2022-12-13 12:15:40.317918+00	102	Kanchipuram	3		7	3
734	2022-12-13 12:15:40.318907+00	101	Kancheepuram	3		7	3
735	2022-12-13 12:15:40.32023+00	100	DINDIGUL	3		7	3
736	2022-12-13 12:15:40.321377+00	99	Chennai	3		7	3
737	2022-12-13 12:15:40.322931+00	98	Baran	3		7	3
738	2022-12-13 12:15:40.324077+00	97	Churu	3		7	3
739	2022-12-13 12:15:40.325132+00	96	Bikaner	3		7	3
740	2022-12-13 12:15:40.326234+00	95	SAS Mohali	3		7	3
741	2022-12-13 12:15:40.327334+00	94	Ropar	3		7	3
742	2022-12-13 12:15:40.328404+00	93	Solan	3		7	3
743	2022-12-13 12:15:40.32986+00	92	Sambalpur	3		7	3
744	2022-12-13 12:15:40.330949+00	91	Sundargarh	3		7	3
745	2022-12-13 12:15:40.332068+00	90	Keonjhar	3		7	3
746	2022-12-13 12:15:40.333115+00	89	PURI	3		7	3
747	2022-12-13 12:15:40.334126+00	88	Koraput	3		7	3
748	2022-12-13 12:15:40.335109+00	87	Jagatsinghpur	3		7	3
749	2022-12-13 12:15:40.336307+00	86	Bhadrak	3		7	3
750	2022-12-13 12:15:40.337267+00	85	Balangir	3		7	3
751	2022-12-13 12:15:40.338183+00	84	Angul	3		7	3
752	2022-12-13 12:15:40.339358+00	83	Pune City	3		7	3
753	2022-12-13 12:15:40.340663+00	82	Palghar	3		7	3
754	2022-12-13 12:15:40.342343+00	81	Raigad	3		7	3
755	2022-12-13 12:15:40.343906+00	80	Nasik	3		7	3
756	2022-12-13 12:15:40.345576+00	79	Satara	3		7	3
757	2022-12-13 12:15:40.347148+00	78	Thane	3		7	3
758	2022-12-13 12:15:40.348629+00	77	Satara	3		7	3
759	2022-12-13 12:15:40.350077+00	76	Raigad	3		7	3
760	2022-12-13 12:15:40.351486+00	75	Pune	3		7	3
761	2022-12-13 12:15:40.352755+00	74	Mumbai City	3		7	3
762	2022-12-13 12:15:40.354247+00	73	Mumbai	3		7	3
763	2022-12-13 12:15:40.35573+00	72	Gondia	3		7	3
764	2022-12-13 12:15:40.356899+00	71	CHANDRAPUR	3		7	3
765	2022-12-13 12:15:40.358211+00	70	Ahmednagar	3		7	3
766	2022-12-13 12:15:40.359467+00	69	BHIND	3		7	3
767	2022-12-13 12:15:40.360731+00	68	KHANDWA	3		7	3
768	2022-12-13 12:15:40.362205+00	67	Indore	3		7	3
769	2022-12-13 12:15:40.363523+00	66	Dhar	3		7	3
770	2022-12-13 12:15:40.364822+00	65	Betul	3		7	3
771	2022-12-13 12:15:40.366169+00	64	Leh	3		7	3
772	2022-12-13 12:15:40.367357+00	63	Trivandrum	3		7	3
773	2022-12-13 12:15:40.368519+00	62	BELLARI	3		7	3
774	2022-12-13 12:15:40.369862+00	61	Tumakur.G	3		7	3
775	2022-12-13 12:15:40.371012+00	60	Bangalore.G	3		7	3
776	2022-12-13 12:15:40.372406+00	59	VIJAYANAGARA	3		7	3
778	2022-12-13 12:15:40.375681+00	57	VIJAY NAGAR	3		7	3
779	2022-12-13 12:15:40.376866+00	56	SANDUR	3		7	3
780	2022-12-13 12:15:40.378185+00	55	Raichur	3		7	3
781	2022-12-13 12:15:40.379388+00	54	Mysore	3		7	3
782	2022-12-13 12:15:40.380553+00	53	Chamarajanagar	3		7	3
783	2022-12-13 12:15:40.381745+00	52	Bangalore Urban	3		7	3
784	2022-12-13 12:15:40.383099+00	50	Bangalore	3		7	3
785	2022-12-13 12:15:40.384292+00	49	GODDA	3		7	3
786	2022-12-13 12:15:40.385652+00	48	SHIMLA	3		7	3
787	2022-12-13 12:15:40.387011+00	47	Una	3		7	3
788	2022-12-13 12:15:40.388489+00	46	Solan	3		7	3
789	2022-12-13 12:15:40.390055+00	45	Shimla	3		7	3
790	2022-12-13 12:15:40.391475+00	44	MANDI	3		7	3
791	2022-12-13 12:15:40.392973+00	43	KULLU	3		7	3
792	2022-12-13 12:15:40.39439+00	42	Kinnaur	3		7	3
793	2022-12-13 12:15:40.395714+00	41	KANGRA	3		7	3
794	2022-12-13 12:15:40.396905+00	40	HAMIRPUR	3		7	3
795	2022-12-13 12:15:40.398368+00	39	Chota Udaipur	3		7	3
796	2022-12-13 12:15:40.399515+00	38	Morbi	3		7	3
797	2022-12-13 12:15:40.40055+00	37	Amreli	3		7	3
798	2022-12-13 12:15:40.401669+00	36	Kutch	3		7	3
799	2022-12-13 12:15:40.402657+00	35	Kheda	3		7	3
800	2022-12-13 12:15:40.403654+00	34	Mahisagar	3		7	3
801	2022-12-13 12:15:40.40463+00	33	Dahod	3		7	3
802	2022-12-13 12:15:40.405671+00	32	GIR SOMNATH	3		7	3
803	2022-12-13 12:15:40.406727+00	31	Devbhoomi Dwarka	3		7	3
804	2022-12-13 12:15:40.407769+00	30	Jamnagar	3		7	3
805	2022-12-13 12:15:40.40887+00	29	Anand	3		7	3
806	2022-12-13 12:15:40.409991+00	28	PANCHMAHAL	3		7	3
807	2022-12-13 12:15:40.411001+00	27	VADODARA	3		7	3
808	2022-12-13 12:15:40.412377+00	26	Surendrnagar	3		7	3
809	2022-12-13 12:15:40.413615+00	25	surat	3		7	3
810	2022-12-13 12:15:40.414713+00	24	Mehsana	3		7	3
811	2022-12-13 12:15:40.415973+00	23	Bharuch	3		7	3
812	2022-12-13 12:15:40.417219+00	22	Ahmedabad	3		7	3
813	2022-12-13 12:15:40.418435+00	21	North-Goa	3		7	3
814	2022-12-13 12:15:40.419442+00	20	Delhi & NCR(UP)	3		7	3
815	2022-12-13 12:15:40.420609+00	19	JHAJJAR	3		7	3
816	2022-12-13 12:15:40.421853+00	18	GURUGRAM	3		7	3
817	2022-12-13 12:15:40.423023+00	17	South Delhi	3		7	3
818	2022-12-13 12:15:40.424322+00	16	Rohtak	3		7	3
819	2022-12-13 12:15:40.425619+00	15	Faridabad	3		7	3
820	2022-12-13 12:15:40.426715+00	14	SOUTH	3		7	3
821	2022-12-13 12:15:40.427967+00	13	SOUTH WEST	3		7	3
822	2022-12-13 12:15:40.429173+00	12	Gautam Buddha Nagar	3		7	3
823	2022-12-13 12:15:40.430315+00	11	RAIGARH	3		7	3
824	2022-12-13 12:15:40.431567+00	10	Patna	3		7	3
825	2022-12-13 12:15:40.432642+00	9	Muzaffarpur	3		7	3
826	2022-12-13 12:15:40.433802+00	8	Madhubani	3		7	3
827	2022-12-13 12:15:40.434915+00	7	Darbhanga	3		7	3
828	2022-12-13 12:15:40.436019+00	6	Buxar	3		7	3
829	2022-12-13 12:15:40.437156+00	5	Aurangabad	3		7	3
830	2022-12-13 12:15:40.438429+00	4	Kamrup Metro	3		7	3
831	2022-12-13 12:15:40.439645+00	3	Parvathipuram	3		7	3
832	2022-12-13 12:15:40.440836+00	2	Vijyanagaram	3		7	3
833	2022-12-13 12:15:40.441918+00	1	Visakhapatnam	3		7	3
834	2022-12-13 12:16:25.805209+00	24	West Bengal	3		11	3
835	2022-12-13 12:16:25.807768+00	23	Uttarakhand	3		11	3
836	2022-12-13 12:16:25.809112+00	22	Uttar Pradesh	3		11	3
837	2022-12-13 12:16:25.810181+00	21	Telangana	3		11	3
838	2022-12-13 12:16:25.811168+00	20	Tamil Nadu	3		11	3
839	2022-12-13 12:16:25.812148+00	19	Rajasthan	3		11	3
840	2022-12-13 12:16:25.813126+00	18	Punjab	3		11	3
841	2022-12-13 12:16:25.814026+00	17	Odisha	3		11	3
842	2022-12-13 12:16:25.814865+00	16	Maharashtra	3		11	3
843	2022-12-13 12:16:25.815716+00	15	Madhya Pradesh	3		11	3
844	2022-12-13 12:16:25.816596+00	14	Ladakh	3		11	3
845	2022-12-13 12:16:25.817482+00	13	Kerala	3		11	3
846	2022-12-13 12:16:25.818345+00	11	Jharkhand	3		11	3
847	2022-12-13 12:16:25.819209+00	10	Himachal Pradesh	3		11	3
848	2022-12-13 12:16:25.820093+00	9	Gujarat	3		11	3
849	2022-12-13 12:16:25.821209+00	8	Goa	3		11	3
850	2022-12-13 12:16:25.822127+00	7	Delhi & NCR (U.P)	3		11	3
851	2022-12-13 12:16:25.823077+00	6	Delhi & NCR (Haryana)	3		11	3
852	2022-12-13 12:16:25.824028+00	5	Delhi & NCR	3		11	3
853	2022-12-13 12:16:25.825029+00	4	Chhattisgarh	3		11	3
854	2022-12-13 12:16:25.825928+00	3	Bihar	3		11	3
855	2022-12-13 12:16:25.826761+00	2	Assam	3		11	3
856	2022-12-13 12:16:25.827663+00	1	Andhra Pradesh	3		11	3
857	2022-12-13 12:55:25.892417+00	54	Formoterol+ BUDESONIDE Rotacaps	3		23	3
858	2022-12-13 12:55:25.895506+00	53	BUDESONIDE MDI	3		23	3
859	2022-12-13 12:55:25.896971+00	52	Salbutamol MDI	3		23	3
860	2022-12-13 12:55:25.898313+00	51	Rotahaler	3		23	3
861	2022-12-13 12:55:25.89966+00	50	Gamma benzene + cetrimide lotion	3		23	3
862	2022-12-13 12:55:25.90114+00	49	Povidone ointment	3		23	3
863	2022-12-13 12:55:25.902481+00	48	Diclofenac gel	3		23	3
864	2022-12-13 12:55:25.903676+00	47	Miconazole ointment	3		23	3
865	2022-12-13 12:55:25.904546+00	46	Moisturizer	3		23	3
866	2022-12-13 12:55:25.90551+00	45	Ciprofloxacin eyedrops	3		23	3
867	2022-12-13 12:55:25.906598+00	44	Carboxymethylcellulose eyedrops	3		23	3
868	2022-12-13 12:55:25.907662+00	43	ORS powder	3		23	3
869	2022-12-13 12:55:25.908552+00	42	Amoxicillin 228.5mg syrup	3		23	3
870	2022-12-13 12:55:25.909523+00	41	Paracetamol 250mg syrup	3		23	3
871	2022-12-13 12:55:25.910526+00	40	Ambroxyl/ Chlorpheniramine syrup	3		23	3
872	2022-12-13 12:55:25.911511+00	39	Aluminium hydroxide+ magnesium hydroxide syrup	3		23	3
873	2022-12-13 12:55:25.912409+00	38	Tab TRIHEXPHENYDYL 2mg	3		23	3
874	2022-12-13 12:55:25.913303+00	37	Tab Risperidone 4mg	3		23	3
875	2022-12-13 12:55:25.914194+00	36	Tab Amitriptyline 10mg	3		23	3
876	2022-12-13 12:55:25.915098+00	35	Tab Chlorpheniramine	3		23	3
877	2022-12-13 12:55:25.916097+00	34	Tab Etophylline+ Theophylline	3		23	3
878	2022-12-13 12:55:25.916975+00	33	Tab Salbutamol 4mg	3		23	3
879	2022-12-13 12:55:25.917805+00	32	Tab Citrizine 10mg	3		23	3
880	2022-12-13 12:55:25.918741+00	31	Tab Bisacodyl	3		23	3
881	2022-12-13 12:55:25.919961+00	30	Tab Ondansetron	3		23	3
882	2022-12-13 12:55:25.921013+00	29	Tab Mefenemic acid + Dicyclomine	3		23	3
883	2022-12-13 12:55:25.922054+00	28	Tab Domperidone	3		23	3
884	2022-12-13 12:55:25.923221+00	27	Tab Lactobacillus	3		23	3
885	2022-12-13 12:55:25.92452+00	26	Cap Omeprazole 20mg	3		23	3
886	2022-12-13 12:55:25.925535+00	25	Tab Pregabalin 75mg	3		23	3
887	2022-12-13 12:55:25.926448+00	24	Tab Diclofenac 100mg	3		23	3
888	2022-12-13 12:55:25.927513+00	23	Tab Tramadol 50mg	3		23	3
889	2022-12-13 12:55:25.928657+00	22	Tab Paracetamol 650mg	3		23	3
890	2022-12-13 12:55:25.929687+00	21	Tab Albendazole 400mg	3		23	3
891	2022-12-13 12:55:25.93068+00	20	Tab Fluconazole 150mg	3		23	3
892	2022-12-13 12:55:25.931993+00	19	Tab Metronidazole 400mg	3		23	3
893	2022-12-13 12:55:25.935997+00	18	Tab Cefexime 200 mg	3		23	3
894	2022-12-13 12:55:25.937576+00	17	Tab Amoxicillin+ potassium clavunate 625mg	3		23	3
895	2022-12-13 12:55:25.93898+00	16	Tab Calcium+ Vitamin D3	3		23	3
896	2022-12-13 12:55:25.940478+00	15	Tab Zinc	3		23	3
897	2022-12-13 12:55:25.941622+00	14	Tab C	3		23	3
898	2022-12-13 12:55:25.943075+00	13	Tab Iron sulphate + Folic acid	3		23	3
899	2022-12-13 12:55:25.944389+00	12	Tab Multivitamin B complex	3		23	3
900	2022-12-13 12:55:25.945454+00	11	Tab Voglibose (0.2mg)+Metformin (500mg)+Glimeperide (2mg)	3		23	3
901	2022-12-13 12:55:25.946504+00	10	Tab PIOGLITAZONE (15mg)+Metformin (500mg)+Glimeperide (2mg)	3		23	3
902	2022-12-13 12:55:25.947582+00	9	Tab Glimeperide 2mg	3		23	3
903	2022-12-13 12:55:25.948531+00	8	Tab Glimeperide 1mg	3		23	3
904	2022-12-13 12:55:25.949441+00	7	Tab Metformin 1000mg	3		23	3
905	2022-12-13 12:55:25.950408+00	6	Tab Metformin 500mg	3		23	3
906	2022-12-13 12:55:25.951602+00	5	Tab Metoprolol 50mg	3		23	3
907	2022-12-13 12:55:25.952728+00	4	Tab Atenolol 50mg	3		23	3
908	2022-12-13 12:55:25.953747+00	3	Tab Hydrochlorothiazide 25mg	3		23	3
909	2022-12-13 12:55:25.954843+00	2	Tab Telmisartan 40mg	3		23	3
910	2022-12-13 12:55:25.95611+00	1	Tab AMLODIPINE 5mg	3		23	3
911	2022-12-13 12:55:51.290423+00	1	ANTIHYPERTENSIVES	1	new through import_export	23	3
912	2022-12-13 12:55:51.292721+00	2	ANTIDIABETICS	1	new through import_export	23	3
913	2022-12-13 12:55:51.294445+00	3	Vitamins and minerals	1	new through import_export	23	3
914	2022-12-13 12:55:51.296034+00	4	Antibiotics	1	new through import_export	23	3
915	2022-12-13 12:55:51.297485+00	5	Antifungal	1	new through import_export	23	3
916	2022-12-13 12:55:51.298775+00	6	Antiparasitic	1	new through import_export	23	3
917	2022-12-13 12:55:51.30018+00	7	NSAIDS and related	1	new through import_export	23	3
918	2022-12-13 12:55:51.301453+00	8	Digestive system related 	1	new through import_export	23	3
919	2022-12-13 12:55:51.302558+00	9	Respiratory system related	1	new through import_export	23	3
920	2022-12-13 12:55:51.303887+00	10	Psychiatry drugs	1	new through import_export	23	3
921	2022-12-13 12:55:51.305091+00	11	Syrups and powder	1	new through import_export	23	3
922	2022-12-13 12:55:51.306218+00	12	Eye drops	1	new through import_export	23	3
923	2022-12-13 12:55:51.30755+00	13	Ointments and lotions	1	new through import_export	23	3
924	2022-12-13 12:55:51.308819+00	14	Pumps and inhaler	1	new through import_export	23	3
925	2022-12-13 12:55:51.309991+00	15	Tab AMLODIPINE 5mg	1	new through import_export	23	3
926	2022-12-13 12:55:51.311445+00	16	Tab Telmisartan 40mg	1	new through import_export	23	3
927	2022-12-13 12:55:51.312777+00	17	Tab Hydrochlorothiazide 25mg	1	new through import_export	23	3
928	2022-12-13 12:55:51.31441+00	18	Tab Atenolol 50mg	1	new through import_export	23	3
929	2022-12-13 12:55:51.315845+00	19	Tab Metoprolol 50mg	1	new through import_export	23	3
930	2022-12-13 12:55:51.317171+00	20	Tab Metformin 500mg	1	new through import_export	23	3
931	2022-12-13 12:55:51.318332+00	21	Tab Metformin 1000mg	1	new through import_export	23	3
932	2022-12-13 12:55:51.319389+00	22	Tab Glimeperide 1mg	1	new through import_export	23	3
933	2022-12-13 12:55:51.320401+00	23	Tab Glimeperide 2mg	1	new through import_export	23	3
934	2022-12-13 12:55:51.321662+00	24	Tab PIOGLITAZONE (15mg)+Metformin (500mg)+Glimeperide (2mg)	1	new through import_export	23	3
935	2022-12-13 12:55:51.322715+00	25	Tab Voglibose (0.2mg)+Metformin (500mg)+Glimeperide (2mg)	1	new through import_export	23	3
936	2022-12-13 12:55:51.323919+00	26	Tab Multivitamin B complex	1	new through import_export	23	3
937	2022-12-13 12:55:51.32506+00	27	Tab Iron sulphate + Folic acid	1	new through import_export	23	3
938	2022-12-13 12:55:51.326266+00	28	Tab C	1	new through import_export	23	3
939	2022-12-13 12:55:51.327484+00	29	Tab Zinc	1	new through import_export	23	3
940	2022-12-13 12:55:51.328605+00	30	Tab Calcium+ Vitamin D3	1	new through import_export	23	3
941	2022-12-13 12:55:51.329703+00	31	Tab Amoxicillin+ potassium clavunate 625mg	1	new through import_export	23	3
942	2022-12-13 12:55:51.330881+00	32	Tab Cefexime 200 mg	1	new through import_export	23	3
943	2022-12-13 12:55:51.332364+00	33	Tab Metronidazole 400mg	1	new through import_export	23	3
944	2022-12-13 12:55:51.333633+00	34	Tab Fluconazole 150mg	1	new through import_export	23	3
945	2022-12-13 12:55:51.335053+00	35	Tab Albendazole 400mg	1	new through import_export	23	3
946	2022-12-13 12:55:51.336395+00	36	Tab Paracetamol 650mg	1	new through import_export	23	3
947	2022-12-13 12:55:51.337736+00	37	Tab Tramadol 50mg	1	new through import_export	23	3
948	2022-12-13 12:55:51.33897+00	38	Tab Diclofenac 100mg	1	new through import_export	23	3
949	2022-12-13 12:55:51.340395+00	39	Tab Pregabalin 75mg	1	new through import_export	23	3
950	2022-12-13 12:55:51.341582+00	40	Cap Omeprazole 20mg	1	new through import_export	23	3
951	2022-12-13 12:55:51.343118+00	41	Tab Lactobacillus	1	new through import_export	23	3
952	2022-12-13 12:55:51.344325+00	42	Tab Domperidone	1	new through import_export	23	3
953	2022-12-13 12:55:51.345456+00	43	Tab Mefenemic acid + Dicyclomine	1	new through import_export	23	3
954	2022-12-13 12:55:51.3467+00	44	Tab Ondansetron	1	new through import_export	23	3
955	2022-12-13 12:55:51.347887+00	45	Tab Bisacodyl	1	new through import_export	23	3
956	2022-12-13 12:55:51.348928+00	46	Tab Citrizine 10mg	1	new through import_export	23	3
957	2022-12-13 12:55:51.349968+00	47	Tab Salbutamol 4mg	1	new through import_export	23	3
958	2022-12-13 12:55:51.351113+00	48	Tab Etophylline+ Theophylline	1	new through import_export	23	3
959	2022-12-13 12:55:51.35234+00	49	Tab Chlorpheniramine	1	new through import_export	23	3
960	2022-12-13 12:55:51.353831+00	50	Tab Amitriptyline 10mg	1	new through import_export	23	3
961	2022-12-13 12:55:51.355113+00	51	Tab Risperidone 4mg	1	new through import_export	23	3
962	2022-12-13 12:55:51.356384+00	52	Tab TRIHEXPHENYDYL 2mg	1	new through import_export	23	3
963	2022-12-13 12:55:51.35745+00	53	Aluminium hydroxide+ magnesium hydroxide syrup	1	new through import_export	23	3
964	2022-12-13 12:55:51.358596+00	54	Ambroxyl/ Chlorpheniramine syrup	1	new through import_export	23	3
965	2022-12-13 12:55:51.359879+00	55	Paracetamol 250mg syrup	1	new through import_export	23	3
966	2022-12-13 12:55:51.36077+00	56	Amoxicillin 228.5mg syrup	1	new through import_export	23	3
967	2022-12-13 12:55:51.361769+00	57	ORS powder	1	new through import_export	23	3
968	2022-12-13 12:55:51.362701+00	58	Carboxymethylcellulose eyedrops	1	new through import_export	23	3
969	2022-12-13 12:55:51.363756+00	59	Ciprofloxacin eyedrops	1	new through import_export	23	3
970	2022-12-13 12:55:51.364931+00	60	Moisturizer	1	new through import_export	23	3
971	2022-12-13 12:55:51.365932+00	61	Miconazole ointment	1	new through import_export	23	3
972	2022-12-13 12:55:51.367016+00	62	Diclofenac gel	1	new through import_export	23	3
973	2022-12-13 12:55:51.36823+00	63	Povidone ointment	1	new through import_export	23	3
974	2022-12-13 12:55:51.369167+00	64	Gamma benzene + cetrimide lotion	1	new through import_export	23	3
975	2022-12-13 12:55:51.37003+00	65	Rotahaler	1	new through import_export	23	3
976	2022-12-13 12:55:51.370943+00	66	Salbutamol MDI	1	new through import_export	23	3
977	2022-12-13 12:55:51.372145+00	67	BUDESONIDE MDI	1	new through import_export	23	3
978	2022-12-13 12:55:51.373239+00	68	Formoterol+ BUDESONIDE Rotacaps	1	new through import_export	23	3
979	2022-12-14 10:21:47.447874+00	51	Bangalore urban	2	[{"changed": {"fields": ["Name"]}}]	7	2
980	2022-12-15 07:25:07.775356+00	11	KHT	2	[{"changed": {"fields": ["Name"]}}]	12	2
981	2022-12-15 07:25:19.087013+00	10	KDM	2	[{"changed": {"fields": ["Name"]}}]	12	2
982	2022-12-15 07:25:29.41329+00	9	NHT	2	[{"changed": {"fields": ["Name"]}}]	12	2
983	2022-12-15 07:25:41.690021+00	8	NDM	2	[{"changed": {"fields": ["Name"]}}]	12	2
984	2022-12-15 07:25:52.440857+00	7	PHT	2	[{"changed": {"fields": ["Name"]}}]	12	2
985	2022-12-15 07:26:05.08915+00	5	PDM	2	[{"changed": {"fields": ["Name"]}}]	12	2
986	2022-12-15 07:27:55.466539+00	14	Dosages	1	[{"added": {}}]	12	2
987	2022-12-15 07:28:35.47308+00	15	OD	1	[{"added": {}}]	12	2
988	2022-12-15 07:28:46.635408+00	16	BD	1	[{"added": {}}]	12	2
989	2022-12-15 07:28:59.262358+00	17	TID	1	[{"added": {}}]	12	2
990	2022-12-15 07:29:11.391663+00	18	SOS	1	[{"added": {}}]	12	2
991	2022-12-15 07:29:31.556958+00	19	HS	1	[{"added": {}}]	12	2
992	2022-12-15 07:29:49.796886+00	20	WEEKLY ONCE	1	[{"added": {}}]	12	2
993	2022-12-15 07:46:19.342239+00	20	WEEKLY ONCE	3		12	2
994	2022-12-15 07:46:19.344848+00	19	HS	3		12	2
995	2022-12-15 07:46:19.3461+00	18	SOS	3		12	2
996	2022-12-15 07:46:19.34713+00	17	TID	3		12	2
997	2022-12-15 07:46:19.351901+00	16	BD	3		12	2
998	2022-12-15 07:46:19.353207+00	15	OD	3		12	2
999	2022-12-15 07:46:19.354157+00	14	Dosages	3		12	2
1000	2022-12-15 12:14:02.657333+00	6	Dosage object (6)	1	new through import_export	24	2
1001	2022-12-15 12:14:02.659331+00	5	Dosage object (5)	1	new through import_export	24	2
1002	2022-12-15 12:14:02.660456+00	4	Dosage object (4)	1	new through import_export	24	2
1003	2022-12-15 12:14:02.66148+00	3	Dosage object (3)	1	new through import_export	24	2
1004	2022-12-15 12:14:02.662422+00	2	Dosage object (2)	1	new through import_export	24	2
1005	2022-12-15 12:14:02.663328+00	1	Dosage object (1)	1	new through import_export	24	2
1006	2022-12-16 09:54:10.81355+00	12	Karnataka	2	[{"changed": {"fields": ["Code"]}}]	11	3
1007	2022-12-16 09:54:22.607256+00	51	Bangalore urban	2	[{"changed": {"fields": ["Code"]}}]	7	3
1008	2022-12-16 09:55:14.454515+00	1	Anekal	2	[{"changed": {"fields": ["Code"]}}]	10	3
1009	2022-12-19 06:16:23.344985+00	1	Anekal	2	[{"changed": {"fields": ["Code"]}}]	10	3
1010	2022-12-19 07:28:32.636704+00	30	MUTTURU	3		9	3
1011	2022-12-19 07:28:32.641322+00	29	BASAVANAPURA	3		9	3
1012	2022-12-19 07:28:32.643738+00	28	LAKSHMIPURA	3		9	3
1013	2022-12-19 07:28:32.646277+00	27	AREHALLI	3		9	3
1014	2022-12-19 07:28:32.648829+00	26	KARAKALAGATTA JANATHA COLONY	3		9	3
1015	2022-12-19 07:28:32.651926+00	25	KARAKALAGATTA	3		9	3
1016	2022-12-19 07:28:32.655095+00	24	CHOODAHALLI	3		9	3
1017	2022-12-19 07:28:32.657929+00	23	TAMMANAYAKANAHALLI	3		9	3
1018	2022-12-19 07:28:32.660844+00	22	NALLAYANADODDI	3		9	3
1019	2022-12-19 07:28:32.664113+00	21	CHIKKAHOSALLI	3		9	3
1020	2022-12-19 07:28:32.667049+00	20	TELAGARAHALLI	3		9	3
1021	2022-12-19 07:28:32.669981+00	19	KEMPADOMMASANDRA	3		9	3
1022	2022-12-19 07:28:32.67291+00	18	SINGASANDRA	3		9	3
1023	2022-12-19 07:28:32.675993+00	17	MENASIGANAHALLI	3		9	3
1024	2022-12-19 07:28:32.679564+00	16	P GOLLAHALLI	3		9	3
1025	2022-12-19 07:28:32.682835+00	15	CHODENAHALLI	3		9	3
1026	2022-12-19 07:28:32.685803+00	14	SUNAVARA	3		9	3
1027	2022-12-19 07:28:32.688561+00	13	KALANAYAKANAHALLI	3		9	3
1028	2022-12-19 07:28:32.691317+00	12	SOLLORU	3		9	3
1029	2022-12-19 07:28:32.694096+00	11	VANAKANAHALLI	3		9	3
1030	2022-12-19 07:28:32.696853+00	10	BANGLADODDI	3		9	3
1031	2022-12-19 07:28:32.70002+00	9	TIMMASANDRA	3		9	3
1032	2022-12-19 07:28:32.703138+00	8	INDLAWADI PURA	3		9	3
1033	2022-12-19 07:28:32.705977+00	7	CHIKKNAHALLI	3		9	3
1034	2022-12-19 07:28:32.709087+00	6	NAGAYANADODDI	3		9	3
1035	2022-12-19 07:28:32.712234+00	5	TIMMYANADODDI	3		9	3
1036	2022-12-19 07:28:32.715275+00	4	BAGGANADODDI	3		9	3
1037	2022-12-19 07:28:32.718373+00	3	MYSORAMANADODDI	3		9	3
1038	2022-12-19 07:28:32.721431+00	2	KADUJAKKANAHALLI	3		9	3
1039	2022-12-19 07:28:32.724601+00	1	Allikhanudupalem	3		9	3
1040	2022-12-19 07:30:41.354095+00	3	CHIKKAHOSALLI	3		8	3
1041	2022-12-19 07:30:41.358668+00	2	VANAKANAHALLI	3		8	3
1042	2022-12-19 07:42:35.433856+00	14	Diagnosis object (14)	3		19	3
1043	2022-12-19 07:42:35.440257+00	13	Diagnosis object (13)	3		19	3
1044	2022-12-19 07:42:35.448252+00	12	Diagnosis object (12)	3		19	3
1045	2022-12-19 07:42:35.451005+00	11	Diagnosis object (11)	3		19	3
1046	2022-12-19 07:42:35.454208+00	10	Diagnosis object (10)	3		19	3
1047	2022-12-19 07:42:35.456934+00	5	Diagnosis object (5)	3		19	3
1048	2022-12-19 07:42:44.20463+00	104	Jayant	3		18	3
1049	2022-12-19 07:42:44.208667+00	103	usha1	3		18	3
1050	2022-12-19 07:42:44.211176+00	102	suhail	3		18	3
1051	2022-12-19 07:42:44.213806+00	101	Rohit 	3		18	3
1052	2022-12-19 07:42:44.216406+00	100	ravi 	3		18	3
1053	2022-12-19 07:42:44.219053+00	46	Anita	3		18	3
1054	2022-12-19 07:42:44.221882+00	37	Barat	3		18	3
1055	2022-12-19 07:42:44.224572+00	36	Abhi	3		18	3
1056	2022-12-19 07:42:44.227798+00	35	Manju	3		18	3
1057	2022-12-19 07:42:44.230823+00	28	ritu	3		18	3
1058	2022-12-19 07:42:44.23376+00	27	Rohit	3		18	3
1059	2022-12-19 07:42:44.236807+00	19	mohit	3		18	3
1060	2022-12-19 07:42:44.239639+00	18	rohit	3		18	3
1063	2022-12-19 07:42:53.249291+00	12	Tab Paracetamol 650mg	3		17	3
1064	2022-12-19 07:42:53.255309+00	11	Tab Fluconazole 150mg	3		17	3
1065	2022-12-19 07:42:53.258184+00	10	Tab Albendazole 400mg	3		17	3
1066	2022-12-19 07:42:53.261106+00	9	Tab Metformin 500mg	3		17	3
1067	2022-12-19 07:42:53.264026+00	8	Tab PIOGLITAZONE (15mg)+Metformin (500mg)+Glimeperide (2mg)	3		17	3
1068	2022-12-19 07:42:53.266943+00	7	Tab Zinc	3		17	3
1069	2022-12-19 07:43:00.34741+00	4	Scanned_Report object (4)	3		16	3
1070	2022-12-19 07:43:10.726476+00	11	Treatments object (11)	3		15	3
1071	2022-12-19 07:43:10.730525+00	10	Treatments object (10)	3		15	3
1072	2022-12-19 07:43:10.73318+00	9	Treatments object (9)	3		15	3
1073	2022-12-19 07:43:10.735754+00	8	Treatments object (8)	3		15	3
1074	2022-12-19 07:43:10.738332+00	7	Treatments object (7)	3		15	3
1075	2022-12-19 07:43:10.740875+00	4	Treatments object (4)	3		15	3
1076	2022-12-19 07:43:19.547853+00	3	doctor1	3		21	3
1077	2022-12-19 07:43:19.586616+00	2	hw	3		21	3
1078	2022-12-19 07:43:19.589923+00	1	admin2	3		21	3
1079	2022-12-19 07:43:31.91826+00	30	MUTTURU	3		9	3
1080	2022-12-19 07:43:31.921455+00	29	BASAVANAPURA	3		9	3
1081	2022-12-19 07:43:31.924343+00	28	LAKSHMIPURA	3		9	3
1082	2022-12-19 07:43:31.926705+00	27	AREHALLI	3		9	3
1083	2022-12-19 07:43:31.929097+00	26	KARAKALAGATTA JANATHA COLONY	3		9	3
1084	2022-12-19 07:43:31.931601+00	25	KARAKALAGATTA	3		9	3
1085	2022-12-19 07:43:31.934169+00	24	CHOODAHALLI	3		9	3
1086	2022-12-19 07:43:31.936942+00	23	TAMMANAYAKANAHALLI	3		9	3
1087	2022-12-19 07:43:31.939548+00	22	NALLAYANADODDI	3		9	3
1088	2022-12-19 07:43:31.942448+00	21	CHIKKAHOSALLI	3		9	3
1089	2022-12-19 07:43:31.945144+00	20	TELAGARAHALLI	3		9	3
1090	2022-12-19 07:43:31.947889+00	19	KEMPADOMMASANDRA	3		9	3
1091	2022-12-19 07:43:31.950781+00	18	SINGASANDRA	3		9	3
1092	2022-12-19 07:43:31.953628+00	17	MENASIGANAHALLI	3		9	3
1093	2022-12-19 07:43:31.956537+00	16	P GOLLAHALLI	3		9	3
1094	2022-12-19 07:43:40.518553+00	15	CHODENAHALLI	3		9	3
1095	2022-12-19 07:43:40.52138+00	14	SUNAVARA	3		9	3
1096	2022-12-19 07:43:40.523807+00	13	KALANAYAKANAHALLI	3		9	3
1097	2022-12-19 07:43:40.526249+00	12	SOLLORU	3		9	3
1098	2022-12-19 07:43:40.528863+00	11	VANAKANAHALLI	3		9	3
1099	2022-12-19 07:43:40.531481+00	10	BANGLADODDI	3		9	3
1100	2022-12-19 07:43:40.534216+00	9	TIMMASANDRA	3		9	3
1101	2022-12-19 07:43:40.537036+00	8	INDLAWADI PURA	3		9	3
1102	2022-12-19 07:43:40.539904+00	7	CHIKKNAHALLI	3		9	3
1103	2022-12-19 07:43:40.543127+00	6	NAGAYANADODDI	3		9	3
1104	2022-12-19 07:43:40.54609+00	5	TIMMYANADODDI	3		9	3
1105	2022-12-19 07:43:40.549286+00	4	BAGGANADODDI	3		9	3
1106	2022-12-19 07:43:40.55237+00	3	MYSORAMANADODDI	3		9	3
1107	2022-12-19 07:43:40.555269+00	2	KADUJAKKANAHALLI	3		9	3
1108	2022-12-19 07:43:40.558412+00	1	Allikhanudupalem	3		9	3
1109	2022-12-19 07:43:55.260858+00	9	RUHI	3		18	3
1110	2022-12-19 07:44:01.92566+00	15	CHODENAHALLI	3		9	3
1111	2022-12-19 07:44:01.928737+00	14	SUNAVARA	3		9	3
1112	2022-12-19 07:44:01.931165+00	13	KALANAYAKANAHALLI	3		9	3
1113	2022-12-19 07:44:01.933456+00	12	SOLLORU	3		9	3
1114	2022-12-19 07:44:01.935766+00	11	VANAKANAHALLI	3		9	3
1115	2022-12-19 07:44:01.938394+00	10	BANGLADODDI	3		9	3
1116	2022-12-19 07:44:01.940921+00	9	TIMMASANDRA	3		9	3
1117	2022-12-19 07:44:01.943313+00	8	INDLAWADI PURA	3		9	3
1118	2022-12-19 07:44:01.945904+00	7	CHIKKNAHALLI	3		9	3
1119	2022-12-19 07:44:01.948605+00	6	NAGAYANADODDI	3		9	3
1120	2022-12-19 07:44:01.95098+00	5	TIMMYANADODDI	3		9	3
1121	2022-12-19 07:44:01.953452+00	4	BAGGANADODDI	3		9	3
1122	2022-12-19 07:44:01.956147+00	3	MYSORAMANADODDI	3		9	3
1123	2022-12-19 07:44:01.958996+00	2	KADUJAKKANAHALLI	3		9	3
1124	2022-12-19 07:44:01.96166+00	1	Allikhanudupalem	3		9	3
1125	2022-12-19 07:44:16.109983+00	3	CHIKKAHOSALLI	3		8	3
1126	2022-12-19 07:44:16.114147+00	2	VANAKANAHALLI	3		8	3
1127	2022-12-19 07:46:00.427209+00	1	INDLAWADI	2	[{"changed": {"fields": ["Code"]}}]	8	3
1128	2022-12-19 07:50:42.462169+00	1	Dari ambatoli	1	[{"added": {}}]	25	3
1129	2022-12-19 08:46:13.716513+00	1	Dari ambatoli	3		25	3
1130	2022-12-19 08:46:57.223326+00	1	INDLAWADI	1	new through import_export	25	3
1131	2022-12-19 08:46:57.227229+00	2	VANAKANAHALLI	1	new through import_export	25	3
1132	2022-12-19 08:46:57.231223+00	3	CHIKKAHOSALLI	1	new through import_export	25	3
1133	2022-12-19 08:47:31.653352+00	31	Dari ambatoli	1	[{"added": {}}]	9	3
1134	2022-12-19 08:54:36.641885+00	31	Dari ambatoli	3		9	3
1135	2022-12-19 08:56:55.102159+00	1	INDLAWADI	1	new through import_export	9	3
1136	2022-12-19 08:56:55.105163+00	2	KADUJAKKANAHALLI	1	new through import_export	9	3
1137	2022-12-19 08:56:55.107593+00	3	MYSORAMANADODDI	1	new through import_export	9	3
1138	2022-12-19 08:56:55.109854+00	4	BAGGANADODDI	1	new through import_export	9	3
1139	2022-12-19 08:56:55.112187+00	5	TIMMYANADODDI	1	new through import_export	9	3
1140	2022-12-19 08:56:55.114581+00	6	NAGAYANADODDI	1	new through import_export	9	3
1141	2022-12-19 08:56:55.11683+00	7	CHIKKNAHALLI	1	new through import_export	9	3
1142	2022-12-19 08:56:55.118958+00	8	INDLAWADI PURA	1	new through import_export	9	3
1143	2022-12-19 08:56:55.12123+00	9	TIMMASANDRA	1	new through import_export	9	3
1144	2022-12-19 08:56:55.123868+00	10	BANGLADODDI	1	new through import_export	9	3
1145	2022-12-19 08:56:55.126244+00	11	VANAKANAHALLI	1	new through import_export	9	3
1146	2022-12-19 08:56:55.128831+00	12	SOLLORU	1	new through import_export	9	3
1147	2022-12-19 08:56:55.131287+00	13	KALANAYAKANAHALLI	1	new through import_export	9	3
1148	2022-12-19 08:56:55.133689+00	14	SUNAVARA	1	new through import_export	9	3
1149	2022-12-19 08:56:55.136285+00	15	CHODENAHALLI	1	new through import_export	9	3
1150	2022-12-19 08:56:55.138888+00	16	P GOLLAHALLI	1	new through import_export	9	3
1151	2022-12-19 08:56:55.141701+00	17	MENASIGANAHALLI	1	new through import_export	9	3
1152	2022-12-19 08:56:55.144574+00	18	SINGASANDRA	1	new through import_export	9	3
1153	2022-12-19 08:56:55.147366+00	19	KEMPADOMMASANDRA	1	new through import_export	9	3
1154	2022-12-19 08:56:55.150122+00	20	TELAGARAHALLI	1	new through import_export	9	3
1155	2022-12-19 08:56:55.152847+00	21	CHIKKAHOSALLI	1	new through import_export	9	3
1156	2022-12-19 08:56:55.155796+00	22	NALLAYANADODDI	1	new through import_export	9	3
1157	2022-12-19 08:56:55.159065+00	23	TAMMANAYAKANAHALLI	1	new through import_export	9	3
1158	2022-12-19 08:56:55.161929+00	24	CHOODAHALLI	1	new through import_export	9	3
1159	2022-12-19 08:56:55.165005+00	25	KARAKALAGATTA	1	new through import_export	9	3
1160	2022-12-19 08:56:55.168194+00	26	KARAKALAGATTA JANATHA COLONY 	1	new through import_export	9	3
1161	2022-12-19 08:56:55.170979+00	27	AREHALLI	1	new through import_export	9	3
1162	2022-12-19 08:56:55.173803+00	28	LAKSHMIPURA	1	new through import_export	9	3
1163	2022-12-19 08:56:55.176731+00	29	BASAVANAPURA	1	new through import_export	9	3
1164	2022-12-19 08:56:55.179887+00	30	MUTTURU	1	new through import_export	9	3
1165	2022-12-19 08:56:55.183383+00	31		1	new through import_export	9	3
1166	2022-12-19 08:57:08.131483+00	31		3		9	3
1167	2022-12-19 08:57:51.343801+00	4	hm_admin	1	[{"added": {}}]	21	3
1168	2022-12-19 09:18:24.080885+00	13	Vitamins and minerals	2	[{"changed": {"fields": ["Medicines"]}}]	17	3
1169	2022-12-19 10:02:28.485644+00	5	admin	1	[{"added": {}}]	21	3
1170	2022-12-19 10:02:47.554195+00	6	doctor1	1	[{"added": {}}]	21	3
1171	2022-12-19 11:33:28.90339+00	5	hw	2	[{"changed": {"fields": ["User"]}}]	21	3
1172	2022-12-19 12:01:08.738028+00	118	RUHI	3		18	3
1173	2022-12-20 12:41:45.600235+00	8	DM	2	[{"changed": {"fields": ["Name"]}}]	12	3
1174	2022-12-20 12:41:56.42016+00	9	HT	2	[{"changed": {"fields": ["Name"]}}]	12	3
1175	2022-12-28 05:57:17.181124+00	14	Pumps and inhaler	1	new through import_export	26	3
1176	2022-12-28 05:57:17.185214+00	13	Ointments and lotions	1	new through import_export	26	3
1177	2022-12-28 05:57:17.186695+00	12	Eye drops	1	new through import_export	26	3
1178	2022-12-28 05:57:17.18808+00	11	Syrups and powder	1	new through import_export	26	3
1179	2022-12-28 05:57:17.189294+00	10	Psychiatry drugs	1	new through import_export	26	3
1180	2022-12-28 05:57:17.190432+00	9	Respiratory system related	1	new through import_export	26	3
1181	2022-12-28 05:57:17.191568+00	8	Digestive system related	1	new through import_export	26	3
1182	2022-12-28 05:57:17.192797+00	7	NSAIDS and related	1	new through import_export	26	3
1183	2022-12-28 05:57:17.193847+00	6	Antiparasitic	1	new through import_export	26	3
1184	2022-12-28 05:57:17.194934+00	5	Antifungal	1	new through import_export	26	3
1185	2022-12-28 05:57:17.195928+00	4	Antibiotics	1	new through import_export	26	3
1186	2022-12-28 05:57:17.196947+00	3	Vitamins and minerals	1	new through import_export	26	3
1187	2022-12-28 05:57:17.197805+00	2	ANTIDIABETICS	1	new through import_export	26	3
1188	2022-12-28 05:57:17.198931+00	1	ANTIHYPERTENSIVES	1	new through import_export	26	3
1189	2022-12-29 05:41:22.785891+00	3	hmadmin	2	[{"changed": {"fields": ["Username"]}}]	4	3
1190	2022-12-29 05:41:51.599193+00	3	hmadmin	2	[{"changed": {"fields": ["password"]}}]	4	3
1191	2023-01-10 16:54:29.802506+00	32	Aveda Sb	3		9	3
1192	2023-01-13 05:15:01.867584+00	2	MedicineStock object (2)	3		28	3
1193	2023-01-13 05:15:01.874684+00	1	MedicineStock object (1)	3		28	3
1194	2023-01-17 09:04:29.848433+00	7	HwEmy01	1	[{"added": {}}]	4	3
1195	2023-01-17 09:04:59.939005+00	7	HwEmy01	2	[{"changed": {"fields": ["First name", "Email address"]}}]	4	3
1196	2023-01-17 09:05:14.500369+00	7	HwEmy01	2	[{"changed": {"fields": ["Staff status"]}}]	4	3
1197	2023-01-17 09:05:53.63127+00	8	HwEmy02	1	[{"added": {}}]	4	3
1198	2023-01-17 09:06:14.383066+00	8	HwEmy02	2	[{"changed": {"fields": ["First name", "Email address", "Staff status"]}}]	4	3
1199	2023-01-17 09:06:34.442859+00	9	HwEmy03	1	[{"added": {}}]	4	3
1200	2023-01-17 09:07:18.085956+00	9	HwEmy03	2	[{"changed": {"fields": ["First name", "Email address", "Staff status"]}}]	4	3
1201	2023-01-17 09:07:57.951963+00	10	HwEmy04	1	[{"added": {}}]	4	3
1202	2023-01-17 09:08:20.939067+00	10	HwEmy04	2	[{"changed": {"fields": ["First name", "Email address", "Staff status"]}}]	4	3
1203	2023-01-17 09:08:44.837073+00	11	HwEmy05	1	[{"added": {}}]	4	3
1204	2023-01-17 09:09:03.592929+00	11	HwEmy05	2	[{"changed": {"fields": ["First name", "Email address", "Staff status"]}}]	4	3
1205	2023-01-17 09:09:22.82185+00	12	HwEmy06	1	[{"added": {}}]	4	3
1206	2023-01-17 09:10:09.833249+00	12	HwEmy06	2	[{"changed": {"fields": ["First name", "Email address", "Staff status"]}}]	4	3
1207	2023-01-17 09:13:07.463212+00	13	HwEmy07	1	[{"added": {}}]	4	3
1208	2023-01-17 09:13:42.664413+00	13	HwEmy07	2	[{"changed": {"fields": ["First name", "Email address", "Staff status"]}}]	4	3
1209	2023-01-17 09:14:03.975591+00	14	HwEmy08	1	[{"added": {}}]	4	3
1210	2023-01-17 09:14:33.350182+00	14	HwEmy08	2	[{"changed": {"fields": ["First name", "Last name", "Staff status"]}}]	4	3
1211	2023-01-17 09:14:59.465145+00	14	HwEmy08	2	[{"changed": {"fields": ["First name", "Last name", "Email address"]}}]	4	3
1212	2023-01-17 09:15:26.720217+00	15	HwEmy09	1	[{"added": {}}]	4	3
1213	2023-01-17 09:15:50.473242+00	15	HwEmy09	2	[{"changed": {"fields": ["First name", "Email address", "Staff status"]}}]	4	3
1214	2023-01-17 09:16:20.188588+00	16	HwEmy10	1	[{"added": {}}]	4	3
1215	2023-01-17 09:16:50.511361+00	16	HwEmy10	2	[{"changed": {"fields": ["First name", "Email address", "Staff status"]}}]	4	3
1216	2023-01-17 09:17:26.83702+00	17	HwEmy11	1	[{"added": {}}]	4	3
1217	2023-01-17 09:17:51.843633+00	17	HwEmy11	2	[{"changed": {"fields": ["First name", "Email address", "Staff status"]}}]	4	3
1218	2023-01-17 09:18:12.242684+00	18	HwEmy12	1	[{"added": {}}]	4	3
1219	2023-01-17 09:18:46.566828+00	18	HwEmy12	2	[{"changed": {"fields": ["First name", "Email address", "Staff status"]}}]	4	3
1220	2023-01-17 09:19:14.15454+00	19	HwEmy13	1	[{"added": {}}]	4	3
1221	2023-01-17 09:19:48.868394+00	19	HwEmy13	2	[{"changed": {"fields": ["First name", "Email address", "Staff status"]}}]	4	3
1222	2023-01-17 09:20:12.733177+00	20	HwEmy14	1	[{"added": {}}]	4	3
1223	2023-01-17 09:20:51.849262+00	20	HwEmy14	2	[{"changed": {"fields": ["First name", "Email address", "Staff status"]}}]	4	3
1224	2023-01-17 09:21:51.556974+00	21	HwEmy15	1	[{"added": {}}]	4	3
1225	2023-01-17 09:22:15.816715+00	21	HwEmy15	2	[{"changed": {"fields": ["First name", "Email address", "Staff status"]}}]	4	3
1226	2023-01-17 09:22:36.905425+00	22	HwEmy16	1	[{"added": {}}]	4	3
1227	2023-01-17 09:22:58.040112+00	22	HwEmy16	2	[{"changed": {"fields": ["First name", "Email address", "Staff status"]}}]	4	3
1228	2023-01-17 09:23:17.981917+00	23	HwEmy17	1	[{"added": {}}]	4	3
1229	2023-01-17 09:23:41.436177+00	23	HwEmy17	2	[{"changed": {"fields": ["First name", "Email address", "Staff status"]}}]	4	3
1230	2023-01-17 09:24:12.733474+00	24	HwEmy18	1	[{"added": {}}]	4	3
1231	2023-01-17 09:25:07.055013+00	24	HwEmy18	2	[{"changed": {"fields": ["First name", "Email address", "Staff status"]}}]	4	3
1232	2023-01-17 09:25:34.547498+00	25	HwEmy19	1	[{"added": {}}]	4	3
1233	2023-01-17 09:25:52.04339+00	25	HwEmy19	2	[{"changed": {"fields": ["First name", "Email address", "Staff status"]}}]	4	3
1234	2023-01-17 09:26:18.29977+00	26	HwEmy20	1	[{"added": {}}]	4	3
1235	2023-01-17 09:26:37.41631+00	26	HwEmy20	2	[{"changed": {"fields": ["First name", "Email address", "Staff status"]}}]	4	3
1236	2023-01-17 09:29:17.400892+00	8	HwEmy01	1	[{"added": {}}]	21	3
1237	2023-01-17 09:50:25.732362+00	9	HwEmy09	1	[{"added": {}}]	21	3
1238	2023-01-17 09:51:46.264526+00	10	HwEmy10	1	[{"added": {}}]	21	3
1239	2023-01-17 09:52:30.895284+00	11	HwEmy11	1	[{"added": {}}]	21	3
1240	2023-01-17 09:53:10.898055+00	12	HwEmy12	1	[{"added": {}}]	21	3
1241	2023-01-17 09:54:35.557437+00	13	HwEmy14	1	[{"added": {}}]	21	3
1242	2023-01-17 09:55:45.608812+00	14	HwEmy15	1	[{"added": {}}]	21	3
1243	2023-01-17 09:57:02.580518+00	15	HwEmy04	1	[{"added": {}}]	21	3
1244	2023-01-17 09:58:23.517967+00	16	HwEmy03	1	[{"added": {}}]	21	3
1245	2023-01-17 10:02:55.814975+00	17	HwEmy13	1	[{"added": {}}]	21	3
1246	2023-01-17 10:03:47.829852+00	18	HwEmy16	1	[{"added": {}}]	21	3
1247	2023-01-17 10:05:19.492915+00	19	HwEmy02	1	[{"added": {}}]	21	3
1248	2023-01-17 10:06:46.691475+00	20	HwEmy01	1	[{"added": {}}]	21	3
1249	2023-01-17 10:07:18.282645+00	21	HwEmy01	1	[{"added": {}}]	21	3
1250	2023-01-17 10:07:57.494133+00	22	HwEmy02	1	[{"added": {}}]	21	3
1251	2023-01-17 10:08:19.570159+00	23	HwEmy02	1	[{"added": {}}]	21	3
1252	2023-01-17 10:08:32.695005+00	24	HwEmy02	1	[{"added": {}}]	21	3
1253	2023-01-17 10:09:59.327224+00	25	HwEmy05	1	[{"added": {}}]	21	3
1254	2023-01-17 10:10:32.855255+00	26	HwEmy05	1	[{"added": {}}]	21	3
1255	2023-01-17 10:11:49.568227+00	27	HwEmy05	1	[{"added": {}}]	21	3
1256	2023-01-17 10:12:06.580225+00	28	HwEmy05	1	[{"added": {}}]	21	3
1257	2023-01-17 10:13:14.79879+00	29	HwEmy07	1	[{"added": {}}]	21	3
1258	2023-01-17 10:13:31.849322+00	30	HwEmy06	1	[{"added": {}}]	21	3
1259	2023-01-17 10:13:58.575351+00	31	HwEmy08	1	[{"added": {}}]	21	3
1260	2023-01-17 10:14:20.950052+00	32	HwEmy07	1	[{"added": {}}]	21	3
1261	2023-01-17 10:14:46.131887+00	33	HwEmy07	1	[{"added": {}}]	21	3
1262	2023-01-17 10:16:11.913705+00	31	HwEmy08	2	[{"changed": {"fields": ["Village"]}}]	21	3
1263	2023-01-17 10:16:56.309357+00	34	HwEmy08	1	[{"added": {}}]	21	3
1264	2023-01-17 10:17:16.515172+00	31	HwEmy08	2	[{"changed": {"fields": ["Phone no"]}}]	21	3
1265	2023-01-17 10:18:53.446243+00	35	HwEmy13	1	[{"added": {}}]	21	3
1266	2023-01-17 10:20:44.58138+00	36	HwEmy16	1	[{"added": {}}]	21	3
1267	2023-01-17 10:31:19.95282+00	37	HwEmy17	1	[{"added": {}}]	21	3
1268	2023-01-17 10:31:59.255667+00	38	HwEmy18	1	[{"added": {}}]	21	3
1269	2023-01-17 10:32:12.11741+00	39	HwEmy19	1	[{"added": {}}]	21	3
1270	2023-01-17 10:32:25.002768+00	40	HwEmy20	1	[{"added": {}}]	21	3
1271	2023-01-19 05:03:32.381981+00	20	HwEmy14	2	[]	4	3
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	auth	user
5	contenttypes	contenttype
6	sessions	session
7	application_masters	district
8	application_masters	phc
9	application_masters	village
10	application_masters	taluk
11	application_masters	state
12	application_masters	masterlookup
13	application_masters	appcontent
14	health_management	medicines
15	health_management	treatments
16	health_management	scanned_report
17	health_management	prescription
18	health_management	patients
19	health_management	diagnosis
20	health_management	comorbid
21	health_management	userprofile
22	application_masters	comorbid
23	application_masters	medicines
24	application_masters	dosage
25	application_masters	subcenter
26	application_masters	category
27	health_management	homevisit
28	health_management	medicinestock
29	health_management	drugdispensation
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2022-09-26 06:05:08.418088+00
2	auth	0001_initial	2022-09-26 06:05:08.552023+00
3	admin	0001_initial	2022-09-26 06:05:08.587454+00
4	admin	0002_logentry_remove_auto_add	2022-09-26 06:05:08.595161+00
5	admin	0003_logentry_add_action_flag_choices	2022-09-26 06:05:08.603677+00
6	contenttypes	0002_remove_content_type_name	2022-09-26 06:05:08.617413+00
7	auth	0002_alter_permission_name_max_length	2022-09-26 06:05:08.629449+00
8	auth	0003_alter_user_email_max_length	2022-09-26 06:05:08.636912+00
9	auth	0004_alter_user_username_opts	2022-09-26 06:05:08.643879+00
10	auth	0005_alter_user_last_login_null	2022-09-26 06:05:08.651185+00
11	auth	0006_require_contenttypes_0002	2022-09-26 06:05:08.654444+00
12	auth	0007_alter_validators_add_error_messages	2022-09-26 06:05:08.662244+00
13	auth	0008_alter_user_username_max_length	2022-09-26 06:05:08.675413+00
14	auth	0009_alter_user_last_name_max_length	2022-09-26 06:05:08.683314+00
15	auth	0010_alter_group_name_max_length	2022-09-26 06:05:08.69099+00
16	auth	0011_update_proxy_permissions	2022-09-26 06:05:08.698482+00
17	auth	0012_alter_user_first_name_max_length	2022-09-26 06:05:08.707086+00
18	sessions	0001_initial	2022-09-26 06:05:08.726969+00
19	application_masters	0001_initial	2022-12-07 13:12:02.442354+00
20	health_management	0001_initial	2022-12-07 13:12:02.762853+00
21	health_management	0002_auto_20221207_1336	2022-12-07 13:36:58.19379+00
22	application_masters	0002_auto_20221208_0713	2022-12-08 07:14:37.456131+00
23	health_management	0003_auto_20221208_0713	2022-12-08 07:14:37.637552+00
24	health_management	0004_userprofile	2022-12-08 09:04:00.075958+00
25	health_management	0005_rename_full_name_userprofile_name	2022-12-08 09:22:27.492596+00
26	health_management	0006_userprofile_email	2022-12-08 13:39:57.080489+00
27	health_management	0007_rename_patient_uuid_patients_patient_id	2022-12-08 17:16:27.243501+00
28	application_masters	0003_auto_20221208_1845	2022-12-08 18:45:45.405349+00
29	health_management	0008_auto_20221208_1845	2022-12-08 18:45:45.504828+00
30	application_masters	0004_auto_20221209_0729	2022-12-09 07:29:45.989882+00
31	health_management	0009_diagnosis_detected_by	2022-12-09 11:04:34.265663+00
32	application_masters	0005_state_parent_id	2022-12-12 07:53:57.319855+00
33	application_masters	0006_auto_20221212_0724	2022-12-12 07:53:57.509398+00
34	health_management	0010_auto_20221212_0724	2022-12-12 07:53:57.585829+00
35	health_management	0011_auto_20221212_1153	2022-12-12 14:35:01.841945+00
36	application_masters	0007_comorbid	2022-12-12 16:03:47.898018+00
37	health_management	0012_delete_comorbid	2022-12-12 16:03:47.903725+00
38	application_masters	0008_auto_20221212_1805	2022-12-12 18:05:45.934032+00
39	application_masters	0008_medicines	2022-12-13 08:17:11.838037+00
40	health_management	0013_auto_20221213_1439	2022-12-13 09:09:26.060223+00
41	application_masters	0009_rename_types_medicines_type	2022-12-13 09:11:21.124867+00
42	application_masters	0010_dosage	2022-12-15 09:32:03.382599+00
43	health_management	0014_remove_prescription_dosage	2022-12-15 09:32:03.409731+00
44	health_management	0015_prescription_dosage	2022-12-15 09:32:03.484921+00
45	application_masters	0011_auto_20221216_1509	2022-12-16 09:52:30.842935+00
46	health_management	0016_alter_diagnosis_years	2022-12-16 11:39:45.992397+00
47	health_management	0017_patients_seq_no	2022-12-19 07:14:35.130596+00
48	application_masters	0012_subcenter	2022-12-19 07:14:55.980596+00
49	application_masters	0013_rename_phc_code_phc_code	2022-12-19 07:45:41.914539+00
50	application_masters	0014_auto_20221219_1319	2022-12-19 07:49:33.576052+00
51	health_management	0018_alter_patients_phone_number	2022-12-20 13:14:07.788743+00
52	health_management	0019_alter_patients_village	2022-12-22 13:39:42.873297+00
53	health_management	0020_patients_subcenter_id	2022-12-22 13:39:42.905379+00
54	application_masters	0015_category	2022-12-28 05:40:43.90709+00
55	health_management	0021_userprofile_phone_no	2022-12-28 05:40:43.953981+00
56	health_management	0022_homevisit	2022-12-28 10:07:02.823009+00
57	health_management	0023_alter_homevisit_home_vist	2022-12-30 05:47:32.554563+00
58	health_management	0024_drugdispensation_medicinestock	2023-01-06 05:24:34.876917+00
59	health_management	0025_auto_20230106_1623	2023-01-09 09:39:20.059655+00
60	health_management	0026_drugdispensation	2023-01-11 05:49:53.867535+00
61	health_management	0027_alter_drugdispensation_date_of_dispensation	2023-01-12 04:08:17.242826+00
62	health_management	0028_auto_20230117_1236	2023-01-17 07:35:26.289204+00
63	health_management	0029_auto_20230117_1242	2023-01-17 07:35:26.344327+00
64	application_masters	0016_alter_village_options	2023-01-17 10:04:43.616653+00
65	health_management	0030_auto_20230117_1509	2023-01-17 10:04:43.684015+00
66	health_management	0031_alter_userprofile_village	2023-01-17 10:04:43.722326+00
67	health_management	0032_patients_user_uuid	2023-01-18 05:54:09.790983+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
n9jr30ciz5wyfq7px0adbf5dqb8l7159	.eJxVjDsOwjAUBO_iGln4EzumpM8ZrGfvMw6gRIqTCnF3iJQC2p2ZfYlI21rj1niJI8RFKHH63RLlB087wJ2m2yzzPK3LmOSuyIM2Oczg5_Vw_w4qtfqtc4KDDV53xRWgVx7ZqETunJh7YwN3UNpbq5gB5X02GpYMF4NQAon3BwPPOM4:1oci5F:nSPJ-oU6c-hz4PBFq5Z8wgqxltA1NMR7nMd1YHOIUoE	2022-10-10 06:59:17.65744+00
zou4qsah1ibk9w8dcetrh7sasbroywjy	.eJxVjDsOwjAUBO_iGln4EzumpM8ZrGfvMw6gRIqTCnF3iJQC2p2ZfYlI21rj1niJI8RFKHH63RLlB087wJ2m2yzzPK3LmOSuyIM2Oczg5_Vw_w4qtfqtc4KDDV53xRWgVx7ZqETunJh7YwN3UNpbq5gB5X02GpYMF4NQAon3BwPPOM4:1oeAYC:FpdP366XtDDoLe1YdtOtSXuy94IPJUKvpJUOu4FEGd4	2022-10-14 07:35:12.306429+00
99e877p22pxzfb6eto0xereayq7i9cr7	.eJxVjDsOwjAUBO_iGln4EzumpM8ZrGfvMw6gRIqTCnF3iJQC2p2ZfYlI21rj1niJI8RFKHH63RLlB087wJ2m2yzzPK3LmOSuyIM2Oczg5_Vw_w4qtfqtc4KDDV53xRWgVx7ZqETunJh7YwN3UNpbq5gB5X02GpYMF4NQAon3BwPPOM4:1p0jnt:78pXdS8yA_plxMfE-fPOd-D2qpRlBxKYyDGqz29lA18	2022-12-15 13:40:41.072291+00
6uidv3z3xqedjavknhow4d07nnumdlso	.eJxVjMsOwiAQRf-FtSE4DI-6dN9vIAMDUjU0Ke3K-O_apAvd3nPOfYlA21rD1vMSJhYXAeL0u0VKj9x2wHdqt1mmua3LFOWuyIN2Oc6cn9fD_Tuo1Ou3RgUanfJDjGAj6VIYBw98RmeUTSZCYq8BXLGE1qisi4Ok2BRyOqEV7w_C-zc9:1p3I5H:XVriWb8G-9-EMmsHKc51AdMMcAHL_F5EMablBA3JfQ8	2022-12-22 14:41:11.128208+00
ix3z8us20jzv8uu5xmfdl9g7ua8dmq5d	.eJxVjMsOwiAQAP-FsyHQLmzx6L3fQHbLYqsGkj5Oxn83JD3odWYybxXp2Od4bLLGJamr6tXllzFNTylNpAeVe9VTLfu6sG6JPu2mx5rkdTvbv8FM29y2VowFJG9gIO9DQAE3IGcMQ4ZenO24Y5dxIvZGXBZx3GOAYC0AefX5AsDBNyo:1p3fMG:eD-p082hGKlSCcPdGMZh7OWpoBcYWMWNY_oubY--mZ0	2022-12-23 15:32:16.326078+00
gggyhf33giu75q8eatwcu410shvzmfqn	.eJxVjMsOwiAQAP-FsyHQLmzx6L3fQHbLYqsGkj5Oxn83JD3odWYybxXp2Od4bLLGJamr6tXllzFNTylNpAeVe9VTLfu6sG6JPu2mx5rkdTvbv8FM29y2VowFJG9gIO9DQAE3IGcMQ4ZenO24Y5dxIvZGXBZx3GOAYC0AefX5AsDBNyo:1p4aEO:JDcyOoXPUy9ksjXdCghJlMFG0QUx4cfwF42e_R2LLkM	2022-12-26 04:15:56.846443+00
omei4g4ztyyc9eoscabb8vhhq07llnjh	.eJxVjMsOwiAQAP-FsyHQLmzx6L3fQHbLYqsGkj5Oxn83JD3odWYybxXp2Od4bLLGJamr6tXllzFNTylNpAeVe9VTLfu6sG6JPu2mx5rkdTvbv8FM29y2VowFJG9gIO9DQAE3IGcMQ4ZenO24Y5dxIvZGXBZx3GOAYC0AefX5AsDBNyo:1p4gjH:kaqj8d4MXonsv6G0W1Nx0gDIYpUcDeUOnMREjsGEhWk	2022-12-26 11:12:15.646129+00
y4ablk4lwj6cayoqs0irvm513dm6j767	.eJxVjMsOwiAQRf-FtSE4DI-6dN9vIAMDUjU0Ke3K-O_apAvd3nPOfYlA21rD1vMSJhYXAeL0u0VKj9x2wHdqt1mmua3LFOWuyIN2Oc6cn9fD_Tuo1Ou3RgUanfJDjGAj6VIYBw98RmeUTSZCYq8BXLGE1qisi4Ok2BRyOqEV7w_C-zc9:1p4lEp:ajrU0svMz518lZRD_GLQTBKrqZvkHgdw1Oe6qqlCAF0	2022-12-26 16:01:07.813184+00
0yu2sb2smuplzt38jn0uiljsvuvqpvlm	.eJxVjMsOwiAQAP-FsyHQLmzx6L3fQHbLYqsGkj5Oxn83JD3odWYybxXp2Od4bLLGJamr6tXllzFNTylNpAeVe9VTLfu6sG6JPu2mx5rkdTvbv8FM29y2VowFJG9gIO9DQAE3IGcMQ4ZenO24Y5dxIvZGXBZx3GOAYC0AefX5AsDBNyo:1p5OHq:r-ENan0z8B9J4cWSEwhjWLeSgjk12Qd6NOV_1oGJY2I	2022-12-28 09:42:51.000031+00
bbrz45q39ab076686d11oj6dna3iaj6k	.eJxVjMsOwiAQAP-FsyHQLmzx6L3fQHbLYqsGkj5Oxn83JD3odWYybxXp2Od4bLLGJamr6tXllzFNTylNpAeVe9VTLfu6sG6JPu2mx5rkdTvbv8FM29y2VowFJG9gIO9DQAE3IGcMQ4ZenO24Y5dxIvZGXBZx3GOAYC0AefX5AsDBNyo:1p5OK0:3iBoQ5DhS14ygnjNg1Ub3KKUsHUikQ-yg-1Vfu3jJxI	2022-12-28 09:45:04.993752+00
c3env1eyktlmta7j7ikf544iw218mspx	.eJxVjMsOwiAQAP-FsyHQLmzx6L3fQHbLYqsGkj5Oxn83JD3odWYybxXp2Od4bLLGJamr6tXllzFNTylNpAeVe9VTLfu6sG6JPu2mx5rkdTvbv8FM29y2VowFJG9gIO9DQAE3IGcMQ4ZenO24Y5dxIvZGXBZx3GOAYC0AefX5AsDBNyo:1p5P0m:mB5Vha0nak1xo0Y4zOqY7v8v6V2oy3BDqe2EYz1qeV4	2022-12-28 10:29:16.159759+00
3nnoxe9fuzwalktb2iv044obvlgu9r93	.eJxVjMsOwiAQAP-FsyHQLmzx6L3fQHbLYqsGkj5Oxn83JD3odWYybxXp2Od4bLLGJamr6tXllzFNTylNpAeVe9VTLfu6sG6JPu2mx5rkdTvbv8FM29y2VowFJG9gIO9DQAE3IGcMQ4ZenO24Y5dxIvZGXBZx3GOAYC0AefX5AsDBNyo:1p7AQy:xUgxcQ4POHY_x_sJ9shTmPGXwbTOClkcRADQ0oyzWv0	2023-01-02 07:19:36.378728+00
sp35aj42azvwvefedi0ev8pgj2pqf74z	.eJxVjMsOwiAQAP-FsyHQLmzx6L3fQHbLYqsGkj5Oxn83JD3odWYybxXp2Od4bLLGJamr6tXllzFNTylNpAeVe9VTLfu6sG6JPu2mx5rkdTvbv8FM29y2VowFJG9gIO9DQAE3IGcMQ4ZenO24Y5dxIvZGXBZx3GOAYC0AefX5AsDBNyo:1p7V8S:AXGmae5PgzlI3m7Q6iKi2PIJhmIUbTFnqSgIuFkjViI	2023-01-03 05:25:52.199048+00
1b3veoepqpudcayebe058akukpmjc78s	.eJxVjEEOwiAQRe_C2hAZoKUu3fcMZGYAqRpISrsy3l1JutDte-__l_C4b9nvLa5-CeIitDj9MkJ-xNJFuGO5Vcm1bOtCsifysE3ONcTn9Wj_DjK23NcmEHFCUmjOaLWFyIMFx9OXAlKaDEUAF4Ecw5C0GRWNBsEqHViheH8AGrA40w:1pCbSr:zmTK7y8cALdSET6QyOjtCNHxQ68cYjesk2GuTVUW4aE	2023-01-17 07:12:01.76243+00
sfx4cr3c7pckaf8eq8e1i4g15oe82bqq	.eJxVjEEOwiAQRe_C2hAZoKUu3fcMZGYAqRpISrsy3l1JutDte-__l_C4b9nvLa5-CeIitDj9MkJ-xNJFuGO5Vcm1bOtCsifysE3ONcTn9Wj_DjK23NcmEHFCUmjOaLWFyIMFx9OXAlKaDEUAF4Ecw5C0GRWNBsEqHViheH8AGrA40w:1pDJ0H:PAcELF4ZRtYop9GEUi48d84Kl9hgkiLG8BIlVHtT4MU	2023-01-19 05:41:25.07497+00
4t3ejkuttl92y3o6rjdzwi5y82mrakce	.eJxVjEEOwiAQRe_C2hAZoKUu3fcMZGYAqRpISrsy3l1JutDte-__l_C4b9nvLa5-CeIitDj9MkJ-xNJFuGO5Vcm1bOtCsifysE3ONcTn9Wj_DjK23NcmEHFCUmjOaLWFyIMFx9OXAlKaDEUAF4Ecw5C0GRWNBsEqHViheH8AGrA40w:1pGC6u:SVle2o1sO9kGLAj5zWwGOItcBJE8YOX_z4k4-BEGA0E	2023-01-27 04:56:12.094985+00
nhw7r8myl8t5il3v6071fkbow0cnr1kv	.eJxVjEEOwiAQRe_C2hAZoKUu3fcMZGYAqRpISrsy3l1JutDte-__l_C4b9nvLa5-CeIitDj9MkJ-xNJFuGO5Vcm1bOtCsifysE3ONcTn9Wj_DjK23NcmEHFCUmjOaLWFyIMFx9OXAlKaDEUAF4Ecw5C0GRWNBsEqHViheH8AGrA40w:1pHfe2:Z83s6ECGcZ8zoI_JGcwRcUA1GVBDU4jLiD_H2li8W5A	2023-01-31 06:40:30.125519+00
bvc55mxy3lknjuod777ahrv1jh313csk	.eJxVjEEOwiAQRe_C2hAZoKUu3fcMZGYAqRpISrsy3l1JutDte-__l_C4b9nvLa5-CeIitDj9MkJ-xNJFuGO5Vcm1bOtCsifysE3ONcTn9Wj_DjK23NcmEHFCUmjOaLWFyIMFx9OXAlKaDEUAF4Ecw5C0GRWNBsEqHViheH8AGrA40w:1pHi0T:Cv7DP0WnDeq9tPQLf4-v2te9-KQwO6IvrtA1ltiwkeU	2023-01-31 09:11:49.212156+00
k3crlghqikh2fz4ghcltntyj5kyq2cf4	.eJxVjEEOwiAQRe_C2hAZoKUu3fcMZGYAqRpISrsy3l1JutDte-__l_C4b9nvLa5-CeIitDj9MkJ-xNJFuGO5Vcm1bOtCsifysE3ONcTn9Wj_DjK23NcmEHFCUmjOaLWFyIMFx9OXAlKaDEUAF4Ecw5C0GRWNBsEqHViheH8AGrA40w:1pIOGg:rowPb-EQdfforiJwFQoePRiU6W1WSNZFcr0ARnPAPJ4	2023-02-02 06:19:22.722709+00
\.


--
-- Data for Name: health_management_diagnosis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.health_management_diagnosis (id, status, server_created_on, server_modified_on, uuid, treatment_uuid, source_treatment, years, sync_status, created_by_id, modified_by_id, ndc_id, detected_by, user_uuid) FROM stdin;
26	2	2022-12-19 09:14:54.691873+00	2022-12-19 09:15:37.185491+00	20221208105053781507b7b9-f921-44d1-8c7e-0918af6cccbc	2022120811044169d51869ae-0edc-425b-be6c-d20c35420e89	120	2	2	\N	\N	5	\N	\N
27	2	2022-12-19 10:09:15.498948+00	2022-12-19 10:09:15.498973+00	20221219153823238cd9b58e-684c-4ddc-98ab-746e45005efd	202212191538325614e1e357-e770-42ca-995e-cd5e784586f3	2	12-22	2	\N	\N	10	2	\N
28	2	2022-12-20 09:25:10.356145+00	2022-12-20 09:25:10.356176+00	20221220145441856d132a86-aa8f-4eed-9646-baca4a217060	202212201454541589b65348-996e-49c2-babb-597d96d51064	1	12-22	2	\N	\N	11	1	\N
\.


--
-- Data for Name: health_management_drugdispensation; Type: TABLE DATA; Schema: public; Owner: oblf_user
--

COPY public.health_management_drugdispensation (id, uuid, status, server_created_on, server_modified_on, sync_status, units_dispensed, date_of_dispensation, created_by_id, medicine_id, modified_by_id, village_id) FROM stdin;
1	\N	2	2023-01-13 05:40:40.198939+00	2023-01-13 05:40:40.202212+00	2	2	2023-01-13	\N	1	\N	1
2	\N	2	2023-01-13 05:53:19.908664+00	2023-01-13 05:53:19.911213+00	2	2	2023-01-13	\N	1	\N	2
3	\N	2	2023-01-13 06:37:02.529577+00	2023-01-13 06:37:02.532021+00	2	2	2023-01-13	\N	2	\N	1
4	\N	2	2023-01-13 06:40:10.589727+00	2023-01-13 06:40:10.597609+00	2	2	2023-01-13	\N	1	\N	2
\.


--
-- Data for Name: health_management_homevisit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.health_management_homevisit (id, status, server_created_on, server_modified_on, sync_status, uuid, patient_uuid, home_vist, response_location, response_datetime, image, created_by_id, modified_by_id, user_uuid) FROM stdin;
1	2	2022-12-29 19:55:56.230146+00	2022-12-29 20:19:33.26178+00	2		\N	2	20.5813321,81.0790073	2022-12-29 20:18:22+00		\N	\N	\N
2	2	2022-12-29 20:23:54.470555+00	2022-12-29 20:23:54.470581+00	2	202212300148220764158511-317f-4c79-a0b6-d4c703416844		2	20.5813321,81.0790073	2022-12-29 20:18:22+00		\N	\N	\N
3	2	2022-12-29 20:28:47.948543+00	2022-12-29 20:28:47.948569+00	2	2022123001590106637f1e89-33d7-4dff-9a60-56c3bbd080aa	202212201042384202de6573-e053-4756-8b16-554b90eb262e	2	20.581332,81.0790074	2022-12-29 20:29:01+00		\N	\N	\N
\.


--
-- Data for Name: health_management_medicinestock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.health_management_medicinestock (id, uuid, status, server_created_on, server_modified_on, sync_status, date_of_creation, unit_price, no_of_units, opening_stock, closing_stock, created_by_id, medicine_id, modified_by_id) FROM stdin;
3	\N	2	2023-01-13 05:39:57.141949+00	2023-01-13 05:39:57.146769+00	2	2023-01-13	12	12	0	12	\N	1	\N
4	\N	2	2023-01-13 06:36:07.174093+00	2023-01-13 06:36:07.177797+00	2	2023-01-13	78	10	0	10	\N	2	\N
5	\N	2	2023-01-13 06:36:27.1579+00	2023-01-13 06:36:27.160649+00	2	2023-01-13	3	2	10	12	\N	2	\N
6	\N	2	2023-01-17 10:21:21.350179+00	2023-01-17 10:21:21.353402+00	2	\N	\N	1	6	7	\N	1	\N
\.


--
-- Data for Name: health_management_patients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.health_management_patients (id, status, server_created_on, server_modified_on, uuid, patient_id, name, dob, age, gender, phone_number, image, height, weight, door_no, fee_status, fee_paid, fee_date, registered_date, last_visit_date, created_by_id, modified_by_id, patient_visit_type_id, village_id, sync_status, seq_no, subcenter_id, user_uuid) FROM stdin;
120	2	2022-12-19 10:28:36.807774+00	2022-12-19 10:28:36.810563+00	2022121915564038414f0090-82c4-484b-a217-4d3dd3f410d6	BUATINDCLP25812-00120	ffhhffh	1942-06-07	80	1	9595898989		128	40	258	1	0	2022-12-18 18:30:00+00	2022-12-18 18:30:00+00	2022-12-18 18:30:00+00	\N	\N	12	28	2	258	\N	\N
131	2	2022-12-22 13:47:31.259038+00	2022-12-22 13:48:45.960015+00	2022122219174071368a6e80-0c50-4cc9-be25-35ec22e888b4	BUATINDVSO12512	numish	1968-03-03	54	1	4598555555		125	0	125	1	0	2022-12-21 18:30:00+00	2022-12-21 18:30:00+00	2022-12-21 18:30:00+00	\N	\N	12	12	2	12	2	\N
122	2	2022-12-19 12:13:28.415561+00	2022-12-19 12:13:28.479868+00	20221219173436744fe38854-2143-4981-939e-d0d7eae9135a	BUATINDVSG00409-00122	Sunil	1980-06-06	42	1	8698586886	patients_image/22/12/19/temp0.99723605025455031671451385463_RuupAYc.jpg	135	50	004	2	50	2022-12-18 18:30:00+00	2022-12-18 18:30:00+00	2022-12-18 18:30:00+00	\N	\N	12	18	2	004	\N	\N
124	2	2022-12-19 12:41:51.825364+00	2022-12-19 12:41:51.828017+00	2022121918115834beb08e89-8822-4d82-a53b-c77d8a66b539	BUATINDVPG50656-00124	Saini	1966-05-07	56	2	8861579741	patients_image/22/12/19/temp0.0137734269972342731671453717121.jpg	156	56	506	2	500	2022-12-18 18:30:00+00	2022-12-18 18:30:00+00	2022-12-18 18:30:00+00	\N	\N	12	16	2	506	\N	\N
125	2	2022-12-19 12:48:10.355887+00	2022-12-19 12:48:10.359641+00	202212191818169463320078-bb2b-4bd5-924b-7a4e8554328e	BUATINDVSU56464-00125	Shaid	1956-05-07	66	1	0838325630	patients_image/22/12/19/temp0.099611613531817361671454083809.jpg	145	56	564	2	500	2022-12-18 18:30:00+00	2022-12-18 18:30:00+00	2022-12-18 18:30:00+00	\N	\N	12	14	2	\N	\N	\N
126	2	2022-12-19 12:48:32.498635+00	2022-12-19 12:48:32.500672+00	2022121918183750434eda1a-4760-47f1-b520-fdf0a4f1477b	BUATINDVKL12596-00126	gopal	1995-05-06	27	1	9449949494	patients_image/22/12/19/temp0.161900951575463141671454096703.jpg	158	68	125	1	0	2022-12-18 18:30:00+00	2022-12-18 18:30:00+00	2022-12-18 18:30:00+00	\N	\N	12	13	2	\N	\N	\N
128	2	2022-12-19 14:03:12.691921+00	2022-12-19 14:03:12.693832+00	2022121919331927f9ef9348-8272-4beb-942f-53f80c21ff14	BUATINDIKJ15888	kamal	1960-04-07	62	2	9665655555		99	58	158	1	0	2022-12-18 18:30:00+00	2022-12-18 18:30:00+00	2022-12-18 18:30:00+00	\N	\N	12	2	2	88	\N	\N
130	2	2022-12-20 09:29:15.190244+00	2022-12-27 13:08:30.006243+00	2022122014592184acb3ff41-e6a6-4fbe-be24-2a7145b5c1fe	BUATINDVSG00101	anishaya	\N	50	2	9937803231		150	90	001	2	30	2022-12-19 18:30:00+00	2022-12-19 18:30:00+00	2022-12-26 18:30:00+00	\N	\N	12	18	2	\N	0	\N
121	2	2022-12-19 10:29:54.260213+00	2022-12-22 15:58:07.836172+00	20221219155909645584ac95-9b64-47c3-a775-4b264efdf4ba	BUATINDVSU15880-00121	fhjjv	1985-06-07	37	2	8988989787		150	40	158	1	0	2022-12-18 18:30:00+00	2022-12-18 18:30:00+00	2022-12-21 18:30:00+00	\N	\N	12	14	2	\N	0	\N
127	2	2022-12-19 12:57:50.339603+00	2022-12-22 12:07:57.864628+00	2022121918275697c42224ab-11f2-4549-841a-430b4dba3354	BUATINDVSU34555	Rohini	1956-03-06	66	2	9961579741		66	36	345	2	45	2022-12-18 18:30:00+00	2022-12-18 18:30:00+00	2022-12-21 18:30:00+00	\N	\N	12	14	2	\N	\N	\N
132	2	2022-12-22 13:48:45.966011+00	2022-12-22 19:29:21.585686+00	2022122219185501a1d1487a-cb9f-4558-a382-3de4a2034397		polin	\N	80	1			0	0		0	0	2022-12-21 18:30:00+00	2022-12-21 18:30:00+00	2022-12-22 18:30:00+00	\N	\N	13	\N	2	\N	0	\N
134	2	2022-12-23 04:07:41.501128+00	2022-12-23 04:07:41.524168+00	20221222175916044cfd8a14-05cf-48d8-bcd7-6df619cee4c4		temp	\N	29	2			0	\N	\N	0	0	2022-12-21 18:30:00+00	2022-12-21 18:30:00+00	2022-12-21 18:30:00+00	\N	\N	13	\N	2	\N	0	\N
119	2	2022-12-19 10:09:15.478757+00	2022-12-29 20:15:29.618523+00	2022121915371898e584e153-7b1c-4805-8e62-48613b36f47b	BUATINDIKJ-00119	mira	1980-05-07	42	2	9865623225		158	50		1	0	2022-12-18 18:30:00+00	2022-12-18 18:30:00+00	2022-12-29 18:30:00+00	\N	\N	12	2	2	\N	0	\N
167	2	2023-01-05 05:45:21.633698+00	2023-01-05 05:45:21.636399+00	202301051115461675390204-949c-459f-8bda-10fa924cd2bd	BUATINDVSO47774	Ehehh	1975-04-05	48	2	8861579741	patients_image/23/01/05/temp0.287988508645713241672897544924.jpg	156	67	477	2	500	2023-01-04 18:30:00+00	2023-01-04 18:30:00+00	2023-01-04 18:30:00+00	\N	\N	12	12	2	74	2	\N
198	2	2023-01-10 11:18:32.603629+00	2023-01-10 11:18:52.952657+00	2023011016483143af2dbfd2-0d9a-4f53-b89f-69066f1445c8	BUATINDIID15080	xvfb	1973-01-01	50	2	9898898989		155	58	150	1	0	2023-01-09 18:30:00+00	2023-01-09 18:30:00+00	2023-01-09 18:30:00+00	\N	\N	12	8	2	80	1	\N
199	2	2023-01-10 13:20:35.092358+00	2023-01-10 13:20:35.096333+00	2023011018503392ef9a675b-fee4-49ca-ae86-103336b66359	BUATINDINY12512	hshs	2007-01-01	16	2			128	0	125	0	0	2023-01-09 18:30:00+00	2023-01-09 18:30:00+00	2023-01-09 18:30:00+00	\N	\N	12	6	2	12	1	\N
129	2	2022-12-20 05:12:30.960669+00	2023-01-16 09:10:54.980328+00	202212201042384202de6573-e053-4756-8b16-554b90eb262e	BUATINDCNA25612	Anna	1992-02-02	30	2	9949949940		152	60	256	2	30	2022-12-19 18:30:00+00	2022-12-19 18:30:00+00	2023-01-15 18:30:00+00	\N	\N	12	22	2	\N	0	\N
123	2	2022-12-19 12:16:21.363856+00	2023-01-16 09:12:47.382781+00	20221219174626589cf5eb64-21d4-407d-a54a-0056b8b2f014	BUATINDVSO20102-00123	Manoj	2000-07-07	22	1	9865555556		150	50	201	2	50	2022-12-18 18:30:00+00	2022-12-18 18:30:00+00	2023-01-15 18:30:00+00	\N	\N	12	12	2	\N	0	\N
133	2	2022-12-22 15:56:40.965076+00	2023-01-16 09:12:47.386172+00	2022122221265165c73020bc-f68a-4836-be79-b9f4c02b0b15	BUATINDVPG46357	Divya	1966-05-06	56	2	8861579741		146	56	463	2	500	2022-12-21 18:30:00+00	2022-12-21 18:30:00+00	2023-01-15 18:30:00+00	\N	\N	12	16	2	\N	0	\N
\.


--
-- Data for Name: health_management_prescription; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.health_management_prescription (id, status, server_created_on, server_modified_on, uuid, patient_uuid, treatment_uuid, no_of_days, medicine_type, qty, sync_status, created_by_id, medicines_id, modified_by_id, dosage_id, user_uuid) FROM stdin;
14	2	2022-12-19 09:14:54.699306+00	2022-12-19 09:15:37.187592+00	20221208111259876dfa8cb4-975a-4071-b2b3-b2adb802ff0d	2022120810504710e11a532f-082d-4bfe-9d90-06e2f6b7efd0	2022120810524605577d6715-c6c9-486e-a159-7be06bb339ba	6	Tab	6	2	\N	2	\N	3	\N
13	2	2022-12-19 09:14:54.69406+00	2022-12-19 09:18:24.080228+00	2022120811125972b7115fbd-7046-4450-a46d-72d738cd119d	2022120810504710e11a532f-082d-4bfe-9d90-06e2f6b7efd0	2022120810524605577d6715-c6c9-486e-a159-7be06bb339ba	5	Tab	5	2	\N	3	\N	3	\N
15	2	2022-12-19 10:09:15.506252+00	2022-12-19 10:09:15.506278+00	20221219153845584d94a751-89e9-43e8-ab98-bd83d8edb969	2022121915371898e584e153-7b1c-4805-8e62-48613b36f47b	202212191538325614e1e357-e770-42ca-995e-cd5e784586f3	0	Tab	9	2	\N	18	\N	4	\N
16	2	2022-12-20 05:16:41.706831+00	2022-12-20 05:16:41.706853+00	20221220104649123c1985ec-d263-4f5f-880a-b6626a160536	202212201042384202de6573-e053-4756-8b16-554b90eb262e	2022122010455169af333d73-8c0f-4f1f-973f-08a1560b7160	0	Syrup	1	2	\N	55	\N	3	\N
17	2	2022-12-20 09:23:21.741598+00	2022-12-20 09:23:21.741622+00	20221220145328374f7cf4d6-22e8-4849-9436-4659ae974a26	2022121919331927f9ef9348-8272-4beb-942f-53f80c21ff14	\N	0	Tab	30	2	\N	15	\N	1	\N
18	2	2022-12-20 09:25:10.359302+00	2022-12-20 09:25:10.359325+00	2022122014551703aad79a33-20cc-454e-bdcc-b1f703484a7e	2022121919331927f9ef9348-8272-4beb-942f-53f80c21ff14	202212201454541589b65348-996e-49c2-babb-597d96d51064	0	Tab	60	2	\N	15	\N	5	\N
19	2	2022-12-20 10:26:17.501024+00	2022-12-20 10:26:17.501049+00	2022122015562419a1ef05e7-ac6a-464b-be80-8ca826445172	202212201042384202de6573-e053-4756-8b16-554b90eb262e	2022122010455169af333d73-8c0f-4f1f-973f-08a1560b7160	0	Tab	60	2	\N	16	\N	3	\N
47	2	2023-01-11 07:36:49.442289+00	2023-01-11 07:36:49.442322+00	202301111306475044829767-39ed-4696-bc85-225d2abbfba4	2022121915564038414f0090-82c4-484b-a217-4d3dd3f410d6	2023011113063314cbc44ec4-9cc5-4231-a9fa-0c68e5bb5319	0	Tab	5	2	\N	29	\N	4	\N
\.


--
-- Data for Name: health_management_scanned_report; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.health_management_scanned_report (id, status, server_created_on, server_modified_on, uuid, patient_uuid, title, image_path, captured_date, sync_status, created_by_id, modified_by_id, user_uuid) FROM stdin;
5	2	2022-12-19 09:14:54.705157+00	2022-12-19 09:15:37.189957+00	2022120811044169d51869ae-0edc-425b-be6c-d20c35420e89	20221208105053781507b7b9-f921-44d1-8c7e-0918af6cccbc	Report1	39985111345010351670476839804.jpg	2022-12-07 18:30:00+00	2	\N	\N	\N
6	2	2022-12-20 10:26:17.505757+00	2022-12-20 10:28:20.116299+00	202212201042384202de6573-e053-4756-8b16-554b90eb262e	\N	\N	/storage/emulated/0/Android/data/org.mahiti.oblfhm/files/HelpAge/ScannedReport/ScannedReportBUATINDCNA256121671531645680.jpg	2022-12-19 18:30:00+00	2	\N	\N	\N
7	2	2022-12-22 11:39:18.970296+00	2022-12-22 11:40:37.871674+00	2022122014592184acb3ff41-e6a6-4fbe-be24-2a7145b5c1fe	\N	\N	/storage/emulated/0/Android/data/org.mahiti.oblfhm/files/HelpAge/ScannedReport/ScannedReportBUATINDVSG001011671709124552.jpg	2022-12-21 18:30:00+00	2	\N	\N	\N
\.


--
-- Data for Name: health_management_treatments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.health_management_treatments (id, status, server_created_on, server_modified_on, uuid, patient_uuid, visit_date, bp_sys1, bp_non_sys1, bp_sys2, bp_non_sys2, bp_sys3, bp_non_sys3, fbs, pp, random, weight, bmi, symptoms, remarks, hyper_diabetic, co_morbid_ids, co_morbid_names, is_alcoholic, is_tobacco, is_smoker, created_by_id, modified_by_id, sync_status, user_uuid) FROM stdin;
12	2	2022-12-19 09:14:54.701709+00	2022-12-19 09:15:37.188819+00	2022120811044169d51869ae-0edc-425b-be6c-d20c35420e89	20221208105053781507b7b9-f921-44d1-8c7e-0918af6cccbc	2022-12-06 18:30:00+00	120	80	120	80	120	80	120	120	120	31	31	31	dghdfj	0	20,35	Anaemia,fever	1	0	0	\N	\N	2	\N
13	2	2022-12-19 10:09:15.512804+00	2022-12-19 10:09:15.512828+00	202212191538325614e1e357-e770-42ca-995e-cd5e784586f3	2022121915371898e584e153-7b1c-4805-8e62-48613b36f47b	2022-12-17 18:30:00+00	100	110	120	130	140	150	90	80	70	\N	20.	dvvdbdg	fbfvfvhffh	0	4,6	CORONARY ARTERY DISEASE,ARTHRITIS	1	0	0	\N	\N	2	\N
14	2	2022-12-20 05:16:41.711267+00	2022-12-20 05:16:41.71131+00	2022122010455169af333d73-8c0f-4f1f-973f-08a1560b7160	202212201042384202de6573-e053-4756-8b16-554b90eb262e	2022-12-19 18:30:00+00	160	110	140	100			150			\N	26.	Cough	viral infection	0	1,5	ASTHMA,COPD	0	0	0	\N	\N	2	\N
15	2	2022-12-20 09:25:10.363325+00	2022-12-20 09:25:10.363353+00	202212201454541589b65348-996e-49c2-babb-597d96d51064	2022121919331927f9ef9348-8272-4beb-942f-53f80c21ff14	2022-12-19 18:30:00+00	150	60	145	905				150		\N	59.			1	2,7	CHRONIC KIDNEY DISEASE,RHEUMATOID ARTHRITIS	1	0	0	\N	\N	2	\N
16	2	2022-12-22 07:58:35.196013+00	2023-01-11 07:36:49.449468+00	20221222132626423eacfb04-cf94-485b-8548-d97031183b0a	2022122014592184acb3ff41-e6a6-4fbe-be24-2a7145b5c1fe	2022-12-20 18:30:00+00	128	228								\N	27.			0	5	COPD	0	0	1	\N	\N	2	\N
21	2	2023-01-11 07:36:49.460691+00	2023-01-11 07:36:49.460719+00	2023011113063314cbc44ec4-9cc5-4231-a9fa-0c68e5bb5319	2022121915564038414f0090-82c4-484b-a217-4d3dd3f410d6	2023-01-10 18:30:00+00	80	90								\N	24.			1			1	1	0	\N	\N	2	\N
\.


--
-- Data for Name: health_management_userprofile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.health_management_userprofile (id, status, server_created_on, server_modified_on, uuid, user_type, created_by_id, modified_by_id, user_id, village_id, sync_status, phone_no) FROM stdin;
4	2	2022-12-19 08:57:51.339672+00	2022-12-19 08:57:51.339684+00	cd014c0c-5798-4952-a3a9-07ba31e325a4	1	\N	\N	3	1	2	\N
6	2	2022-12-19 10:02:47.552752+00	2022-12-19 10:02:47.552807+00	7390ace5-42b9-4afe-b17a-58ca34190614	2	\N	\N	4	1	2	\N
5	2	2022-12-19 10:02:28.483743+00	2022-12-19 11:33:28.9019+00	49d65c3a-0833-4808-9a28-2762460c9db3	1	\N	\N	5	1	2	\N
7	2	2022-12-29 05:46:42.485068+00	2023-01-03 05:52:54.363699+00	0419816a-a36c-404f-8295-76e9c8d5bf41	1	\N	\N	6	15	2	99999888888888888
8	2	2023-01-17 09:29:17.396041+00	2023-01-17 09:29:17.396076+00	e6a74c25-9ece-4196-b6a5-ee6bd4eacb72	1	\N	\N	7	3	2	9606144981
9	2	2023-01-17 09:50:25.730919+00	2023-01-17 09:50:25.730942+00	ad88663c-bfee-4bcc-bdcc-560950790303	1	\N	\N	15	14	2	9066558421
10	2	2023-01-17 09:51:46.263437+00	2023-01-17 09:51:46.263461+00	b65c43d4-4ede-4632-960b-97be12c9ad7d	1	\N	\N	16	11	2	9844199239
11	2	2023-01-17 09:52:30.894246+00	2023-01-17 09:52:30.894287+00	d1749bc5-9579-4d40-9512-f4d19b8324d5	1	\N	\N	17	15	2	8495910072
12	2	2023-01-17 09:53:10.896627+00	2023-01-17 09:53:10.896659+00	d0275fee-b3d8-49c5-99f6-5ee0e7198a7e	1	\N	\N	18	17	2	7603890585
13	2	2023-01-17 09:54:35.556121+00	2023-01-17 09:54:35.556148+00	e620362b-0722-4fa0-8cd0-23bd2cb9f2b7	1	\N	\N	20	18	2	8217497371
14	2	2023-01-17 09:55:45.607758+00	2023-01-17 09:55:45.607781+00	02d4e7c1-dea9-4f76-81b7-6dd5cd6d1328	1	\N	\N	21	20	2	8123518146
15	2	2023-01-17 09:57:02.579493+00	2023-01-17 09:57:02.579515+00	4703083b-093a-469b-a982-25bf4ee951cc	1	\N	\N	10	1	2	9972359897
16	2	2023-01-17 09:58:23.516966+00	2023-01-17 09:58:23.516986+00	899f81f6-4fa3-4099-9b6e-044f9ec1da77	1	\N	\N	9	23	2	9980637791
17	2	2023-01-17 10:02:55.813339+00	2023-01-17 10:02:55.813373+00	85700904-7f70-4c99-94d0-e2678b48cf07	1	\N	\N	19	16	2	7019909787
18	2	2023-01-17 10:03:47.828654+00	2023-01-17 10:03:47.828678+00	13db65d6-11b3-48f2-aca5-a322c983c4bf	1	\N	\N	22	2	2	8123679506
19	2	2023-01-17 10:05:19.491641+00	2023-01-17 10:05:19.491669+00	1c9b7a21-910a-4f06-810a-c928e80b84cc	1	\N	\N	8	27	2	7349075105
20	2	2023-01-17 10:06:46.690448+00	2023-01-17 10:06:46.690468+00	657a7c71-45be-46d4-b9d0-5d15c145b6e6	1	\N	\N	7	5	2	9606144981
21	2	2023-01-17 10:07:18.281483+00	2023-01-17 10:07:18.281504+00	86458ff0-94ef-419b-ae36-cce168d7afdb	1	\N	\N	7	10	2	9606144981
22	2	2023-01-17 10:07:57.492799+00	2023-01-17 10:07:57.492828+00	ee81537d-a874-4991-8a5c-a52528ff5750	1	\N	\N	8	28	2	7349075105
23	2	2023-01-17 10:08:19.568267+00	2023-01-17 10:08:19.568295+00	74cdf55d-9d6e-4721-84c0-a4928baef17f	1	\N	\N	8	30	2	7349075105
24	2	2023-01-17 10:08:32.693666+00	2023-01-17 10:08:32.693695+00	848a36c8-c22a-4259-856e-084d14beec17	1	\N	\N	8	29	2	7349075105
25	2	2023-01-17 10:09:59.326044+00	2023-01-17 10:09:59.326072+00	eb767a65-7d60-4729-b273-17ac852bc75e	1	\N	\N	11	7	2	7259363365
26	2	2023-01-17 10:10:32.853819+00	2023-01-17 10:10:32.853849+00	5320d172-ba59-4139-9013-e3242dbf6d79	1	\N	\N	11	9	2	7259363365
27	2	2023-01-17 10:11:49.566854+00	2023-01-17 10:11:49.566883+00	1e8c07bf-fa9c-47b5-b55d-a4d92b53434e	1	\N	\N	11	10	2	7259363365
28	2	2023-01-17 10:12:06.578953+00	2023-01-17 10:12:06.578995+00	f2a123f1-9e6e-4f41-a496-3e79f04d60ad	1	\N	\N	11	8	2	7259363365
29	2	2023-01-17 10:13:14.79769+00	2023-01-17 10:13:14.797718+00	ec557315-fd26-40bb-a05b-15ae80cc5eed	1	\N	\N	13	21	2	7353812495
30	2	2023-01-17 10:13:31.848196+00	2023-01-17 10:13:31.84822+00	d289cc22-6159-4b89-8f83-85897e17bc0d	1	\N	\N	12	22	2	7353812495
32	2	2023-01-17 10:14:20.948402+00	2023-01-17 10:14:20.948425+00	dc495d3c-7311-445f-a9e3-4b6096924acf	1	\N	\N	13	25	2	8310937830
33	2	2023-01-17 10:14:46.13074+00	2023-01-17 10:14:46.130762+00	b3fd18ec-9c2b-4a61-8a7c-67a03b7770af	1	\N	\N	13	26	2	8310937830
34	2	2023-01-17 10:16:56.307729+00	2023-01-17 10:16:56.307789+00	26a99d9b-5cd3-40a9-b96c-240d0220c4c2	1	\N	\N	14	12	2	9844287274
31	2	2023-01-17 10:13:58.574065+00	2023-01-17 10:17:16.513617+00	c89fd286-e412-48ef-995e-d7959e5f8ca5	1	\N	\N	14	13	2	9844287274
35	2	2023-01-17 10:18:53.444902+00	2023-01-17 10:18:53.44493+00	3722ff26-6773-4d2c-9e52-295e56cc6204	1	\N	\N	19	19	2	7019909787
36	2	2023-01-17 10:20:44.58013+00	2023-01-17 10:20:44.58016+00	01e84691-5d8f-41c1-90fd-bb54804d52b7	1	\N	\N	22	6	2	8123679506
37	2	2023-01-17 10:31:19.951666+00	2023-01-17 10:31:19.951687+00	fc338479-b395-4c2e-99cf-2d1afb2944e6	1	\N	\N	23	\N	2	8073327440
38	2	2023-01-17 10:31:59.254467+00	2023-01-17 10:31:59.254502+00	30b437c4-d4c8-473e-ad41-0864e3df7490	1	\N	\N	24	\N	2	7978785137
39	2	2023-01-17 10:32:12.116412+00	2023-01-17 10:32:12.116435+00	8f2911de-3f28-4353-aeeb-38ce0f2e8be8	1	\N	\N	25	\N	2	9740870011
40	2	2023-01-17 10:32:25.001477+00	2023-01-17 10:32:25.001502+00	99e2dce8-b937-4e9c-9c2d-b2f2ec58c48a	1	\N	\N	26	\N	2	8722813125
\.


--
-- Name: application_masters_appcontent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.application_masters_appcontent_id_seq', 1, false);


--
-- Name: application_masters_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.application_masters_category_id_seq', 14, true);


--
-- Name: application_masters_comorbid_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.application_masters_comorbid_id_seq', 17, true);


--
-- Name: application_masters_district_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.application_masters_district_id_seq', 134, true);


--
-- Name: application_masters_dosage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.application_masters_dosage_id_seq', 6, true);


--
-- Name: application_masters_masterlookup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.application_masters_masterlookup_id_seq', 21, true);


--
-- Name: application_masters_medicines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.application_masters_medicines_id_seq', 71, true);


--
-- Name: application_masters_phc_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.application_masters_phc_id_seq', 5, true);


--
-- Name: application_masters_state_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.application_masters_state_id_seq', 24, true);


--
-- Name: application_masters_subcenter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.application_masters_subcenter_id_seq', 4, true);


--
-- Name: application_masters_taluk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.application_masters_taluk_id_seq', 1, true);


--
-- Name: application_masters_village_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.application_masters_village_id_seq', 32, true);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 116, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 26, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1271, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 29, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 67, true);


--
-- Name: health_management_diagnosis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.health_management_diagnosis_id_seq', 49, true);


--
-- Name: health_management_drugdispensation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oblf_user
--

SELECT pg_catalog.setval('public.health_management_drugdispensation_id_seq', 4, true);


--
-- Name: health_management_homevisit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.health_management_homevisit_id_seq', 3, true);


--
-- Name: health_management_medicinestock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.health_management_medicinestock_id_seq', 6, true);


--
-- Name: health_management_patients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.health_management_patients_id_seq', 202, true);


--
-- Name: health_management_prescription_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.health_management_prescription_id_seq', 47, true);


--
-- Name: health_management_scanned_report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.health_management_scanned_report_id_seq', 9, true);


--
-- Name: health_management_treatments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.health_management_treatments_id_seq', 21, true);


--
-- Name: health_management_userprofile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.health_management_userprofile_id_seq', 40, true);


--
-- Name: application_masters_appcontent application_masters_appcontent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_appcontent
    ADD CONSTRAINT application_masters_appcontent_pkey PRIMARY KEY (id);


--
-- Name: application_masters_appcontent application_masters_appcontent_uuid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_appcontent
    ADD CONSTRAINT application_masters_appcontent_uuid_key UNIQUE (uuid);


--
-- Name: application_masters_category application_masters_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_category
    ADD CONSTRAINT application_masters_category_pkey PRIMARY KEY (id);


--
-- Name: application_masters_category application_masters_category_uuid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_category
    ADD CONSTRAINT application_masters_category_uuid_key UNIQUE (uuid);


--
-- Name: application_masters_comorbid application_masters_comorbid_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_comorbid
    ADD CONSTRAINT application_masters_comorbid_pkey PRIMARY KEY (id);


--
-- Name: application_masters_comorbid application_masters_comorbid_uuid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_comorbid
    ADD CONSTRAINT application_masters_comorbid_uuid_key UNIQUE (uuid);


--
-- Name: application_masters_district application_masters_district_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_district
    ADD CONSTRAINT application_masters_district_pkey PRIMARY KEY (id);


--
-- Name: application_masters_district application_masters_district_uuid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_district
    ADD CONSTRAINT application_masters_district_uuid_key UNIQUE (uuid);


--
-- Name: application_masters_dosage application_masters_dosage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_dosage
    ADD CONSTRAINT application_masters_dosage_pkey PRIMARY KEY (id);


--
-- Name: application_masters_dosage application_masters_dosage_uuid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_dosage
    ADD CONSTRAINT application_masters_dosage_uuid_key UNIQUE (uuid);


--
-- Name: application_masters_masterlookup application_masters_masterlookup_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_masterlookup
    ADD CONSTRAINT application_masters_masterlookup_name_key UNIQUE (name);


--
-- Name: application_masters_masterlookup application_masters_masterlookup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_masterlookup
    ADD CONSTRAINT application_masters_masterlookup_pkey PRIMARY KEY (id);


--
-- Name: application_masters_masterlookup application_masters_masterlookup_uuid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_masterlookup
    ADD CONSTRAINT application_masters_masterlookup_uuid_key UNIQUE (uuid);


--
-- Name: application_masters_medicines application_masters_medicines_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_medicines
    ADD CONSTRAINT application_masters_medicines_pkey PRIMARY KEY (id);


--
-- Name: application_masters_medicines application_masters_medicines_uuid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_medicines
    ADD CONSTRAINT application_masters_medicines_uuid_key UNIQUE (uuid);


--
-- Name: application_masters_phc application_masters_phc_name_taluk_id_4036fee2_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_phc
    ADD CONSTRAINT application_masters_phc_name_taluk_id_4036fee2_uniq UNIQUE (name, taluk_id);


--
-- Name: application_masters_phc application_masters_phc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_phc
    ADD CONSTRAINT application_masters_phc_pkey PRIMARY KEY (id);


--
-- Name: application_masters_phc application_masters_phc_uuid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_phc
    ADD CONSTRAINT application_masters_phc_uuid_key UNIQUE (uuid);


--
-- Name: application_masters_state application_masters_state_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_state
    ADD CONSTRAINT application_masters_state_name_key UNIQUE (name);


--
-- Name: application_masters_state application_masters_state_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_state
    ADD CONSTRAINT application_masters_state_pkey PRIMARY KEY (id);


--
-- Name: application_masters_state application_masters_state_uuid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_state
    ADD CONSTRAINT application_masters_state_uuid_key UNIQUE (uuid);


--
-- Name: application_masters_subcenter application_masters_subcenter_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_subcenter
    ADD CONSTRAINT application_masters_subcenter_pkey PRIMARY KEY (id);


--
-- Name: application_masters_subcenter application_masters_subcenter_uuid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_subcenter
    ADD CONSTRAINT application_masters_subcenter_uuid_key UNIQUE (uuid);


--
-- Name: application_masters_taluk application_masters_taluk_name_district_id_f461c4c4_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_taluk
    ADD CONSTRAINT application_masters_taluk_name_district_id_f461c4c4_uniq UNIQUE (name, district_id);


--
-- Name: application_masters_taluk application_masters_taluk_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_taluk
    ADD CONSTRAINT application_masters_taluk_pkey PRIMARY KEY (id);


--
-- Name: application_masters_taluk application_masters_taluk_uuid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_taluk
    ADD CONSTRAINT application_masters_taluk_uuid_key UNIQUE (uuid);


--
-- Name: application_masters_village application_masters_village_name_subcenter_id_ed3719c0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_village
    ADD CONSTRAINT application_masters_village_name_subcenter_id_ed3719c0_uniq UNIQUE (name, subcenter_id);


--
-- Name: application_masters_village application_masters_village_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_village
    ADD CONSTRAINT application_masters_village_pkey PRIMARY KEY (id);


--
-- Name: application_masters_village application_masters_village_uuid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_village
    ADD CONSTRAINT application_masters_village_uuid_key UNIQUE (uuid);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: health_management_diagnosis health_management_diagnosis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_diagnosis
    ADD CONSTRAINT health_management_diagnosis_pkey PRIMARY KEY (id);


--
-- Name: health_management_drugdispensation health_management_drugdispensation_pkey; Type: CONSTRAINT; Schema: public; Owner: oblf_user
--

ALTER TABLE ONLY public.health_management_drugdispensation
    ADD CONSTRAINT health_management_drugdispensation_pkey PRIMARY KEY (id);


--
-- Name: health_management_drugdispensation health_management_drugdispensation_uuid_key; Type: CONSTRAINT; Schema: public; Owner: oblf_user
--

ALTER TABLE ONLY public.health_management_drugdispensation
    ADD CONSTRAINT health_management_drugdispensation_uuid_key UNIQUE (uuid);


--
-- Name: health_management_homevisit health_management_homevisit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_homevisit
    ADD CONSTRAINT health_management_homevisit_pkey PRIMARY KEY (id);


--
-- Name: health_management_medicinestock health_management_medicinestock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_medicinestock
    ADD CONSTRAINT health_management_medicinestock_pkey PRIMARY KEY (id);


--
-- Name: health_management_medicinestock health_management_medicinestock_uuid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_medicinestock
    ADD CONSTRAINT health_management_medicinestock_uuid_key UNIQUE (uuid);


--
-- Name: health_management_patients health_management_patients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_patients
    ADD CONSTRAINT health_management_patients_pkey PRIMARY KEY (id);


--
-- Name: health_management_prescription health_management_prescription_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_prescription
    ADD CONSTRAINT health_management_prescription_pkey PRIMARY KEY (id);


--
-- Name: health_management_scanned_report health_management_scanned_report_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_scanned_report
    ADD CONSTRAINT health_management_scanned_report_pkey PRIMARY KEY (id);


--
-- Name: health_management_treatments health_management_treatments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_treatments
    ADD CONSTRAINT health_management_treatments_pkey PRIMARY KEY (id);


--
-- Name: health_management_userprofile health_management_userprofile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_userprofile
    ADD CONSTRAINT health_management_userprofile_pkey PRIMARY KEY (id);


--
-- Name: health_management_userprofile health_management_userprofile_uuid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_userprofile
    ADD CONSTRAINT health_management_userprofile_uuid_key UNIQUE (uuid);


--
-- Name: application_masters_appcontent_created_by_id_2c0ba5d6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_appcontent_created_by_id_2c0ba5d6 ON public.application_masters_appcontent USING btree (created_by_id);


--
-- Name: application_masters_appcontent_modified_by_id_7e587f98; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_appcontent_modified_by_id_7e587f98 ON public.application_masters_appcontent USING btree (modified_by_id);


--
-- Name: application_masters_appcontent_status_73eba925; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_appcontent_status_73eba925 ON public.application_masters_appcontent USING btree (status);


--
-- Name: application_masters_appcontent_uuid_5bc80ec2_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_appcontent_uuid_5bc80ec2_like ON public.application_masters_appcontent USING btree (uuid varchar_pattern_ops);


--
-- Name: application_masters_category_created_by_id_76d08676; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_category_created_by_id_76d08676 ON public.application_masters_category USING btree (created_by_id);


--
-- Name: application_masters_category_modified_by_id_1eaf2439; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_category_modified_by_id_1eaf2439 ON public.application_masters_category USING btree (modified_by_id);


--
-- Name: application_masters_category_status_f77d3f42; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_category_status_f77d3f42 ON public.application_masters_category USING btree (status);


--
-- Name: application_masters_category_uuid_0aaf22ba_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_category_uuid_0aaf22ba_like ON public.application_masters_category USING btree (uuid varchar_pattern_ops);


--
-- Name: application_masters_comorbid_created_by_id_75597c97; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_comorbid_created_by_id_75597c97 ON public.application_masters_comorbid USING btree (created_by_id);


--
-- Name: application_masters_comorbid_modified_by_id_a7ec645b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_comorbid_modified_by_id_a7ec645b ON public.application_masters_comorbid USING btree (modified_by_id);


--
-- Name: application_masters_comorbid_status_571ae9d4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_comorbid_status_571ae9d4 ON public.application_masters_comorbid USING btree (status);


--
-- Name: application_masters_comorbid_uuid_c96ca486_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_comorbid_uuid_c96ca486_like ON public.application_masters_comorbid USING btree (uuid varchar_pattern_ops);


--
-- Name: application_masters_district_created_by_id_1f0c3898; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_district_created_by_id_1f0c3898 ON public.application_masters_district USING btree (created_by_id);


--
-- Name: application_masters_district_modified_by_id_f5d311fd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_district_modified_by_id_f5d311fd ON public.application_masters_district USING btree (modified_by_id);


--
-- Name: application_masters_district_state_id_ede4f01b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_district_state_id_ede4f01b ON public.application_masters_district USING btree (state_id);


--
-- Name: application_masters_district_status_2fa4915d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_district_status_2fa4915d ON public.application_masters_district USING btree (status);


--
-- Name: application_masters_district_uuid_18b27b64_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_district_uuid_18b27b64_like ON public.application_masters_district USING btree (uuid varchar_pattern_ops);


--
-- Name: application_masters_dosage_created_by_id_6072720c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_dosage_created_by_id_6072720c ON public.application_masters_dosage USING btree (created_by_id);


--
-- Name: application_masters_dosage_modified_by_id_ce5c005e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_dosage_modified_by_id_ce5c005e ON public.application_masters_dosage USING btree (modified_by_id);


--
-- Name: application_masters_dosage_status_9b7b6da1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_dosage_status_9b7b6da1 ON public.application_masters_dosage USING btree (status);


--
-- Name: application_masters_dosage_uuid_23802610_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_dosage_uuid_23802610_like ON public.application_masters_dosage USING btree (uuid varchar_pattern_ops);


--
-- Name: application_masters_masterlookup_created_by_id_1a8a56d5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_masterlookup_created_by_id_1a8a56d5 ON public.application_masters_masterlookup USING btree (created_by_id);


--
-- Name: application_masters_masterlookup_modified_by_id_d22c7352; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_masterlookup_modified_by_id_d22c7352 ON public.application_masters_masterlookup USING btree (modified_by_id);


--
-- Name: application_masters_masterlookup_name_f1272f2f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_masterlookup_name_f1272f2f_like ON public.application_masters_masterlookup USING btree (name varchar_pattern_ops);


--
-- Name: application_masters_masterlookup_parent_id_37628928; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_masterlookup_parent_id_37628928 ON public.application_masters_masterlookup USING btree (parent_id);


--
-- Name: application_masters_masterlookup_status_b215aa4d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_masterlookup_status_b215aa4d ON public.application_masters_masterlookup USING btree (status);


--
-- Name: application_masters_masterlookup_uuid_92527671_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_masterlookup_uuid_92527671_like ON public.application_masters_masterlookup USING btree (uuid varchar_pattern_ops);


--
-- Name: application_masters_medicines_created_by_id_4a7c536c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_medicines_created_by_id_4a7c536c ON public.application_masters_medicines USING btree (created_by_id);


--
-- Name: application_masters_medicines_modified_by_id_0e32473f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_medicines_modified_by_id_0e32473f ON public.application_masters_medicines USING btree (modified_by_id);


--
-- Name: application_masters_medicines_status_7f0a51a6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_medicines_status_7f0a51a6 ON public.application_masters_medicines USING btree (status);


--
-- Name: application_masters_medicines_uuid_02046ffd_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_medicines_uuid_02046ffd_like ON public.application_masters_medicines USING btree (uuid varchar_pattern_ops);


--
-- Name: application_masters_phc_created_by_id_939ff1e3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_phc_created_by_id_939ff1e3 ON public.application_masters_phc USING btree (created_by_id);


--
-- Name: application_masters_phc_modified_by_id_1bf33389; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_phc_modified_by_id_1bf33389 ON public.application_masters_phc USING btree (modified_by_id);


--
-- Name: application_masters_phc_status_6f44eb29; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_phc_status_6f44eb29 ON public.application_masters_phc USING btree (status);


--
-- Name: application_masters_phc_taluk_id_25d86991; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_phc_taluk_id_25d86991 ON public.application_masters_phc USING btree (taluk_id);


--
-- Name: application_masters_phc_uuid_aca5f998_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_phc_uuid_aca5f998_like ON public.application_masters_phc USING btree (uuid varchar_pattern_ops);


--
-- Name: application_masters_state_created_by_id_bb0a6304; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_state_created_by_id_bb0a6304 ON public.application_masters_state USING btree (created_by_id);


--
-- Name: application_masters_state_modified_by_id_c8ca6c84; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_state_modified_by_id_c8ca6c84 ON public.application_masters_state USING btree (modified_by_id);


--
-- Name: application_masters_state_name_e9b802be_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_state_name_e9b802be_like ON public.application_masters_state USING btree (name varchar_pattern_ops);


--
-- Name: application_masters_state_status_44e58406; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_state_status_44e58406 ON public.application_masters_state USING btree (status);


--
-- Name: application_masters_state_uuid_ede5c367_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_state_uuid_ede5c367_like ON public.application_masters_state USING btree (uuid varchar_pattern_ops);


--
-- Name: application_masters_subcenter_created_by_id_23dcda1b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_subcenter_created_by_id_23dcda1b ON public.application_masters_subcenter USING btree (created_by_id);


--
-- Name: application_masters_subcenter_modified_by_id_2eb92d6b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_subcenter_modified_by_id_2eb92d6b ON public.application_masters_subcenter USING btree (modified_by_id);


--
-- Name: application_masters_subcenter_phc_id_18069260; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_subcenter_phc_id_18069260 ON public.application_masters_subcenter USING btree (phc_id);


--
-- Name: application_masters_subcenter_status_1b0ac2eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_subcenter_status_1b0ac2eb ON public.application_masters_subcenter USING btree (status);


--
-- Name: application_masters_subcenter_uuid_b9794cb2_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_subcenter_uuid_b9794cb2_like ON public.application_masters_subcenter USING btree (uuid varchar_pattern_ops);


--
-- Name: application_masters_taluk_created_by_id_be503b1e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_taluk_created_by_id_be503b1e ON public.application_masters_taluk USING btree (created_by_id);


--
-- Name: application_masters_taluk_district_id_09ab04eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_taluk_district_id_09ab04eb ON public.application_masters_taluk USING btree (district_id);


--
-- Name: application_masters_taluk_modified_by_id_95360430; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_taluk_modified_by_id_95360430 ON public.application_masters_taluk USING btree (modified_by_id);


--
-- Name: application_masters_taluk_status_d228ec0f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_taluk_status_d228ec0f ON public.application_masters_taluk USING btree (status);


--
-- Name: application_masters_taluk_uuid_0344f920_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_taluk_uuid_0344f920_like ON public.application_masters_taluk USING btree (uuid varchar_pattern_ops);


--
-- Name: application_masters_village_created_by_id_44cd2873; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_village_created_by_id_44cd2873 ON public.application_masters_village USING btree (created_by_id);


--
-- Name: application_masters_village_modified_by_id_ea0c40bf; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_village_modified_by_id_ea0c40bf ON public.application_masters_village USING btree (modified_by_id);


--
-- Name: application_masters_village_status_b5d78f87; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_village_status_b5d78f87 ON public.application_masters_village USING btree (status);


--
-- Name: application_masters_village_subcenter_id_637c78cf; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_village_subcenter_id_637c78cf ON public.application_masters_village USING btree (subcenter_id);


--
-- Name: application_masters_village_uuid_4768c1cd_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX application_masters_village_uuid_4768c1cd_like ON public.application_masters_village USING btree (uuid varchar_pattern_ops);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: health_management_diagnosis_created_by_id_07859726; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_diagnosis_created_by_id_07859726 ON public.health_management_diagnosis USING btree (created_by_id);


--
-- Name: health_management_diagnosis_modified_by_id_7f98e5cc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_diagnosis_modified_by_id_7f98e5cc ON public.health_management_diagnosis USING btree (modified_by_id);


--
-- Name: health_management_diagnosis_ndc_id_87a86e82; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_diagnosis_ndc_id_87a86e82 ON public.health_management_diagnosis USING btree (ndc_id);


--
-- Name: health_management_diagnosis_status_ef24cca0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_diagnosis_status_ef24cca0 ON public.health_management_diagnosis USING btree (status);


--
-- Name: health_management_drugdispensation_created_by_id_e99912f9; Type: INDEX; Schema: public; Owner: oblf_user
--

CREATE INDEX health_management_drugdispensation_created_by_id_e99912f9 ON public.health_management_drugdispensation USING btree (created_by_id);


--
-- Name: health_management_drugdispensation_medicine_id_52fc0ee7; Type: INDEX; Schema: public; Owner: oblf_user
--

CREATE INDEX health_management_drugdispensation_medicine_id_52fc0ee7 ON public.health_management_drugdispensation USING btree (medicine_id);


--
-- Name: health_management_drugdispensation_modified_by_id_b9fc13eb; Type: INDEX; Schema: public; Owner: oblf_user
--

CREATE INDEX health_management_drugdispensation_modified_by_id_b9fc13eb ON public.health_management_drugdispensation USING btree (modified_by_id);


--
-- Name: health_management_drugdispensation_status_353b4102; Type: INDEX; Schema: public; Owner: oblf_user
--

CREATE INDEX health_management_drugdispensation_status_353b4102 ON public.health_management_drugdispensation USING btree (status);


--
-- Name: health_management_drugdispensation_uuid_f9a44e82_like; Type: INDEX; Schema: public; Owner: oblf_user
--

CREATE INDEX health_management_drugdispensation_uuid_f9a44e82_like ON public.health_management_drugdispensation USING btree (uuid varchar_pattern_ops);


--
-- Name: health_management_drugdispensation_village_id_eda2c476; Type: INDEX; Schema: public; Owner: oblf_user
--

CREATE INDEX health_management_drugdispensation_village_id_eda2c476 ON public.health_management_drugdispensation USING btree (village_id);


--
-- Name: health_management_homevisit_created_by_id_f112b099; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_homevisit_created_by_id_f112b099 ON public.health_management_homevisit USING btree (created_by_id);


--
-- Name: health_management_homevisit_modified_by_id_ddfea13d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_homevisit_modified_by_id_ddfea13d ON public.health_management_homevisit USING btree (modified_by_id);


--
-- Name: health_management_homevisit_status_f39c0c16; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_homevisit_status_f39c0c16 ON public.health_management_homevisit USING btree (status);


--
-- Name: health_management_medicinestock_created_by_id_7cabbc73; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_medicinestock_created_by_id_7cabbc73 ON public.health_management_medicinestock USING btree (created_by_id);


--
-- Name: health_management_medicinestock_medicine_id_0c6aa190; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_medicinestock_medicine_id_0c6aa190 ON public.health_management_medicinestock USING btree (medicine_id);


--
-- Name: health_management_medicinestock_modified_by_id_cc9bd3bf; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_medicinestock_modified_by_id_cc9bd3bf ON public.health_management_medicinestock USING btree (modified_by_id);


--
-- Name: health_management_medicinestock_status_c57033ff; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_medicinestock_status_c57033ff ON public.health_management_medicinestock USING btree (status);


--
-- Name: health_management_medicinestock_uuid_e1262e2b_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_medicinestock_uuid_e1262e2b_like ON public.health_management_medicinestock USING btree (uuid varchar_pattern_ops);


--
-- Name: health_management_patients_created_by_id_6acceff1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_patients_created_by_id_6acceff1 ON public.health_management_patients USING btree (created_by_id);


--
-- Name: health_management_patients_modified_by_id_39ce8910; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_patients_modified_by_id_39ce8910 ON public.health_management_patients USING btree (modified_by_id);


--
-- Name: health_management_patients_patient_visit_type_id_daed94bd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_patients_patient_visit_type_id_daed94bd ON public.health_management_patients USING btree (patient_visit_type_id);


--
-- Name: health_management_patients_status_9d6da5d1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_patients_status_9d6da5d1 ON public.health_management_patients USING btree (status);


--
-- Name: health_management_patients_village_id_5dca3325; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_patients_village_id_5dca3325 ON public.health_management_patients USING btree (village_id);


--
-- Name: health_management_prescription_created_by_id_925109c6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_prescription_created_by_id_925109c6 ON public.health_management_prescription USING btree (created_by_id);


--
-- Name: health_management_prescription_dosage_id_efce109b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_prescription_dosage_id_efce109b ON public.health_management_prescription USING btree (dosage_id);


--
-- Name: health_management_prescription_medicines_id_82c2b3e9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_prescription_medicines_id_82c2b3e9 ON public.health_management_prescription USING btree (medicines_id);


--
-- Name: health_management_prescription_modified_by_id_79365e3a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_prescription_modified_by_id_79365e3a ON public.health_management_prescription USING btree (modified_by_id);


--
-- Name: health_management_prescription_status_9345216f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_prescription_status_9345216f ON public.health_management_prescription USING btree (status);


--
-- Name: health_management_scanned_report_created_by_id_8348738a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_scanned_report_created_by_id_8348738a ON public.health_management_scanned_report USING btree (created_by_id);


--
-- Name: health_management_scanned_report_modified_by_id_2976c2ea; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_scanned_report_modified_by_id_2976c2ea ON public.health_management_scanned_report USING btree (modified_by_id);


--
-- Name: health_management_scanned_report_status_fb5e7911; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_scanned_report_status_fb5e7911 ON public.health_management_scanned_report USING btree (status);


--
-- Name: health_management_treatments_created_by_id_c85ac089; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_treatments_created_by_id_c85ac089 ON public.health_management_treatments USING btree (created_by_id);


--
-- Name: health_management_treatments_modified_by_id_655404f3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_treatments_modified_by_id_655404f3 ON public.health_management_treatments USING btree (modified_by_id);


--
-- Name: health_management_treatments_status_6e004beb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_treatments_status_6e004beb ON public.health_management_treatments USING btree (status);


--
-- Name: health_management_userprofile_created_by_id_f2d60550; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_userprofile_created_by_id_f2d60550 ON public.health_management_userprofile USING btree (created_by_id);


--
-- Name: health_management_userprofile_modified_by_id_bc76bf92; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_userprofile_modified_by_id_bc76bf92 ON public.health_management_userprofile USING btree (modified_by_id);


--
-- Name: health_management_userprofile_status_e339ba5c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_userprofile_status_e339ba5c ON public.health_management_userprofile USING btree (status);


--
-- Name: health_management_userprofile_user_id_26ebcb69; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_userprofile_user_id_26ebcb69 ON public.health_management_userprofile USING btree (user_id);


--
-- Name: health_management_userprofile_user_type_28a552eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_userprofile_user_type_28a552eb ON public.health_management_userprofile USING btree (user_type);


--
-- Name: health_management_userprofile_uuid_d0a66d07_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_userprofile_uuid_d0a66d07_like ON public.health_management_userprofile USING btree (uuid varchar_pattern_ops);


--
-- Name: health_management_userprofile_village_id_16f49b18; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX health_management_userprofile_village_id_16f49b18 ON public.health_management_userprofile USING btree (village_id);


--
-- Name: application_masters_masterlookup application_masters__created_by_id_1a8a56d5_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_masterlookup
    ADD CONSTRAINT application_masters__created_by_id_1a8a56d5_fk_auth_user FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_district application_masters__created_by_id_1f0c3898_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_district
    ADD CONSTRAINT application_masters__created_by_id_1f0c3898_fk_auth_user FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_subcenter application_masters__created_by_id_23dcda1b_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_subcenter
    ADD CONSTRAINT application_masters__created_by_id_23dcda1b_fk_auth_user FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_appcontent application_masters__created_by_id_2c0ba5d6_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_appcontent
    ADD CONSTRAINT application_masters__created_by_id_2c0ba5d6_fk_auth_user FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_village application_masters__created_by_id_44cd2873_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_village
    ADD CONSTRAINT application_masters__created_by_id_44cd2873_fk_auth_user FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_medicines application_masters__created_by_id_4a7c536c_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_medicines
    ADD CONSTRAINT application_masters__created_by_id_4a7c536c_fk_auth_user FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_dosage application_masters__created_by_id_6072720c_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_dosage
    ADD CONSTRAINT application_masters__created_by_id_6072720c_fk_auth_user FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_comorbid application_masters__created_by_id_75597c97_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_comorbid
    ADD CONSTRAINT application_masters__created_by_id_75597c97_fk_auth_user FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_category application_masters__created_by_id_76d08676_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_category
    ADD CONSTRAINT application_masters__created_by_id_76d08676_fk_auth_user FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_state application_masters__created_by_id_bb0a6304_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_state
    ADD CONSTRAINT application_masters__created_by_id_bb0a6304_fk_auth_user FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_taluk application_masters__created_by_id_be503b1e_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_taluk
    ADD CONSTRAINT application_masters__created_by_id_be503b1e_fk_auth_user FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_taluk application_masters__district_id_09ab04eb_fk_applicati; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_taluk
    ADD CONSTRAINT application_masters__district_id_09ab04eb_fk_applicati FOREIGN KEY (district_id) REFERENCES public.application_masters_district(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_medicines application_masters__modified_by_id_0e32473f_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_medicines
    ADD CONSTRAINT application_masters__modified_by_id_0e32473f_fk_auth_user FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_category application_masters__modified_by_id_1eaf2439_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_category
    ADD CONSTRAINT application_masters__modified_by_id_1eaf2439_fk_auth_user FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_subcenter application_masters__modified_by_id_2eb92d6b_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_subcenter
    ADD CONSTRAINT application_masters__modified_by_id_2eb92d6b_fk_auth_user FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_appcontent application_masters__modified_by_id_7e587f98_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_appcontent
    ADD CONSTRAINT application_masters__modified_by_id_7e587f98_fk_auth_user FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_taluk application_masters__modified_by_id_95360430_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_taluk
    ADD CONSTRAINT application_masters__modified_by_id_95360430_fk_auth_user FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_comorbid application_masters__modified_by_id_a7ec645b_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_comorbid
    ADD CONSTRAINT application_masters__modified_by_id_a7ec645b_fk_auth_user FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_state application_masters__modified_by_id_c8ca6c84_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_state
    ADD CONSTRAINT application_masters__modified_by_id_c8ca6c84_fk_auth_user FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_dosage application_masters__modified_by_id_ce5c005e_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_dosage
    ADD CONSTRAINT application_masters__modified_by_id_ce5c005e_fk_auth_user FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_masterlookup application_masters__modified_by_id_d22c7352_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_masterlookup
    ADD CONSTRAINT application_masters__modified_by_id_d22c7352_fk_auth_user FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_village application_masters__modified_by_id_ea0c40bf_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_village
    ADD CONSTRAINT application_masters__modified_by_id_ea0c40bf_fk_auth_user FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_district application_masters__modified_by_id_f5d311fd_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_district
    ADD CONSTRAINT application_masters__modified_by_id_f5d311fd_fk_auth_user FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_masterlookup application_masters__parent_id_37628928_fk_applicati; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_masterlookup
    ADD CONSTRAINT application_masters__parent_id_37628928_fk_applicati FOREIGN KEY (parent_id) REFERENCES public.application_masters_masterlookup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_subcenter application_masters__phc_id_18069260_fk_applicati; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_subcenter
    ADD CONSTRAINT application_masters__phc_id_18069260_fk_applicati FOREIGN KEY (phc_id) REFERENCES public.application_masters_phc(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_district application_masters__state_id_ede4f01b_fk_applicati; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_district
    ADD CONSTRAINT application_masters__state_id_ede4f01b_fk_applicati FOREIGN KEY (state_id) REFERENCES public.application_masters_state(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_village application_masters__subcenter_id_637c78cf_fk_applicati; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_village
    ADD CONSTRAINT application_masters__subcenter_id_637c78cf_fk_applicati FOREIGN KEY (subcenter_id) REFERENCES public.application_masters_subcenter(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_phc application_masters__taluk_id_25d86991_fk_applicati; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_phc
    ADD CONSTRAINT application_masters__taluk_id_25d86991_fk_applicati FOREIGN KEY (taluk_id) REFERENCES public.application_masters_taluk(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_phc application_masters_phc_created_by_id_939ff1e3_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_phc
    ADD CONSTRAINT application_masters_phc_created_by_id_939ff1e3_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: application_masters_phc application_masters_phc_modified_by_id_1bf33389_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_masters_phc
    ADD CONSTRAINT application_masters_phc_modified_by_id_1bf33389_fk_auth_user_id FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_diagnosis health_management_di_created_by_id_07859726_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_diagnosis
    ADD CONSTRAINT health_management_di_created_by_id_07859726_fk_auth_user FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_diagnosis health_management_di_modified_by_id_7f98e5cc_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_diagnosis
    ADD CONSTRAINT health_management_di_modified_by_id_7f98e5cc_fk_auth_user FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_diagnosis health_management_di_ndc_id_87a86e82_fk_applicati; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_diagnosis
    ADD CONSTRAINT health_management_di_ndc_id_87a86e82_fk_applicati FOREIGN KEY (ndc_id) REFERENCES public.application_masters_masterlookup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_drugdispensation health_management_dr_created_by_id_e99912f9_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: oblf_user
--

ALTER TABLE ONLY public.health_management_drugdispensation
    ADD CONSTRAINT health_management_dr_created_by_id_e99912f9_fk_auth_user FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_drugdispensation health_management_dr_medicine_id_52fc0ee7_fk_applicati; Type: FK CONSTRAINT; Schema: public; Owner: oblf_user
--

ALTER TABLE ONLY public.health_management_drugdispensation
    ADD CONSTRAINT health_management_dr_medicine_id_52fc0ee7_fk_applicati FOREIGN KEY (medicine_id) REFERENCES public.application_masters_medicines(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_drugdispensation health_management_dr_modified_by_id_b9fc13eb_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: oblf_user
--

ALTER TABLE ONLY public.health_management_drugdispensation
    ADD CONSTRAINT health_management_dr_modified_by_id_b9fc13eb_fk_auth_user FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_drugdispensation health_management_dr_village_id_eda2c476_fk_applicati; Type: FK CONSTRAINT; Schema: public; Owner: oblf_user
--

ALTER TABLE ONLY public.health_management_drugdispensation
    ADD CONSTRAINT health_management_dr_village_id_eda2c476_fk_applicati FOREIGN KEY (village_id) REFERENCES public.application_masters_village(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_homevisit health_management_ho_created_by_id_f112b099_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_homevisit
    ADD CONSTRAINT health_management_ho_created_by_id_f112b099_fk_auth_user FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_homevisit health_management_ho_modified_by_id_ddfea13d_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_homevisit
    ADD CONSTRAINT health_management_ho_modified_by_id_ddfea13d_fk_auth_user FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_medicinestock health_management_me_created_by_id_7cabbc73_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_medicinestock
    ADD CONSTRAINT health_management_me_created_by_id_7cabbc73_fk_auth_user FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_medicinestock health_management_me_medicine_id_0c6aa190_fk_applicati; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_medicinestock
    ADD CONSTRAINT health_management_me_medicine_id_0c6aa190_fk_applicati FOREIGN KEY (medicine_id) REFERENCES public.application_masters_medicines(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_medicinestock health_management_me_modified_by_id_cc9bd3bf_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_medicinestock
    ADD CONSTRAINT health_management_me_modified_by_id_cc9bd3bf_fk_auth_user FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_patients health_management_pa_created_by_id_6acceff1_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_patients
    ADD CONSTRAINT health_management_pa_created_by_id_6acceff1_fk_auth_user FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_patients health_management_pa_modified_by_id_39ce8910_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_patients
    ADD CONSTRAINT health_management_pa_modified_by_id_39ce8910_fk_auth_user FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_patients health_management_pa_patient_visit_type_i_daed94bd_fk_applicati; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_patients
    ADD CONSTRAINT health_management_pa_patient_visit_type_i_daed94bd_fk_applicati FOREIGN KEY (patient_visit_type_id) REFERENCES public.application_masters_masterlookup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_patients health_management_pa_village_id_5dca3325_fk_applicati; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_patients
    ADD CONSTRAINT health_management_pa_village_id_5dca3325_fk_applicati FOREIGN KEY (village_id) REFERENCES public.application_masters_village(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_prescription health_management_pr_created_by_id_925109c6_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_prescription
    ADD CONSTRAINT health_management_pr_created_by_id_925109c6_fk_auth_user FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_prescription health_management_pr_dosage_id_efce109b_fk_applicati; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_prescription
    ADD CONSTRAINT health_management_pr_dosage_id_efce109b_fk_applicati FOREIGN KEY (dosage_id) REFERENCES public.application_masters_dosage(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_prescription health_management_pr_medicines_id_82c2b3e9_fk_applicati; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_prescription
    ADD CONSTRAINT health_management_pr_medicines_id_82c2b3e9_fk_applicati FOREIGN KEY (medicines_id) REFERENCES public.application_masters_medicines(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_prescription health_management_pr_modified_by_id_79365e3a_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_prescription
    ADD CONSTRAINT health_management_pr_modified_by_id_79365e3a_fk_auth_user FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_scanned_report health_management_sc_created_by_id_8348738a_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_scanned_report
    ADD CONSTRAINT health_management_sc_created_by_id_8348738a_fk_auth_user FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_scanned_report health_management_sc_modified_by_id_2976c2ea_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_scanned_report
    ADD CONSTRAINT health_management_sc_modified_by_id_2976c2ea_fk_auth_user FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_treatments health_management_tr_created_by_id_c85ac089_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_treatments
    ADD CONSTRAINT health_management_tr_created_by_id_c85ac089_fk_auth_user FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_treatments health_management_tr_modified_by_id_655404f3_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_treatments
    ADD CONSTRAINT health_management_tr_modified_by_id_655404f3_fk_auth_user FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_userprofile health_management_us_created_by_id_f2d60550_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_userprofile
    ADD CONSTRAINT health_management_us_created_by_id_f2d60550_fk_auth_user FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_userprofile health_management_us_modified_by_id_bc76bf92_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_userprofile
    ADD CONSTRAINT health_management_us_modified_by_id_bc76bf92_fk_auth_user FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_userprofile health_management_us_village_id_16f49b18_fk_applicati; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_userprofile
    ADD CONSTRAINT health_management_us_village_id_16f49b18_fk_applicati FOREIGN KEY (village_id) REFERENCES public.application_masters_village(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_management_userprofile health_management_userprofile_user_id_26ebcb69_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_management_userprofile
    ADD CONSTRAINT health_management_userprofile_user_id_26ebcb69_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

